"""نقطة الدخول للإنتاج: gunicorn wsgi:app"""
from werkzeug.middleware.proxy_fix import ProxyFix

from app import create_app

app = create_app()
# خلف Nginx: ثق بعنوان واحد فقط من الوكيل العكسي لضمان صحة IP في سجل التدقيق وحدود المحاولات
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
