import os
import re
import shutil
import tempfile
import unittest

from app import create_app
from app.config import TestConfig

DEMO_PW = "Demo@2026"
PHONES = {
    "super_admin": "0900000001", "general_admin": "0900000002", "state_manager": "0900000003",
    "locality_manager": "0900000004", "center_manager": "0900000005", "center_staff": "0900000006",
    "umr_manager": "0900000007", "donor": "0911000001",
}


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix="qh-test-")
        url = os.environ.get("QH_TEST_PG_URL")
        if url:  # تشغيل نفس الاختبارات على PostgreSQL
            from app.db import Database
            db = Database(url)
            db.execute("DROP SCHEMA IF EXISTS public CASCADE")
            db.execute("CREATE SCHEMA public")
            db.close()
        else:
            url = f"sqlite:///{cls.tmp}/test.db"
        cls.app = create_app(TestConfig, {"DATABASE_URL": url, "BACKUP_DIR": f"{cls.tmp}/backups"})

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def setUp(self):
        self.c = self.app.test_client()
        with self.app.app_context():
            from app.db import get_db
            get_db().execute("DELETE FROM rate_limits")

    # ---------- أدوات ----------
    def csrf(self, client=None, path="/login"):
        client = client or self.c
        for p in (path, "/login", "/"):
            html = client.get(p).get_data(as_text=True)
            m = re.search(r'name="_csrf" value="([^"]+)"', html)
            if m:
                return m.group(1)
        return ""

    def post(self, path, data=None, client=None, follow=True):
        client = client or self.c
        data = dict(data or {})
        data["_csrf"] = self.csrf(client, "/login" if not path.startswith("/admin") and not path.startswith("/donor") else "/")
        return client.post(path, data=data, follow_redirects=follow)

    def login(self, who, client=None):
        client = client or self.c
        phone = PHONES.get(who, who)
        r = self.post("/login", {"phone": phone, "password": DEMO_PW}, client=client)
        self.assertNotIn("غير صحيحة", r.get_data(as_text=True), f"login failed for {who}")
        return r

    def db(self):
        from app.db import Database
        return Database(self.app.config["DATABASE_URL"])
