"""التقرير الشهري لبنوك الدم: الإعداد، الصلاحيات، الإرسال، المراجعة، الطباعة، والتقرير المجمّع."""
import io
import json
import re

from tests.helpers import Base

YEAR, MONTH = 2025, 6


def filled_form(**over):
    f = {
        "action": "save", "ref_no": "و ص/ب د/12", "notes": "تقرير تجريبي",
        "tti__HIV__rapid__n": "5429", "tti__HIV__rapid__r": "30", "tti__HIV__elisa__n": "450",
        "tti__HBV__rapid__n": "٢٠", "tti__HBV__rapid__r": "0",
        "dept_count": "3", "dept_name_0": "الحوادث العامة", "dept_whole_0": "275",
        "dept_name_1": "نساء وتوليد", "dept_whole_1": "1200", "dept_name_2": "", "dept_whole_2": "",
        "camp_count": "3", "camp_org_0": "المقاومة الشعبية", "camp_units_0": "50", "camp_loc_0": "شيكان",
        "camp_org_1": "المقاومة الشعبية", "camp_units_1": "50", "camp_loc_1": "شيكان",
        "unit_rural": "14", "svc_donors_voluntary": "450", "svc_expired": "9",
    }
    f.update(over)
    return f


class MonthlyReportsTest(Base):
    def _center_id(self, phone_role="center_manager"):
        db = self.db()
        uid = db.scalar("SELECT id FROM users WHERE phone = ?", ("+249900000005" if phone_role == "center_manager" else "+249900000007",))
        return db.scalar("SELECT center_id FROM user_roles WHERE user_id = ? AND center_id IS NOT NULL", (uid,))

    def _new(self, client, center_id, year=YEAR, month=MONTH):
        r = self.post("/admin/monthly-reports/new", {"center_id": center_id, "year": year, "month": month}, client=client, follow=False)
        self.assertEqual(r.status_code, 302, r.get_data(as_text=True)[:300])
        m = re.search(r"/admin/monthly-reports/(\d+)$", r.headers["Location"])
        self.assertTrue(m, r.headers["Location"])
        return int(m.group(1))

    def test_full_workflow(self):
        cid = self._center_id()
        self.login("center_staff")
        page = self.c.get("/admin/monthly-reports").get_data(as_text=True)
        self.assertIn("التقارير الشهرية لبنوك الدم", page)
        rid = self._new(self.c, cid)
        # فتح نفس الشهر مرة أخرى يعيد نفس التقرير ولا يكرره
        self.assertEqual(self._new(self.c, cid), rid)
        html = self.c.get(f"/admin/monthly-reports/{rid}").get_data(as_text=True)
        self.assertIn("إجمالي عدد الفحوصات", html)
        self.assertIn("الحوادث العامة", html)  # أقسام مقترحة

        r = self.post(f"/admin/monthly-reports/{rid}", filled_form())
        self.assertIn("تم حفظ التقرير كمسودة", r.get_data(as_text=True))
        data = json.loads(self.db().scalar("SELECT data FROM monthly_reports WHERE id = ?", (rid,)))
        self.assertEqual(data["tti"]["HIV"]["rapid"], {"r": 30, "n": 5429})
        self.assertIsNone(data["tti"]["HIV"]["elisa"]["r"])           # الخانة الفارغة تبقى فارغة
        self.assertEqual(data["tti"]["HBV"]["rapid"], {"r": 0, "n": 20})  # أرقام عربية مقبولة
        self.assertEqual([d["dept"] for d in data["transfusion"]], ["الحوادث العامة", "نساء وتوليد"])
        self.assertEqual(len(data["campaigns"]), 2)
        self.assertEqual(data["units"]["rural"], 14)

        # الموظف لا يملك صلاحية الإرسال
        self.assertEqual(self.post(f"/admin/monthly-reports/{rid}", filled_form(action="submit")).status_code, 403)

        # أخطاء الإدخال لا تُحفظ وتظهر للمستخدم
        r = self.post(f"/admin/monthly-reports/{rid}", filled_form(tti__HIV__rapid__r="-5", dept_whole_2="3"))
        txt = r.get_data(as_text=True)
        self.assertIn("أدخل رقمًا صحيحًا", txt)
        self.assertIn("اكتب اسم القسم", txt)
        self.assertEqual(json.loads(self.db().scalar("SELECT data FROM monthly_reports WHERE id = ?", (rid,)))["tti"]["HIV"]["rapid"]["r"], 30)

        # مدير بنك الدم يرسل التقرير
        mgr = self.app.test_client()
        self.login("center_manager", client=mgr)
        r = self.post(f"/admin/monthly-reports/{rid}", filled_form(action="submit"), client=mgr)
        self.assertIn("تم إرسال التقرير للمراجعة", r.get_data(as_text=True))
        self.assertEqual(self.db().scalar("SELECT status FROM monthly_reports WHERE id = ?", (rid,)), "submitted")
        # بعد الإرسال لا يمكن التعديل
        self.assertEqual(self.post(f"/admin/monthly-reports/{rid}", filled_form(), client=mgr).status_code, 403)
        # إشعار للمراجعين (مدير الولاية)
        sm = self.db().scalar("SELECT id FROM users WHERE phone = '+249900000003'")
        self.assertTrue(self.db().scalar("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND category = 'monthly_report'", (sm,)))

        # مدير بنك دم آخر لا يرى التقرير
        other = self.app.test_client()
        self.login("umr_manager", client=other)
        self.assertEqual(other.get(f"/admin/monthly-reports/{rid}").status_code, 403)

        # مدير الولاية يعيده ثم يعتمده
        st = self.app.test_client()
        self.login("state_manager", client=st)
        r = self.post(f"/admin/monthly-reports/{rid}/review", {"action": "return"}, client=st)
        self.assertIn("اكتب سبب الإعادة", r.get_data(as_text=True))
        self.post(f"/admin/monthly-reports/{rid}/review", {"action": "return", "note": "راجع عدد فحوصات HIV"}, client=st)
        self.assertEqual(self.db().scalar("SELECT status FROM monthly_reports WHERE id = ?", (rid,)), "returned")
        html = mgr.get(f"/admin/monthly-reports/{rid}").get_data(as_text=True)
        self.assertIn("راجع عدد فحوصات HIV", html)
        self.post(f"/admin/monthly-reports/{rid}", filled_form(action="submit"), client=mgr)
        self.post(f"/admin/monthly-reports/{rid}/review", {"action": "accept"}, client=st)
        self.assertEqual(self.db().scalar("SELECT status FROM monthly_reports WHERE id = ?", (rid,)), "accepted")

        # الطباعة بشكل الخطاب الرسمي
        p = st.get(f"/admin/monthly-reports/{rid}/print").get_data(as_text=True)
        for s in ("بسم الله الرحمن الرحيم", "ولاية شمال كردفان", "وزارة الصحة والتنمية الاجتماعية", "النمرة",
                  "الإجمالي: 5,909", "1,475", "المقاومة الشعبية", "التالف"):
            self.assertIn(s, p)
        x = st.get(f"/admin/monthly-reports/{rid}/print?format=xlsx")
        self.assertEqual(x.status_code, 200)
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(x.data))
        vals = [c for row in wb.active.iter_rows(values_only=True) for c in row if c is not None]
        self.assertIn(5429, vals)
        self.assertIn("نساء وتوليد", vals)

        # التقرير المجمّع للربع الأول
        s = st.get(f"/admin/monthly-reports/summary?year={YEAR}&period=q2").get_data(as_text=True)
        self.assertIn("الربع الثاني 2025", s)
        self.assertIn("1,475", s)
        self.assertIn("لم تُرسل بعد", s)  # بنوك أخرى لم ترسل
        sp = st.get(f"/admin/monthly-reports/summary?year={YEAR}&period=q2&format=print").get_data(as_text=True)
        self.assertIn("المدير العام لوزارة الصحة والتنمية الاجتماعية", sp)
        self.assertIn("صورة إلى", sp)
        # مدير بنك الدم لا يصل إلى التقرير المجمّع
        self.assertEqual(mgr.get("/admin/monthly-reports/summary").status_code, 403)

    def test_aggregate_and_new_month_prefill(self):
        cid = self._center_id()
        self.login("center_manager")
        a = self._new(self.c, cid, 2026, 1)
        self.post(f"/admin/monthly-reports/{a}", filled_form(action="submit", unit_rural="10"))
        b = self._new(self.c, cid, 2026, 2)
        # الشهر الجديد يقترح أقسام الشهر السابق بدون أرقامها
        d = json.loads(self.db().scalar("SELECT data FROM monthly_reports WHERE id = ?", (b,)))
        self.assertEqual([x["dept"] for x in d["transfusion"]], ["الحوادث العامة", "نساء وتوليد"])
        self.assertIsNone(d["transfusion"][0]["whole"])
        self.post(f"/admin/monthly-reports/{b}", filled_form(action="submit", unit_rural="12", dept_name_2="البريطاني", dept_whole_2="7"))
        st = self.app.test_client()
        self.login("general_admin", client=st)
        html = st.get("/admin/monthly-reports/summary?year=2026&period=q1").get_data(as_text=True)
        # 275×2 + 1200×2 + 7 وحدات دم كامل
        self.assertIn("2,957", html)
        self.assertIn("البريطاني", html)
        # الوحدات الصحية رصيد: يؤخذ آخر شهر (12) ولا يُجمع (22)
        self.assertRegex(html, r"<td>12</td>")
        self.assertNotRegex(html, r"<td>22</td>")
        # لا يمكن إنشاء تقرير لشهر مستقبلي
        r = self.post("/admin/monthly-reports/new", {"center_id": cid, "year": 2099, "month": 1})
        self.assertIn("لا يمكن إعداد تقرير لشهر لم يبدأ", r.get_data(as_text=True))

    def test_empty_report_cannot_be_submitted(self):
        cid = self._center_id()
        self.login("center_manager")
        rid = self._new(self.c, cid, 2025, 12)
        blank = {k: "" for k in filled_form() if k.startswith(("tti__", "dept_whole", "camp_", "unit_", "svc_"))}
        r = self.post(f"/admin/monthly-reports/{rid}", {**filled_form(action="submit"), **blank,
                                                         "dept_count": "0", "camp_count": "0"})
        self.assertIn("التقرير فارغ", r.get_data(as_text=True))
        self.assertEqual(self.db().scalar("SELECT status FROM monthly_reports WHERE id = ?", (rid,)), "draft")

    def test_letterhead_settings_and_logo(self):
        self.login("super_admin")
        html = self.c.get("/admin/settings").get_data(as_text=True)
        self.assertIn("ترويسة التقارير الشهرية", html)
        png = b"\x89PNG\r\n\x1a\n" + b"0" * 200
        r = self.c.post("/admin/settings/report-logo", data={"_csrf": self.csrf(self.c, "/admin/settings"), "action": "upload",
                                                             "logo": (io.BytesIO(png), "logo.png")},
                        content_type="multipart/form-data", follow_redirects=True)
        self.assertIn("تم حفظ شعار التقارير", r.get_data(as_text=True))
        r = self.c.post("/admin/settings/report-logo", data={"_csrf": self.csrf(self.c, "/admin/settings"), "action": "upload",
                                                             "logo": (io.BytesIO(b"<svg onload=alert(1)>"), "x.svg")},
                        content_type="multipart/form-data", follow_redirects=True)
        self.assertIn("ارفع صورة PNG أو JPG", r.get_data(as_text=True))
