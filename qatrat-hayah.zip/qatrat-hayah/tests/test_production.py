"""اختبارات النسخة الحقيقية: الإعداد الأول، الاستيراد من Excel، استعادة كلمة المرور بالـ SMS، PWA."""
import io
import os
import re
import shutil
import tempfile
import unittest

from app import create_app
from app.config import TestConfig


class ProductionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.mkdtemp(prefix="qh-prod-")
        url = os.environ.get("QH_TEST_PG_URL")
        if url:
            from app.db import Database
            db = Database(url)
            db.execute("DROP SCHEMA IF EXISTS public CASCADE")
            db.execute("CREATE SCHEMA public")
            db.close()
        else:
            url = f"sqlite:///{cls.tmp}/prod.db"
        cls.app = create_app(TestConfig, {"DATABASE_URL": url, "SEED_DEMO_DATA": False, "SETUP_TOKEN": "setup-secret",
                                          "BACKUP_DIR": f"{cls.tmp}/b"})
        cls.sent = []

        class FakeSms:
            def send_text(self, phone, text):
                cls.sent.append((phone, text))
                return True

            def send(self, channel, user, n):
                return self.send_text(user["phone"], n["body"])
        import app.notifications as notif
        notif.sms_provider = lambda: FakeSms()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmp, ignore_errors=True)

    def csrf(self, c, path):
        m = re.search(r'name="_csrf" value="([^"]+)"', c.get(path).get_data(as_text=True))
        return m.group(1) if m else ""

    def test_1_setup_import_reset(self):
        c = self.app.test_client()
        # بدون مدير نظام: كل الصفحات تحوّل إلى الإعداد الأول، ولا توجد بيانات تجريبية
        r = c.get("/")
        self.assertEqual(r.status_code, 302)
        self.assertTrue(r.headers["Location"].endswith("/setup"))
        self.assertEqual(c.get("/api/v1/centers").status_code, 503)
        html = c.get("/setup").get_data(as_text=True)
        self.assertNotIn("نسخة تجريبية", html)
        tok = self.csrf(c, "/setup")
        data = {"_csrf": tok, "full_name": "مدير المنصة الفعلي", "phone": "0912345000", "password": "RealAdmin2026",
                "password_confirm": "RealAdmin2026", "setup_token": "wrong"}
        self.assertIn("رمز الإعداد غير صحيح", c.post("/setup", data=data).get_data(as_text=True))
        data["setup_token"] = "setup-secret"
        r = c.post("/setup", data=data, follow_redirects=True)
        self.assertIn("خطوات تجهيز المنصة", r.get_data(as_text=True))
        self.assertEqual(c.get("/setup").status_code, 404)
        self.assertEqual(self.app.test_client().get("/").status_code, 200)

        # استيراد المحليات والمراكز من Excel
        from openpyxl import Workbook

        def xlsx(rows):
            wb = Workbook()
            for r in rows:
                wb.active.append(r)
            b = io.BytesIO()
            wb.save(b)
            b.seek(0)
            return b
        self.assertEqual(c.get("/admin/import/centers/template.xlsx").data[:2], b"PK")
        tok = self.csrf(c, "/admin/import/localities")
        r = c.post("/admin/import/localities", data={"_csrf": tok, "file": (xlsx([
            ["الولاية", "المحلية", "المدينة"], ["الخرطوم", "بحري", "الخرطوم بحري"], ["الخرطوم", "بحري", "الحلفايا"],
            ["شمال كردفان", "شيكان", "الأبيض"]]), "loc.xlsx")}, content_type="multipart/form-data")
        html = r.get_data(as_text=True)
        self.assertIn("تم الاستيراد", html)
        # ملف فيه خطأ: لا يُستورد أي صف
        tok = self.csrf(c, "/admin/import/centers")
        r = c.post("/admin/import/centers", data={"_csrf": tok, "file": (xlsx([
            ["اسم المركز", "النوع", "الولاية", "المحلية", "الهاتف"],
            ["بنك دم بحري", "بنك دم", "الخرطوم", "بحري", "0912000111"],
            ["مركز خاطئ", "نوع غير معروف", "الخرطوم", "بحري", ""]]), "c.xlsx")}, content_type="multipart/form-data")
        self.assertIn("لم يتم الاستيراد", r.get_data(as_text=True))
        from app.db import Database
        db = Database(self.app.config["DATABASE_URL"])
        self.assertEqual(db.scalar("SELECT COUNT(*) AS n FROM blood_centers", (), 0), 0)
        tok = self.csrf(c, "/admin/import/centers")
        r = c.post("/admin/import/centers", data={"_csrf": tok, "file": (xlsx([
            ["اسم المركز", "النوع", "الولاية", "المحلية", "المدينة", "الهاتف", "خط العرض", "خط الطول", "يستقبل الحجوزات"],
            ["بنك دم بحري", "بنك دم", "الخرطوم", "بحري", "الخرطوم بحري", "0912000111", "15.64", "32.53", "نعم"],
            ["مركز التبرع – الأبيض", "مركز تبرع", "شمال كردفان", "شيكان", "الأبيض", "", "", "", "نعم"]]), "c.xlsx")},
            content_type="multipart/form-data")
        self.assertIn("تم الاستيراد", r.get_data(as_text=True))
        self.assertEqual(db.scalar("SELECT COUNT(*) AS n FROM blood_centers", (), 0), 2)
        self.assertEqual(db.scalar("SELECT COUNT(*) AS n FROM blood_inventory", (), 0), 16)
        db.close()

        # متبرع حقيقي يسجل ثم يستعيد كلمة المرور برمز SMS
        d = self.app.test_client()
        loc = self.app.test_client()  # noqa
        from app.db import Database as D2
        db = D2(self.app.config["DATABASE_URL"])
        l = db.one("SELECT id, governorate_id FROM localities WHERE name_ar = 'شيكان'")
        db.close()
        tok = self.csrf(d, "/register")
        d.post("/register", data={"_csrf": tok, "full_name": "متبرع حقيقي للاختبار", "phone": "0912777888",
                                  "password": "Donor2026x", "password_confirm": "Donor2026x", "governorate_id": l["governorate_id"],
                                  "locality_id": l["id"], "blood_type": "unknown", "consent": "1"})
        d.post("/logout", data={"_csrf": self.csrf(d, "/")})
        tok = self.csrf(d, "/forgot-password")
        r = d.post("/forgot-password", data={"_csrf": tok, "phone": "0912777888"}, follow_redirects=True)
        self.assertIn("إذا كان الرقم مسجلًا", r.get_data(as_text=True))
        code = re.search(r"(\d{6})", self.sent[-1][1]).group(1)
        tok = self.csrf(d, "/reset-password?phone=0912777888")
        bad = d.post("/reset-password", data={"_csrf": tok, "phone": "0912777888", "code": "000000" if code != "000000" else "111111",
                                              "password": "NewPass2026", "password_confirm": "NewPass2026"})
        self.assertIn("الرمز غير صحيح", bad.get_data(as_text=True))
        r = d.post("/reset-password", data={"_csrf": tok, "phone": "0912777888", "code": code, "password": "NewPass2026",
                                            "password_confirm": "NewPass2026"}, follow_redirects=True)
        self.assertIn("تم تغيير كلمة المرور", r.get_data(as_text=True))
        tok = self.csrf(d, "/login")
        r = d.post("/login", data={"_csrf": tok, "phone": "0912777888", "password": "NewPass2026"}, follow_redirects=True)
        self.assertIn("مرحبًا", r.get_data(as_text=True))
        # الرمز لا يُستخدم مرتين
        d2 = self.app.test_client()
        tok = self.csrf(d2, "/reset-password?phone=0912777888")
        r = d2.post("/reset-password", data={"_csrf": tok, "phone": "0912777888", "code": code, "password": "Other2026x",
                                             "password_confirm": "Other2026x"})
        self.assertIn("الرمز غير صحيح", r.get_data(as_text=True))
        # رقم غير مسجل: نفس الرسالة ولا تُرسل رسالة
        n = len(self.sent)
        tok = self.csrf(d2, "/forgot-password")
        d2.post("/forgot-password", data={"_csrf": tok, "phone": "0912999000"})
        self.assertEqual(len(self.sent), n)

    def test_2_pwa(self):
        c = self.app.test_client()
        self.assertEqual(c.get("/manifest.webmanifest").status_code, 200)
        self.assertEqual(c.get("/sw.js").headers.get("Service-Worker-Allowed"), "/")


class PortableBackupTest(unittest.TestCase):
    def test_export_restore_roundtrip(self):
        """تصدير JSON من قاعدة فيها بيانات، ثم استعادته في قاعدة جديدة (SQLite أو PostgreSQL) ومطابقة الأعداد."""
        from app.services.backup import TABLE_ORDER, export_json, restore_json
        tmp = tempfile.mkdtemp(prefix="qh-bk-")
        try:
            src = create_app(TestConfig, {"DATABASE_URL": f"sqlite:///{tmp}/src.db", "BACKUP_DIR": f"{tmp}/b"})
            with src.app_context():
                from app.db import get_db
                data = export_json()
                counts = {t: get_db().scalar(f"SELECT COUNT(*) AS n FROM {t}", (), 0) for t in TABLE_ORDER}
            open(f"{tmp}/b.json.zip", "wb").write(data)
            url = os.environ.get("QH_TEST_PG_URL")
            if url:
                from app.db import Database
                d = Database(url)
                d.execute("DROP SCHEMA IF EXISTS public CASCADE")
                d.execute("CREATE SCHEMA public")
                d.close()
            else:
                url = f"sqlite:///{tmp}/dst.db"
            dst = create_app(TestConfig, {"DATABASE_URL": url, "SEED_DEMO_DATA": False, "BACKUP_DIR": f"{tmp}/b2"})
            with dst.app_context():
                from app.db import get_db
                restore_json(f"{tmp}/b.json.zip")
                after = {t: get_db().scalar(f"SELECT COUNT(*) AS n FROM {t}", (), 0) for t in TABLE_ORDER}
                self.assertEqual(counts, after)
                self.assertGreater(after["donations"], 0)
                # بعد الاستعادة يمكن إضافة سجلات جديدة (التسلسلات مضبوطة)
                get_db().insert("governorates", {"name_ar": "ولاية بعد الاستعادة", "is_active": 0, "created_at": "2026-01-01 00:00:00"})
            c = dst.test_client()
            r = c.post("/login", data={"_csrf": re.search(r'name="_csrf" value="([^"]+)"', c.get("/login").get_data(as_text=True)).group(1),
                                       "phone": "0900000001", "password": "Demo@2026"}, follow_redirects=True)
            self.assertIn("لوحة التحكم", r.get_data(as_text=True))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_tasks_endpoint(self):
        tmp = tempfile.mkdtemp(prefix="qh-t-")
        try:
            app = create_app(TestConfig, {"DATABASE_URL": f"sqlite:///{tmp}/t.db", "TASKS_TOKEN": "tok-123"})
            c = app.test_client()
            self.assertEqual(c.get("/tasks/run").status_code, 404)
            self.assertEqual(c.get("/tasks/run?token=bad").status_code, 404)
            r = c.get("/tasks/run", headers={"X-Task-Token": "tok-123"})
            self.assertEqual(r.status_code, 200)
            self.assertIn("reminders", r.get_json())
            self.assertEqual(c.get("/ping").get_json(), {"ok": True})
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class AppReleaseTest(unittest.TestCase):
    def test_upload_and_download_apk(self):
        import zipfile
        tmp = tempfile.mkdtemp(prefix="qh-apk-")
        try:
            app = create_app(TestConfig, {"DATABASE_URL": f"sqlite:///{tmp}/a.db", "APP_FILES_DIR": f"{tmp}/app"})
            pub = app.test_client()
            self.assertEqual(pub.get("/app/qatrat-hayah.apk").status_code, 404)
            html = pub.get("/app").get_data(as_text=True)
            self.assertIn("حمّل تطبيق قطرة حياة", html)
            self.assertNotIn("تنزيل التطبيق لأندرويد", html)
            self.assertEqual(pub.get("/.well-known/assetlinks.json").get_json(), [])

            c = app.test_client()
            tok = re.search(r'name="_csrf" value="([^"]+)"', c.get("/login").get_data(as_text=True)).group(1)
            c.post("/login", data={"_csrf": tok, "phone": "0900000001", "password": "Demo@2026"})
            # الموظف لا يملك الصلاحية
            s = app.test_client()
            tok2 = re.search(r'name="_csrf" value="([^"]+)"', s.get("/login").get_data(as_text=True)).group(1)
            s.post("/login", data={"_csrf": tok2, "phone": "0900000006", "password": "Demo@2026"})
            self.assertEqual(s.get("/admin/app-release").status_code, 403)

            def csrf():
                return re.search(r'name="_csrf" value="([^"]+)"', c.get("/admin/app-release").get_data(as_text=True)).group(1)
            # ملف ليس APK
            r = c.post("/admin/app-release", data={"_csrf": csrf(), "action": "upload", "version": "1.0",
                                                   "apk": (io.BytesIO(b"x" * 20000), "fake.apk")},
                       content_type="multipart/form-data", follow_redirects=True)
            self.assertIn("ليس بصيغة APK", r.get_data(as_text=True))
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, "w") as z:
                z.writestr("AndroidManifest.xml", b"\x03\x00" * 500)
                z.writestr("classes.dex", os.urandom(30000))
                z.writestr("META-INF/CERT.RSA", b"sig")
            apk = buf.getvalue()
            r = c.post("/admin/app-release", data={"_csrf": csrf(), "action": "upload", "version": "1.0.0",
                                                   "apk": (io.BytesIO(apk), "app-release-signed.apk")},
                       content_type="multipart/form-data", follow_redirects=True)
            self.assertIn("تم نشر التطبيق", r.get_data(as_text=True))
            self.assertIn("تنزيل التطبيق لأندرويد", pub.get("/app").get_data(as_text=True))
            r = pub.get("/app/qatrat-hayah.apk")
            self.assertEqual(r.status_code, 200)
            self.assertEqual(r.mimetype, "application/vnd.android.package-archive")
            self.assertEqual(r.data, apk)
            r.close()
            # محاكاة إعادة تشغيل خادم بقرص مؤقت (Render المجاني): يُحذف مجلد الملفات بالكامل
            shutil.rmtree(f"{tmp}/app")
            self.assertIn("تنزيل التطبيق لأندرويد", pub.get("/app").get_data(as_text=True))
            r = pub.get("/app/qatrat-hayah.apk")
            self.assertEqual(r.status_code, 200)
            self.assertEqual(r.data, apk)
            r.close()
            links = '[{"relation":["delegate_permission/common.handle_all_urls"],"target":{"namespace":"android_app","package_name":"sd.qatrathayah.app","sha256_cert_fingerprints":["AA:BB"]}}]'
            c.post("/admin/app-release", data={"_csrf": csrf(), "action": "assetlinks", "assetlinks": links})
            self.assertEqual(pub.get("/.well-known/assetlinks.json").get_json()[0]["target"]["package_name"], "sd.qatrathayah.app")
            r = c.post("/admin/app-release", data={"_csrf": csrf(), "action": "assetlinks", "assetlinks": "not json"},
                       follow_redirects=True)
            self.assertIn("ليس JSON صحيحًا", r.get_data(as_text=True))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class CopyrightSettingTest(unittest.TestCase):
    def test_copyright_footer_and_settings_keep_assetlinks(self):
        tmp = tempfile.mkdtemp(prefix="qh-copy-")
        try:
            app = create_app(TestConfig, {"DATABASE_URL": f"sqlite:///{tmp}/c.db"})
            pub = app.test_client()
            self.assertIn("جميع الحقوق محفوظة — عبدالعظيم عبدالله جمعة", pub.get("/").get_data(as_text=True))

            c = app.test_client()
            tok = re.search(r'name="_csrf" value="([^"]+)"', c.get("/login").get_data(as_text=True)).group(1)
            c.post("/login", data={"_csrf": tok, "phone": "0900000001", "password": "Demo@2026"})

            def csrf(path):
                return re.search(r'name="_csrf" value="([^"]+)"', c.get(path).get_data(as_text=True)).group(1)
            links = '[{"relation":["delegate_permission/common.handle_all_urls"],"target":{"namespace":"android_app","package_name":"sd.qatrathayah.app","sha256_cert_fingerprints":["AA:BB"]}}]'
            c.post("/admin/app-release", data={"_csrf": csrf("/admin/app-release"), "action": "assetlinks", "assetlinks": links})

            html = c.get("/admin/settings").get_data(as_text=True)
            self.assertIn('value="عبدالعظيم عبدالله جمعة"', html)
            # حقوق الطبع تظهر أيضًا في صفحات لوحة الإدارة
            self.assertIn("جميع الحقوق محفوظة — عبدالعظيم عبدالله جمعة", c.get("/admin/").get_data(as_text=True))
            data = {"_csrf": csrf("/admin/settings"), "booking_window_days": "60", "reminder_hours_before": "24",
                    "default_critical_level": "3", "default_low_level": "8", "support_phone": "0912345678",
                    "public_registration": "1", "copyright_owner": "  اسم جديد للتجربة  "}
            r = c.post("/admin/settings", data=data, follow_redirects=True)
            self.assertIn("تم حفظ الإعدادات", r.get_data(as_text=True))
            self.assertIn("جميع الحقوق محفوظة — اسم جديد للتجربة", pub.get("/").get_data(as_text=True))
            # حفظ صفحة الإعدادات لا يمسح ملف ربط التطبيق
            self.assertEqual(pub.get("/.well-known/assetlinks.json").get_json()[0]["target"]["package_name"], "sd.qatrathayah.app")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
