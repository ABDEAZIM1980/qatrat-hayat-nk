"""فحص الواجهة على الهاتف واللوحي وسطح المكتب: لا تمرير أفقي، لا عناصر خارج الشاشة، RTL صحيح.

الاستخدام: python tests/responsive_check.py http://127.0.0.1:5000 [مجلد_اللقطات]
"""
import sys

from playwright.sync_api import sync_playwright

BASE = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5000"
OUT = sys.argv[2] if len(sys.argv) > 2 else None
VIEWPORTS = {"mobile": (360, 740), "tablet": (820, 1180), "desktop": (1366, 850)}
PUBLIC = ["/", "/centers", "/centers/1", "/appeals", "/how-to-donate", "/awareness", "/awareness/article-1", "/about",
          "/login", "/register", "/forgot-password", "/offline", "/app"]
DONOR = ["/donor/", "/donor/appointments/new?center_id=1", "/donor/appointments", "/donor/donations", "/donor/notifications",
         "/donor/settings", "/donor/profile", "/donor/card", "/donor/certificate"]
ADMIN = ["/admin/", "/admin/appointments?range=upcoming", "/admin/inventory", "/admin/inventory/1", "/admin/requests",
         "/admin/requests/1", "/admin/appeals", "/admin/donors", "/admin/donors/1", "/admin/centers", "/admin/centers/1",
         "/admin/users", "/admin/reports?report=donations", "/admin/audit", "/admin/geography/localities/1", "/admin/settings", "/admin/import/centers", "/admin/app-release"]

CHECK_JS = """() => {
  const de = document.documentElement;
  const vw = de.clientWidth;
  const off = [];
  document.querySelectorAll('body *').forEach(el => {
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return;
    if (el.closest('.scroll-x, .days, details:not([open]), .menu-panel')) return;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return;
    if (r.right > vw + 1 || r.left < -1) off.push((el.className || el.tagName) + ' ' + Math.round(r.left) + '..' + Math.round(r.right));
  });
  return {dir: de.getAttribute('dir'), scrollW: de.scrollWidth, vw, off: off.slice(0, 5)};
}"""


def login(page, phone):
    page.goto(BASE + "/login")
    page.fill("#f-phone", phone)
    page.fill("#f-password", "Demo@2026")
    page.click("button[type=submit].btn-primary")
    page.wait_for_load_state("networkidle")


def main():
    problems = 0
    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--no-sandbox"])
        for vp, (w, h) in VIEWPORTS.items():
            for who, pages in (("public", PUBLIC), ("donor", DONOR), ("admin", ADMIN)):
                ctx = browser.new_context(viewport={"width": w, "height": h}, locale="ar", device_scale_factor=1,
                                          is_mobile=(vp == "mobile"), has_touch=(vp != "desktop"))
                page = ctx.new_page()
                if who == "donor":
                    login(page, "0911000001")
                elif who == "admin":
                    login(page, "0900000001")
                for path in pages:
                    page.goto(BASE + path)
                    page.wait_for_load_state("networkidle")
                    res = page.evaluate(CHECK_JS)
                    bad = res["dir"] != "rtl" or res["scrollW"] > res["vw"] + 1 or res["off"]
                    if bad:
                        problems += 1
                        print(f"[{vp}] {path}: dir={res['dir']} scrollW={res['scrollW']} vw={res['vw']} off={res['off']}")
                    if OUT:
                        name = f"{vp}_{who}_{path.strip('/').replace('/', '_').replace('?', '_').replace('=', '-') or 'home'}.png"
                        page.screenshot(path=f"{OUT}/{name}", full_page=True)
                ctx.close()
        browser.close()
    print("problems:", problems)
    return problems


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
