"""تعديل رقم هاتف المستخدم الإداري وحذف المستخدمين."""
import re

from tests.helpers import Base


class UserAdminTest(Base):
    def _create(self, name, phone, role="center_staff", **scope):
        r = self.post("/admin/users/new", {"full_name": name, "phone": phone, "role": role, **scope})
        m = re.search(r"<code[^>]*>([^<]+)</code>", r.get_data(as_text=True))
        self.assertTrue(m)
        db = self.db()
        return db.scalar("SELECT id FROM users WHERE phone = ?", ("+249" + phone[1:],)), m.group(1).strip()

    def _center(self):
        return self.db().scalar("SELECT center_id FROM user_roles ur JOIN users u ON u.id = ur.user_id WHERE u.phone = '+249900000005'")

    def test_change_phone(self):
        self.login("super_admin")
        uid, pw = self._create("موظف لتغيير الرقم", "0912400001", scope_center_id=self._center())
        page = self.c.get(f"/admin/users/{uid}").get_data(as_text=True)
        self.assertIn('value="0912400001"', page)
        # رقم مستخدم آخر مرفوض
        r = self.post(f"/admin/users/{uid}", {"full_name": "موظف لتغيير الرقم", "phone": "0900000005", "status": "active"})
        self.assertIn("هذا الرقم مسجل لمستخدم آخر", r.get_data(as_text=True))
        r = self.post(f"/admin/users/{uid}", {"full_name": "موظف لتغيير الرقم", "phone": "0912400002", "status": "active"})
        self.assertIn("رقم الدخول الجديد: 0912400002", r.get_data(as_text=True))
        # الدخول بالرقم الجديد يعمل والقديم لا يعمل
        c = self.app.test_client()
        r = self.post("/login", {"phone": "0912400001", "password": pw}, client=c)
        self.assertIn("غير صحيحة", r.get_data(as_text=True))
        r = self.post("/login", {"phone": "0912400002", "password": pw}, client=c)
        self.assertNotIn("غير صحيحة", r.get_data(as_text=True))

    def test_delete_without_activity_is_permanent(self):
        self.login("super_admin")
        uid, _ = self._create("حساب أنشئ بالخطأ", "0912400010", scope_center_id=self._center())
        r = self.post(f"/admin/users/{uid}/delete")
        self.assertIn("نهائيًا", r.get_data(as_text=True))
        self.assertIsNone(self.db().one("SELECT id FROM users WHERE id = ?", (uid,)))
        # يمكن إعادة استخدام الرقم
        self._create("حساب جديد بنفس الرقم", "0912400010", scope_center_id=self._center())

    def test_delete_with_activity_is_archived(self):
        self.login("super_admin")
        uid, pw = self._create("موظف له عمليات", "0912400020", scope_center_id=self._center())
        db = self.db()
        don = db.one("SELECT id FROM donations LIMIT 1")
        db.execute("UPDATE donations SET recorded_by = ? WHERE id = ?", (uid, don["id"]))
        r = self.post(f"/admin/users/{uid}/delete")
        self.assertIn("عملياته السابقة بقيت مسجلة باسمه", r.get_data(as_text=True))
        row = db.one("SELECT * FROM users WHERE id = ?", (uid,))
        self.assertEqual(row["status"], "disabled")
        self.assertIn("(محذوف)", row["full_name"])
        self.assertFalse(db.scalar("SELECT COUNT(*) AS n FROM user_roles WHERE user_id = ?", (uid,)))
        self.assertNotIn("موظف له عمليات", self.c.get("/admin/users").get_data(as_text=True))
        c = self.app.test_client()
        self.assertIn("غير صحيحة", self.post("/login", {"phone": "0912400020", "password": pw}, client=c).get_data(as_text=True))
        # الرقم أصبح متاحًا لحساب جديد
        self._create("موظف جديد", "0912400020", scope_center_id=self._center())

    def test_delete_guards(self):
        self.login("super_admin")
        me = self.db().scalar("SELECT id FROM users WHERE phone = '+249900000001'")
        r = self.post(f"/admin/users/{me}/delete")
        self.assertIn("لا يمكنك حذف حسابك بنفسك", r.get_data(as_text=True))
        # مدير بنك الدم لا يستطيع حذف مدير الولاية (رتبة أعلى)
        c = self.app.test_client()
        self.login("center_manager", client=c)
        sm = self.db().scalar("SELECT id FROM users WHERE phone = '+249900000003'")
        self.assertIn(self.post(f"/admin/users/{sm}/delete", client=c, follow=False).status_code, (403, 404))
        self.assertTrue(self.db().one("SELECT id FROM users WHERE id = ?", (sm,)))
