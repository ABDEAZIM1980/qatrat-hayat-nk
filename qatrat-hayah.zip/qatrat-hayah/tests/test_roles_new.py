"""الدوران الجديدان: مدير النظام للولاية، ومشرف بنك الدم."""
import re

from tests.helpers import Base


class NewRolesTest(Base):
    def _create(self, client, name, phone, role, **scope):
        r = self.post("/admin/users/new", {"full_name": name, "phone": phone, "role": role, **scope}, client=client)
        html = r.get_data(as_text=True)
        m = re.search(r"<code[^>]*>([^<]+)</code>", html)
        self.assertTrue(m, html[html.find("<main"):html.find("<main") + 1500])
        return m.group(1).strip()

    def _login_as(self, phone, pw):
        c = self.app.test_client()
        r = self.post("/login", {"phone": phone, "password": pw}, client=c)
        self.assertNotIn("غير صحيحة", r.get_data(as_text=True))
        return c

    def test_state_admin_and_bank_supervisor(self):
        db = self.db()
        nk = db.scalar("SELECT id FROM governorates WHERE code = 'NK'")
        other_gov = db.scalar("SELECT id FROM governorates WHERE code != 'NK' ORDER BY id LIMIT 1")
        main_center = db.scalar("SELECT center_id FROM user_roles ur JOIN users u ON u.id = ur.user_id WHERE u.phone = '+249900000005'")
        self.login("super_admin")
        page = self.c.get("/admin/users/new").get_data(as_text=True)
        self.assertIn("مدير النظام للولاية", page)
        self.assertIn("مشرف بنك الدم", page)

        pw = self._create(self.c, "مدير نظام الولاية التجريبي", "0912300001", "state_admin", scope_governorate_id=nk)
        sa = self._login_as("0912300001", pw)
        # يدير مراكز ولايته ويرى لوحة الإدارة، ولا يصل لإعدادات المنصة
        self.assertEqual(sa.get("/admin/centers").status_code, 200)
        self.assertEqual(sa.get("/admin/settings").status_code, 403)
        self.assertEqual(sa.get("/admin/monthly-reports/summary").status_code, 200)
        # لا يستطيع إسناد دور في ولاية أخرى، ولا إنشاء مدير نظام ولاية آخر (نفس رتبته)
        r = self.post("/admin/users/new", {"full_name": "حساب خارج النطاق", "phone": "0912300009", "role": "state_manager",
                                           "scope_governorate_id": other_gov}, client=sa)
        self.assertIn("خارج نطاق صلاحياتك", r.get_data(as_text=True))
        r = self.post("/admin/users/new", {"full_name": "مدير نظام آخر", "phone": "0912300008", "role": "state_admin",
                                           "scope_governorate_id": nk}, client=sa)
        self.assertNotIn("<code", r.get_data(as_text=True))

        # مدير النظام للولاية ينشئ مشرف بنك دم مربوطًا بمركزه
        pw2 = self._create(sa, "مشرف بنك الدم التجريبي", "0912300002", "bank_supervisor", scope_center_id=main_center)
        sup = self._login_as("0912300002", pw2)
        self.assertEqual(sup.get("/admin/users").status_code, 403)          # لا يدير الحسابات
        page = sup.get("/admin/monthly-reports?year=2025&month=8").get_data(as_text=True)
        self.assertIn("إعداد التقرير", page)
        self.assertEqual(page.count("إعداد التقرير"), 1)                     # بنكه فقط
        r = self.post("/admin/monthly-reports/new", {"center_id": main_center, "year": 2025, "month": 8}, client=sup, follow=False)
        rid = int(r.headers["Location"].rsplit("/", 1)[1])
        r = self.post(f"/admin/monthly-reports/{rid}", {"action": "submit", "dept_count": "0", "camp_count": "0",
                                                        "tti__HIV__rapid__n": "10"}, client=sup)
        self.assertIn("تم إرسال التقرير للمراجعة", r.get_data(as_text=True))
        # مدير النظام للولاية يصله إشعار ويعتمد التقرير
        sa_id = db.scalar("SELECT id FROM users WHERE phone = '+249912300001'")
        self.assertTrue(db.scalar("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND category = 'monthly_report'", (sa_id,)))
        self.post(f"/admin/monthly-reports/{rid}/review", {"action": "accept"}, client=sa)
        self.assertEqual(db.scalar("SELECT status FROM monthly_reports WHERE id = ?", (rid,)), "accepted")
        # مشرف بنك الدم لا يرى بنك دم آخر
        other_center = db.scalar("SELECT id FROM blood_centers WHERE id != ? ORDER BY id LIMIT 1", (main_center,))
        self.assertEqual(sup.get(f"/admin/inventory/{other_center}").status_code, 403)
