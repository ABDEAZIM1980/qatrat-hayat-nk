"""زحف على كل الصفحات لكل دور: لا توجد أخطاء 500 ولا قيم تقنية ظاهرة."""
import re

from tests.helpers import Base

ADMIN_PAGES = ["/admin/", "/admin/search?q=مح", "/admin/appointments", "/admin/appointments?range=upcoming",
               "/admin/appointments?range=past", "/admin/donations", "/admin/donations/new", "/admin/donations/new?lookup=D-DEMO001",
               "/admin/inventory", "/admin/inventory/1", "/admin/requests", "/admin/requests?status=all", "/admin/requests/new",
               "/admin/requests/1", "/admin/appeals", "/admin/appeals/new", "/admin/appeals/1", "/admin/appeals/2", "/admin/donors",
               "/admin/donors/new", "/admin/centers", "/admin/centers/new", "/admin/centers/1", "/admin/centers/1/edit",
               "/admin/geography/governorates", "/admin/geography/localities/1", "/admin/geography/cities/1",
               "/admin/geography/governorates/edit/1", "/admin/users", "/admin/users/new", "/admin/content", "/admin/content/new",
               "/admin/content/1/edit", "/admin/notifications", "/admin/reports", "/admin/audit", "/admin/settings"]
DONOR_PAGES = ["/donor/", "/donor/profile", "/donor/appointments", "/donor/appointments/new", "/donor/donations",
               "/donor/notifications", "/donor/settings"]
BAD = re.compile(r">\s*-0\s*<|>\s*0-\s*<|\bNone\b|\bnan\b|Traceback|undefined")


class CrawlTest(Base):
    def check(self, url, allowed=(200, 403, 404)):
        r = self.c.get(url)
        self.assertIn(r.status_code, allowed, f"{url} -> {r.status_code}")
        if r.status_code == 200 and "text/html" in r.content_type:
            html = r.get_data(as_text=True)
            m = BAD.search(html)
            self.assertIsNone(m, f"{url} shows technical value: {m.group(0) if m else ''}")
        return r

    def test_public(self):
        for u in ["/", "/centers", "/centers?governorate_id=1", "/centers?lat=13.18&lon=30.21", "/centers/1", "/appeals",
                  "/appeals/1", "/how-to-donate", "/awareness", "/awareness?category=myths", "/awareness/article-1", "/about",
                  "/privacy", "/login", "/register"]:
            self.assertEqual(self.check(u).status_code, 200, u)

    def test_all_roles(self):
        for role in ["super_admin", "general_admin", "state_manager", "locality_manager", "center_manager", "center_staff"]:
            with self.subTest(role=role):
                self.c = self.app.test_client()
                self.login(role)
                for u in ADMIN_PAGES:
                    self.check(u)
                self.assertEqual(self.c.get("/admin/").status_code, 200)

    def test_donor(self):
        self.login("donor")
        for u in DONOR_PAGES:
            self.assertEqual(self.check(u).status_code, 200, u)
        self.assertEqual(self.c.get("/admin/").status_code, 403)
