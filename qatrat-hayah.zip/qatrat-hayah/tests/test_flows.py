"""اختبارات السيناريوهات المطلوبة في وثيقة المشروع (القسم السادس والعشرون)."""
import re

from tests.helpers import Base


class FlowTests(Base):
    # ---------- أدوات ----------
    def q(self, sql, params=()):
        with self.app.app_context():
            db = self.db()
            try:
                return db.query(sql, params)
            finally:
                db.close()

    def one(self, sql, params=()):
        rows = self.q(sql, params)
        return rows[0] if rows else None

    def register(self, phone="0912345678", name="متبرع اختبار جديد", bt="A+"):
        loc = self.one("SELECT id, governorate_id FROM localities WHERE name_ar = 'شيكان'")
        return self.post("/register", {
            "full_name": name, "phone": phone, "password": "Test1234", "password_confirm": "Test1234",
            "blood_type": bt, "governorate_id": loc["governorate_id"], "locality_id": loc["id"], "consent": "1"})

    def next_slot(self, center_id=1):
        with self.app.app_context():
            from app.services.appointments import available_slots, open_days
            for d in open_days(center_id, 14):
                s = available_slots(center_id, d["date"])
                if s:
                    return d["date"], s[-1]["time"]
        self.fail("no slot")

    # ---------- 1-3: تسجيل مستخدم/متبرع ودخول وخروج ----------
    def test_01_register_login_logout(self):
        r = self.register()
        self.assertIn("تم إنشاء حسابك بنجاح", r.get_data(as_text=True))
        u = self.one("SELECT * FROM users WHERE phone = '+249912345678'")
        self.assertTrue(u["password_hash"].startswith("scrypt:"), "password must be hashed")
        d = self.one("SELECT * FROM donors WHERE user_id = ?", (u["id"],))
        self.assertEqual(d["blood_type"], "A+")
        self.assertEqual(self.one("SELECT COUNT(*) AS n FROM donor_profiles WHERE donor_id = ?", (d["id"],))["n"], 1)
        # تسجيل مكرر
        c2 = self.app.test_client()
        r = self.post("/register", {"full_name": "شخص آخر مكرر", "phone": "0912345678", "password": "Test1234",
                                    "password_confirm": "Test1234", "governorate_id": 1, "locality_id": 1, "consent": "1"}, client=c2)
        self.assertIn("مسجل مسبقًا", r.get_data(as_text=True))
        # خروج ثم دخول
        r = self.post("/logout", {}, follow=True)
        self.assertIn("تم تسجيل الخروج", r.get_data(as_text=True))
        self.assertEqual(self.c.get("/donor/").status_code, 302)
        r = self.post("/login", {"phone": "0912345678", "password": "Test1234"})
        self.assertIn("مرحبًا", r.get_data(as_text=True))
        self.assertTrue(self.one("SELECT 1 AS x FROM audit_logs WHERE action = 'login' AND user_id = ?", (u["id"],)))

    def test_02_login_failures_and_lockout(self):
        for _ in range(5):
            r = self.post("/login", {"phone": "0911000002", "password": "wrong-pass1"})
            self.assertIn("غير صحيحة", r.get_data(as_text=True))
        r = self.post("/login", {"phone": "0911000002", "password": "Demo@2026"})
        self.assertIn("إيقاف الدخول مؤقتًا", r.get_data(as_text=True))
        # رقم غير موجود لا يكشف وجود الحساب
        r = self.post("/login", {"phone": "0999999999", "password": "whatever1"})
        self.assertIn("رقم الهاتف أو كلمة المرور غير صحيحة", r.get_data(as_text=True))

    def test_03_validation_rejects_bad_values(self):
        r = self.post("/register", {"full_name": "ab", "phone": "12345", "password": "short", "password_confirm": "x",
                                    "governorate_id": "-0", "locality_id": "0-", "consent": ""})
        html = r.get_data(as_text=True)
        for msg in ["رقم الهاتف غير صحيح", "كلمة المرور يجب ألا تقل", "يجب الموافقة"]:
            self.assertIn(msg, html)

    # ---------- 4: تعديل الملف ----------
    def test_04_edit_profile(self):
        self.login("0911000003")
        d = self.one("SELECT d.* FROM donors d JOIN users u ON u.id = d.user_id WHERE u.phone = '+249911000003'")
        r = self.post("/donor/profile", {"full_name": "اسم معدل للاختبار", "email": "t4@example.com",
                                         "blood_type": d["blood_type"] or "unknown", "governorate_id": d["governorate_id"],
                                         "locality_id": d["locality_id"], "gender": "male", "birth_year": "1990"})
        self.assertIn("تم حفظ التعديلات", r.get_data(as_text=True))
        self.assertEqual(self.one("SELECT full_name FROM users WHERE phone = '+249911000003'")["full_name"], "اسم معدل للاختبار")
        self.assertTrue(self.one("SELECT 1 AS x FROM audit_logs WHERE action = 'donor_update' AND entity_id = ?", (d["id"],)))

    # ---------- 5-7: حجز، تعديل، إلغاء ----------
    def test_05_book_reschedule_cancel(self):
        self.register(phone="0912000005")
        day, t = self.next_slot(1)
        r = self.post("/donor/appointments/new", {"center_id": 1, "date": day, "time": t})
        self.assertIn("يرجى تأكيد الاطلاع", r.get_data(as_text=True))  # الإقرار إلزامي
        r = self.post("/donor/appointments/new", {"center_id": 1, "date": day, "time": t, "ack": "1"})
        self.assertIn("تم حجز موعدك بنجاح", r.get_data(as_text=True))
        self.assertIn("حجز الموعد لا يُعد دليلاً على الأهلية الطبية", r.get_data(as_text=True))
        a = self.one("SELECT a.* FROM appointments a JOIN donors d ON d.id = a.donor_id JOIN users u ON u.id = d.user_id "
                     "WHERE u.phone = '+249912000005'")
        self.assertEqual(a["status"], "booked")
        # إشعار المتبرع وإشعار المركز
        self.assertTrue(self.one("SELECT 1 AS x FROM notifications WHERE category = 'appointment_confirmed' AND link = ?",
                                 (f"/donor/appointments/{a['id']}",)))
        self.assertTrue(self.one("SELECT 1 AS x FROM notifications WHERE category = 'center' AND link = ?",
                                 (f"/admin/appointments/{a['id']}",)))
        # لا يمكن حجز موعد ثانٍ
        r = self.post("/donor/appointments/new", {"center_id": 1, "date": day, "time": t, "ack": "1"})
        self.assertIn("لديك موعد قائم", r.get_data(as_text=True))
        # وقت غير متاح
        r = self.post(f"/donor/appointments/{a['id']}/edit", {"center_id": 1, "date": day, "time": "03:00"})
        self.assertIn("غير متاح", r.get_data(as_text=True))
        # تعديل
        with self.app.app_context():
            from app.services.appointments import available_slots
            t2 = available_slots(1, day, a["id"])[0]["time"]
        r = self.post(f"/donor/appointments/{a['id']}/edit", {"center_id": 1, "date": day, "time": t2})
        self.assertIn("تم تعديل موعدك", r.get_data(as_text=True))
        self.assertEqual(str(self.one("SELECT appointment_time FROM appointments WHERE id = ?", (a["id"],))["appointment_time"])[:5], t2)
        # إلغاء
        r = self.post(f"/donor/appointments/{a['id']}/cancel", {"reason": "ظرف طارئ"})
        self.assertIn("تم إلغاء الموعد", r.get_data(as_text=True))
        self.assertEqual(self.one("SELECT status FROM appointments WHERE id = ?", (a["id"],))["status"], "cancelled")
        # متبرع آخر لا يرى هذا الموعد
        other = self.app.test_client()
        self.login("0911000004", client=other)
        self.assertEqual(other.get(f"/donor/appointments/{a['id']}").status_code, 404)

    # ---------- 8-9: التقييم الطبي، تسجيل واعتماد التبرع ----------
    def test_06_assessment_donation_approval_updates_inventory(self):
        self.register(phone="0912000006", bt="B+")
        day, t = self.next_slot(1)
        self.post("/donor/appointments/new", {"center_id": 1, "date": day, "time": t, "ack": "1"})
        a = self.one("SELECT a.* FROM appointments a JOIN donors d ON d.id = a.donor_id JOIN users u ON u.id = d.user_id "
                     "WHERE u.phone = '+249912000006'")
        staff = self.app.test_client()
        self.login("center_staff", client=staff)
        # لا يمكن تسجيل تبرع قبل الحضور والتقييم
        r = self.post(f"/admin/appointments/{a['id']}/donation", {"blood_type": "B+", "volume_ml": "450"}, client=staff)
        self.assertIn("لا يمكن تسجيل تبرع", r.get_data(as_text=True))
        self.post(f"/admin/appointments/{a['id']}/status", {"status": "checked_in"}, client=staff)
        r = self.post(f"/admin/appointments/{a['id']}/donation", {"blood_type": "B+", "volume_ml": "450"}, client=staff)
        self.assertIn("قرار المختص بقبول", r.get_data(as_text=True))
        r = self.post(f"/admin/appointments/{a['id']}/assessment",
                      {"decision": "accepted", "assessed_by_name": "د. مختص الاختبار"}, client=staff)
        self.assertIn("تم تسجيل قرار المختص", r.get_data(as_text=True))
        r = self.post(f"/admin/appointments/{a['id']}/donation", {"blood_type": "B+", "volume_ml": "450"}, client=staff)
        self.assertIn("بانتظار الفحص والاعتماد", r.get_data(as_text=True))
        x = self.one("SELECT * FROM donations WHERE appointment_id = ?", (a["id"],))
        self.assertEqual(x["status"], "pending")
        self.assertEqual(self.one("SELECT status FROM appointments WHERE id = ?", (a["id"],))["status"], "completed")
        # الموظف لا يملك صلاحية الاعتماد
        self.assertEqual(self.post(f"/admin/donations/{x['id']}/approve", {}, client=staff, follow=False).status_code, 403)
        before = self.one("SELECT available_units FROM blood_inventory WHERE center_id = 1 AND blood_type = 'B+'")["available_units"]
        mgr = self.app.test_client()
        self.login("center_manager", client=mgr)
        r = self.post(f"/admin/donations/{x['id']}/approve", {}, client=mgr)
        self.assertIn("تم اعتماد الوحدة", r.get_data(as_text=True))
        after = self.one("SELECT available_units FROM blood_inventory WHERE center_id = 1 AND blood_type = 'B+'")["available_units"]
        self.assertEqual(after, before + 1)
        d = self.one("SELECT * FROM donors WHERE id = ?", (a["donor_id"],))
        self.assertEqual(d["donations_count"], 1)
        self.assertEqual(d["blood_type_verified"], 1)
        self.assertIsNotNone(d["last_donation_at"])
        self.assertTrue(self.one("SELECT 1 AS x FROM notifications n JOIN donors d ON d.user_id = n.user_id "
                                 "WHERE d.id = ? AND n.category = 'donation_approved'", (d["id"],)))
        self.assertTrue(self.one("SELECT 1 AS x FROM blood_inventory_transactions WHERE reference_type = 'donation' AND reference_id = ?",
                                 (x["id"],)))
        # اعتماد مزدوج مرفوض
        r = self.post(f"/admin/donations/{x['id']}/approve", {}, client=mgr)
        self.assertIn("تمت معالجة هذه الوحدة مسبقًا", r.get_data(as_text=True))

    def test_07_deferral_is_recorded_not_decided(self):
        a = self.one("SELECT id FROM appointments WHERE status IN ('booked','confirmed') AND center_id = 1 LIMIT 1")
        staff = self.app.test_client()
        self.login("center_staff", client=staff)
        self.post(f"/admin/appointments/{a['id']}/status", {"status": "checked_in"}, client=staff)
        r = self.post(f"/admin/appointments/{a['id']}/assessment", {"decision": "deferred", "assessed_by_name": "د. مختص"},
                      client=staff)
        self.assertIn("تعذر الحفظ", r.get_data(as_text=True))  # السبب مطلوب
        r = self.post(f"/admin/appointments/{a['id']}/assessment",
                      {"decision": "deferred", "assessed_by_name": "د. مختص", "reason": "قرار المختص"}, client=staff)
        self.assertEqual(self.one("SELECT status FROM appointments WHERE id = ?", (a["id"],))["status"], "deferred")

    def test_08_walk_in_donation(self):
        staff = self.app.test_client()
        self.login("center_staff", client=staff)
        r = self.post("/admin/donors/new", {"full_name": "متبرع حاضر بالمركز", "phone": "0912000008",
                                            "governorate_id": 1, "locality_id": 1, "preferred_center_id": 1,
                                            "blood_type": "unknown"}, client=staff)
        self.assertIn("كلمة المرور المؤقتة", r.get_data(as_text=True))
        r = self.post("/admin/donations/new?lookup=0912000008", {"lookup": "0912000008", "confirm_step": "1", "center_id": 1,
                                                                 "blood_type": "O-", "volume_ml": "450",
                                                                 "assessed_by_name": "د. مختص", "accepted": "1"}, client=staff)
        self.assertIn("تم تسجيل التبرع", r.get_data(as_text=True))

    # ---------- 10: طلب دم ----------
    def test_09_blood_request_lifecycle(self):
        staff = self.app.test_client()
        self.login("center_staff", client=staff)
        r = self.post("/admin/requests/new", {"center_id": 1, "blood_type": "O+", "units_required": "-0", "urgency": "urgent",
                                              "requesting_entity": "قسم الطوارئ"}, client=staff)
        self.assertIn("رقمًا صحيحًا موجبًا", r.get_data(as_text=True))
        r = self.post("/admin/requests/new", {"center_id": 1, "blood_type": "O+", "units_required": "0", "urgency": "urgent",
                                              "requesting_entity": "قسم الطوارئ"}, client=staff)
        self.assertIn("يجب ألا يقل عن 1", r.get_data(as_text=True))
        r = self.post("/admin/requests/new", {"center_id": 1, "blood_type": "O+", "units_required": "2", "urgency": "bogus",
                                              "requesting_entity": "قسم الطوارئ"}, client=staff)
        self.assertIn("غير صالحة", r.get_data(as_text=True))
        r = self.post("/admin/requests/new", {"center_id": 1, "blood_type": "O+", "units_required": "2", "urgency": "critical",
                                              "requesting_entity": "قسم الطوارئ", "patient_reference": "ملف 12"}, client=staff)
        self.assertIn("بانتظار الاعتماد", r.get_data(as_text=True))
        req = self.one("SELECT * FROM blood_requests ORDER BY id DESC LIMIT 1")
        # الموظف لا يعتمد
        self.assertEqual(self.post(f"/admin/requests/{req['id']}/action", {"action": "approve"}, client=staff,
                                   follow=False).status_code, 403)
        mgr = self.app.test_client()
        self.login("center_manager", client=mgr)
        self.post(f"/admin/requests/{req['id']}/action", {"action": "approve"}, client=mgr)
        self.assertEqual(self.one("SELECT status FROM blood_requests WHERE id = ?", (req["id"],))["status"], "approved")
        before = self.one("SELECT available_units FROM blood_inventory WHERE center_id = 1 AND blood_type = 'O+'")["available_units"]
        r = self.post(f"/admin/requests/{req['id']}/action", {"action": "fulfill", "issue_center_id": 1,
                                                              "issue_blood_type": "O+", "units": "2"}, client=mgr)
        self.assertIn("يجب تأكيد", r.get_data(as_text=True))
        r = self.post(f"/admin/requests/{req['id']}/action", {"action": "fulfill", "issue_center_id": 1,
                                                              "issue_blood_type": "O+", "units": "2", "lab_confirm": "1"}, client=mgr)
        self.assertEqual(self.one("SELECT status FROM blood_requests WHERE id = ?", (req["id"],))["status"], "fulfilled")
        after = self.one("SELECT available_units FROM blood_inventory WHERE center_id = 1 AND blood_type = 'O+'")["available_units"]
        self.assertEqual(after, before - 2)

    # ---------- 11: نداء عاجل ----------
    def test_10_emergency_appeal_requires_approval(self):
        staff = self.app.test_client()
        self.login("center_staff", client=staff)
        r = self.post("/admin/appeals/new", {"center_id": 1, "title": "احتياج عاجل للدم", "blood_type": "A+",
                                             "units_needed": "5", "urgency": "critical", "publish_now": "1"}, client=staff)
        self.assertIn("بانتظار الاعتماد قبل النشر", r.get_data(as_text=True))
        ap = self.one("SELECT * FROM emergency_appeals ORDER BY id DESC LIMIT 1")
        self.assertEqual(ap["status"], "pending_approval")
        # لا يظهر للجمهور قبل الاعتماد
        self.assertEqual(self.app.test_client().get(f"/appeals/{ap['id']}").status_code, 404)
        self.assertEqual(self.post(f"/admin/appeals/{ap['id']}/action", {"action": "publish"}, client=staff,
                                   follow=False).status_code, 403)
        mgr = self.app.test_client()
        self.login("center_manager", client=mgr)
        r = self.post(f"/admin/appeals/{ap['id']}/action", {"action": "publish"}, client=mgr)
        self.assertIn("تم اعتماد النداء ونشره", r.get_data(as_text=True))
        self.assertEqual(self.app.test_client().get(f"/appeals/{ap['id']}").status_code, 200)
        n = self.one("SELECT COUNT(*) AS n FROM notifications WHERE category = 'emergency_appeal' AND link = ?",
                     (f"/appeals/{ap['id']}",))["n"]
        expected = self.one("SELECT COUNT(*) AS n FROM donors d JOIN donor_profiles p ON p.donor_id = d.id "
                            "WHERE d.blood_type = 'A+' AND d.status = 'active' AND p.notify_emergency = 1")["n"]
        self.assertEqual(n, expected)
        self.post(f"/admin/appeals/{ap['id']}/action", {"action": "progress", "units_collected": "5", "new_status": "open"}, client=mgr)
        self.assertEqual(self.one("SELECT status FROM emergency_appeals WHERE id = ?", (ap["id"],))["status"], "completed")

    # ---------- 12: المخزون ----------
    def test_11_inventory_management(self):
        mgr = self.app.test_client()
        self.login("center_manager", client=mgr)
        row = self.one("SELECT * FROM blood_inventory WHERE center_id = 1 AND blood_type = 'AB-'")
        r = self.post("/admin/inventory/1", {"action": "tx", "blood_type": "AB-", "tx_type": "issue_out",
                                             "quantity": str(row["available_units"] + 50), "reason": "اختبار"}, client=mgr)
        self.assertIn("أقل من المطلوب", r.get_data(as_text=True))
        self.post("/admin/inventory/1", {"action": "count", "blood_type": "AB-", "counted": "7", "reason": "جرد اختبار"}, client=mgr)
        self.assertEqual(self.one("SELECT available_units FROM blood_inventory WHERE id = ?", (row["id"],))["available_units"], 7)
        self.post("/admin/inventory/1", {"action": "tx", "blood_type": "AB-", "tx_type": "reserve", "quantity": "2",
                                         "reason": "حجز"}, client=mgr)
        x = self.one("SELECT * FROM blood_inventory WHERE id = ?", (row["id"],))
        self.assertEqual((x["available_units"], x["reserved_units"]), (5, row["reserved_units"] + 2))
        self.post("/admin/inventory/1", {"action": "tx", "blood_type": "AB-", "tx_type": "transfer_out", "quantity": "1",
                                         "target_center_id": "3", "reason": "دعم مركز"}, client=mgr)
        self.assertEqual(self.one("SELECT available_units FROM blood_inventory WHERE id = ?", (row["id"],))["available_units"], 4)
        self.assertTrue(self.one("SELECT 1 AS x FROM blood_inventory_transactions WHERE center_id = 3 AND tx_type = 'transfer_in'"))
        self.assertTrue(self.one("SELECT 1 AS x FROM audit_logs WHERE action = 'inventory_adjust'"))
        # مدير مركز أم روابة لا يدير مخزون الأبيض
        other = self.app.test_client()
        self.login("umr_manager", client=other)
        self.assertEqual(other.get("/admin/inventory/1").status_code, 403)

    # ---------- 13-15: مركز، ولاية، محلية ----------
    def test_12_add_governorate_locality_center(self):
        admin = self.app.test_client()
        self.login("general_admin", client=admin)
        self.post("/admin/geography/governorates", {"name_ar": "ولاية اختبار", "name_en": "Test State", "code": "tx",
                                                    "is_active": "1"}, client=admin)
        g = self.one("SELECT * FROM governorates WHERE name_ar = 'ولاية اختبار'")
        self.assertEqual(g["code"], "TX")
        r = self.post("/admin/geography/governorates", {"name_ar": "ولاية اختبار", "is_active": "1"}, client=admin)
        self.assertIn("موجود مسبقًا", r.get_data(as_text=True))
        self.post(f"/admin/geography/localities/{g['id']}", {"name_ar": "محلية اختبار", "is_active": "1"}, client=admin)
        loc = self.one("SELECT * FROM localities WHERE name_ar = 'محلية اختبار'")
        self.post(f"/admin/geography/cities/{loc['id']}", {"name_ar": "مدينة اختبار", "is_active": "1"}, client=admin)
        city = self.one("SELECT * FROM cities WHERE name_ar = 'مدينة اختبار'")
        r = self.post("/admin/centers/new", {"name": "مركز اختبار", "center_type": "blood_bank", "governorate_id": g["id"],
                                             "locality_id": loc["id"], "city_id": city["id"], "phone": "0912000099",
                                             "latitude": "15.5", "longitude": "32.5", "accepts_appointments": "1"}, client=admin)
        self.assertIn("تمت إضافة المركز", r.get_data(as_text=True))
        c = self.one("SELECT * FROM blood_centers WHERE name = 'مركز اختبار'")
        self.assertEqual(self.one("SELECT COUNT(*) AS n FROM blood_inventory WHERE center_id = ?", (c["id"],))["n"], 8)
        self.assertTrue(self.one("SELECT 1 AS x FROM blood_banks WHERE center_id = ?", (c["id"],)))
        # يظهر للجمهور فورًا في الولاية الجديدة
        html = self.app.test_client().get(f"/centers?governorate_id={g['id']}").get_data(as_text=True)
        self.assertIn("مركز اختبار", html)
        # تعطيل المركز
        self.post(f"/admin/centers/{c['id']}/status", {}, client=admin)
        self.assertEqual(self.app.test_client().get(f"/centers/{c['id']}").status_code, 404)
        for act in ("geo_create", "center_create", "center_status"):
            self.assertTrue(self.one("SELECT 1 AS x FROM audit_logs WHERE action = ?", (act,)), act)
        # مدير الولاية لا يدير الجغرافيا
        sm = self.app.test_client()
        self.login("state_manager", client=sm)
        self.assertEqual(sm.get("/admin/geography/governorates").status_code, 403)

    # ---------- 16: الصلاحيات ----------
    def test_13_permissions_and_scope(self):
        # المتبرع لا يصل للإدارة ولا للواجهة الإدارية
        self.login("donor")
        for u in ["/admin/", "/admin/donors", "/admin/audit", "/admin/reports"]:
            self.assertEqual(self.c.get(u).status_code, 403, u)
        # مدير مركز أم روابة يرى متبرعي مركزه فقط
        umr = self.app.test_client()
        self.login("umr_manager", client=umr)
        d_main = self.one("SELECT d.id FROM donors d WHERE d.preferred_center_id = 1 AND d.id NOT IN "
                          "(SELECT donor_id FROM appointments WHERE center_id = 3) AND d.id NOT IN (SELECT donor_id FROM donations WHERE center_id = 3)")
        self.assertEqual(umr.get(f"/admin/donors/{d_main['id']}").status_code, 404)
        self.assertEqual(umr.get("/admin/centers/1").status_code, 403)
        # الإدارة العامة ترى الجميع
        ga = self.app.test_client()
        self.login("general_admin", client=ga)
        self.assertEqual(ga.get(f"/admin/donors/{d_main['id']}").status_code, 200)
        # مدير المركز لا يستطيع إسناد دور أعلى من رتبته
        mgr = self.app.test_client()
        self.login("center_manager", client=mgr)
        r = self.post("/admin/users/new", {"full_name": "محاولة ترقية غير مسموحة", "phone": "0912000013",
                                           "role": "general_admin"}, client=mgr)
        self.assertIn("غير صالحة", r.get_data(as_text=True))
        r = self.post("/admin/users/new", {"full_name": "موظف جديد للاختبار", "phone": "0912000013", "role": "center_staff",
                                           "scope_center_id": "3"}, client=mgr)
        self.assertIn("خارج نطاق صلاحياتك", r.get_data(as_text=True))
        r = self.post("/admin/users/new", {"full_name": "موظف جديد للاختبار", "phone": "0912000013", "role": "center_staff",
                                           "scope_center_id": "1"}, client=mgr)
        self.assertIn("كلمة المرور المؤقتة", r.get_data(as_text=True))
        temp = re.search(r'<code class="ltr"[^>]*>([^<]+)</code>', r.get_data(as_text=True)).group(1)
        u = self.one("SELECT * FROM users WHERE phone = '+249912000013'")
        self.assertTrue(self.one("SELECT 1 AS x FROM audit_logs WHERE action = 'role_assign' AND entity_id = ?", (u["id"],)))
        newc = self.app.test_client()
        r = self.post("/login", {"phone": "0912000013", "password": temp}, client=newc)
        self.assertEqual(newc.get("/admin/appointments").status_code, 200)
        self.assertEqual(newc.get("/admin/users").status_code, 403)
        # إيقاف الحساب ينهي الجلسة فورًا
        self.post(f"/admin/users/{u['id']}", {"full_name": u["full_name"], "status": "suspended"}, client=mgr)
        self.assertEqual(newc.get("/admin/appointments").status_code, 302)

    def test_14_csrf_required(self):
        self.login("donor")
        r = self.c.post("/donor/settings", data={"action": "prefs"})
        self.assertEqual(r.status_code, 400)

    # ---------- 17: الإشعارات ----------
    def test_15_notifications_and_reminders(self):
        self.register(phone="0912000015")
        day, t = self.next_slot(1)
        self.post("/donor/appointments/new", {"center_id": 1, "date": day, "time": t, "ack": "1"})
        with self.app.app_context():
            from app.services.appointments import send_reminders
            from app.services.common import set_setting
            set_setting("reminder_hours_before", "400")
            sent = send_reminders()
            set_setting("reminder_hours_before", "24")
        self.assertGreaterEqual(sent, 1)
        html = self.c.get("/donor/notifications").get_data(as_text=True)
        self.assertIn("تذكير بموعد التبرع", html)
        self.post("/donor/notifications/read", {})
        uid = self.one("SELECT id FROM users WHERE phone = '+249912000015'")["id"]
        self.assertEqual(self.one("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0", (uid,))["n"], 0)
        # إشعار إداري
        admin = self.app.test_client()
        self.login("state_manager", client=admin)
        r = self.post("/admin/notifications", {"target": "donors", "blood_type": "O-", "title": "تنبيه اختبار",
                                               "body": "نص إشعار الاختبار"}, client=admin)
        self.assertIn("تم إرسال الإشعار", r.get_data(as_text=True))

    # ---------- 18: البحث ----------
    def test_16_search(self):
        admin = self.app.test_client()
        self.login("super_admin", client=admin)
        html = admin.get("/admin/search?q=D-DEMO001").get_data(as_text=True)
        self.assertIn("D-DEMO001", html)
        html = admin.get("/admin/search?q=الأبيض").get_data(as_text=True)
        self.assertIn("المركز الرئيسي", html)
        html = admin.get("/admin/search?q=شيكان").get_data(as_text=True)
        self.assertIn("المحليات", html)
        html = admin.get("/admin/donors?blood_type=O%2B&locality_id=1").get_data(as_text=True)
        self.assertNotIn("Traceback", html)
        html = self.app.test_client().get("/centers?q=أم روابة").get_data(as_text=True)
        self.assertIn("أم روابة", html)

    # ---------- 19: التقارير ----------
    def test_17_reports_export(self):
        admin = self.app.test_client()
        self.login("state_manager", client=admin)
        from app.services.reports import REPORTS
        for rep in REPORTS:
            r = admin.get(f"/admin/reports?report={rep}")
            self.assertEqual(r.status_code, 200, rep)
            r = admin.get(f"/admin/reports?report={rep}&format=csv")
            self.assertEqual(r.status_code, 200, rep)
            self.assertTrue(r.data.startswith("﻿".encode()), rep)
            r = admin.get(f"/admin/reports?report={rep}&format=xlsx")
            self.assertEqual(r.data[:2], b"PK", rep)
        r = admin.get("/admin/reports?report=donations&format=csv&blood_type=O%2B&date_from=2020-01-01")
        self.assertNotIn("+249", r.data.decode("utf-8-sig"))  # لا أرقام هواتف في التقارير
        self.assertTrue(self.one("SELECT 1 AS x FROM reports WHERE report_type = 'donations'"))

    def test_18_backup(self):
        admin = self.app.test_client()
        self.login("super_admin", client=admin)
        r = self.post("/admin/settings/backup", {}, client=admin)
        self.assertEqual(r.status_code, 200)
        self.assertIn("attachment", r.headers.get("Content-Disposition", ""))
        ga = self.app.test_client()
        self.login("general_admin", client=ga)
        self.assertEqual(self.post("/admin/settings/backup", {}, client=ga, follow=False).status_code, 403)


class ApiTests(Base):
    def token(self, phone, pw="Demo@2026"):
        r = self.c.post("/api/v1/auth/login", json={"phone": phone, "password": pw})
        self.assertEqual(r.status_code, 200, r.get_json())
        return {"Authorization": "Bearer " + r.get_json()["token"]}

    def test_api_flow(self):
        self.assertEqual(self.c.get("/api/v1/me").status_code, 401)
        r = self.c.post("/api/v1/auth/register", json={"full_name": "متبرع عبر الواجهة", "phone": "0912000101",
                                                        "password": "Api12345", "governorate_id": 1, "locality_id": 1,
                                                        "blood_type": "O+", "consent": True})
        self.assertEqual(r.status_code, 201, r.get_json())
        h = {"Authorization": "Bearer " + r.get_json()["token"]}
        me = self.c.get("/api/v1/me", headers=h).get_json()
        self.assertEqual(me["donor"]["blood_type"], "O+")
        with self.app.app_context():
            from app.services.appointments import available_slots, open_days
            day = next(d["date"] for d in open_days(1, 14) if available_slots(1, d["date"]))
        slots = self.c.get(f"/api/v1/centers/1/slots?date={day}").get_json()
        r = self.c.post("/api/v1/donor/appointments", headers=h, json={"center_id": 1, "date": day, "time": slots[-1]["time"]})
        self.assertEqual(r.status_code, 422)
        r = self.c.post("/api/v1/donor/appointments", headers=h,
                        json={"center_id": 1, "date": day, "time": slots[-1]["time"], "acknowledged": True})
        self.assertEqual(r.status_code, 201, r.get_json())
        aid = r.get_json()["id"]
        r = self.c.post(f"/api/v1/donor/appointments/{aid}/cancel", headers=h, json={})
        self.assertEqual(r.get_json()["status"], "cancelled")
        self.assertEqual(self.c.get("/api/v1/admin/dashboard", headers=h).status_code, 403)
        ha = self.token("0900000003")
        self.assertIn("kpi", self.c.get("/api/v1/admin/dashboard", headers=ha).get_json())
        inv = self.c.get("/api/v1/admin/inventory", headers=ha).get_json()
        self.assertTrue(inv and all(x["available_units"] >= 0 for x in inv))
        r = self.c.post("/api/v1/admin/requests", headers=ha, json={"center_id": 1, "blood_type": "A+", "units_required": -0,
                                                                   "urgency": "normal", "requesting_entity": "اختبار"})
        self.assertEqual(r.status_code, 422)
