# 5. الواجهة البرمجية REST API v1

- **المسار الأساسي:** `/api/v1`
- **المصادقة:** `Authorization: Bearer <JWT>`. الرمز صالح 12 ساعة، ويبطل تلقائيًا عند تغيير كلمة المرور أو الصلاحيات.
- **الأخطاء:** `{"error": "...", "message": "رسالة عربية", "fields": {...}}`، مع الرموز 401 و403 و404 و409 و422 و429.

## المصادقة

| الطريقة | المسار | الوصف |
|---|---|---|
| POST | `/auth/login` | `{phone, password}` ← `{token, expires_in}`، مع حد للمحاولات وقفل مؤقت للحساب |
| POST | `/auth/register` | تسجيل متبرع: `{full_name, phone, password, governorate_id, locality_id, blood_type?, preferred_center_id?, consent: true}` |
| GET | `/me` | المستخدم الحالي وأدواره وملخص ملف المتبرع |

## بيانات عامة (بدون تسجيل دخول)

| الطريقة | المسار | الوصف |
|---|---|---|
| GET | `/governorates` | الولايات المفعّلة |
| GET | `/localities?governorate_id=` | محليات ولاية |
| GET | `/centers?governorate_id=&locality_id=&q=` | المراكز العاملة |
| GET | `/centers/{id}` | تفاصيل المركز، وحالة توفر كل فصيلة (متوفر/منخفض/حرج بدون أرقام)، وأيام العمل |
| GET | `/centers/{id}/slots?date=YYYY-MM-DD` | الأوقات المتاحة للحجز |
| GET | `/appeals?governorate_id=` | النداءات العاجلة المعتمدة فقط |
| GET | `/content` | المحتوى التوعوي المنشور |

## المتبرع

| الطريقة | المسار | الوصف |
|---|---|---|
| GET / PATCH | `/donor/profile` | الملف الشخصي. الفصيلة المثبتة مخبريًا لا تتغير |
| GET / POST | `/donor/appointments` | قائمة المواعيد، أو حجز موعد: `{center_id, date, time, acknowledged: true}` |
| GET / PATCH | `/donor/appointments/{id}` | عرض الموعد، أو تعديل تاريخه ووقته |
| POST | `/donor/appointments/{id}/cancel` | إلغاء الموعد |
| GET | `/donor/donations` | سجل التبرعات |
| GET | `/notifications?page=` | الإشعارات |
| POST | `/notifications/{id}/read` | تعليم إشعار كمقروء |

`acknowledged: true` إلزامي عند الحجز، وهو إقرار بأن حجز الموعد لا يُعد دليلًا على الأهلية الطبية.

## الإدارة (محصورة بنطاق المستخدم)

| الطريقة | المسار | الصلاحية |
|---|---|---|
| GET | `/admin/dashboard` | `dashboard.view` |
| GET | `/admin/inventory` | `inventory.view` |
| GET / POST | `/admin/requests` | `requests.view` / `requests.create` |

## مثال

```bash
TOKEN=$(curl -s -X POST https://host/api/v1/auth/login -H 'Content-Type: application/json' \
  -d '{"phone":"0911000001","password":"Demo@2026"}' | jq -r .token)
curl -s https://host/api/v1/centers/1/slots?date=2026-10-01
curl -s -X POST https://host/api/v1/donor/appointments -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' -d '{"center_id":1,"date":"2026-10-01","time":"09:00","acknowledged":true}'
```
