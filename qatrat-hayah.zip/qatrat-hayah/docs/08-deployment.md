# 8. خطة النشر

## المرحلة 1: شمال كردفان (تجريبي تشغيلي)

- **خادم واحد:** 2 vCPU، و4GB RAM، و80GB SSD، بنظام Ubuntu 24.04.
- **مكان الاستضافة:** يُفضّل مزود قريب جغرافيًا أو مركز بيانات حكومي.
- **البيانات:** PostgreSQL 16 على الخادم نفسه.

### بـ Docker (الأسهل)

```bash
cp .env.example .env        # عدّل المفاتيح وكلمة مرور قاعدة البيانات
export POSTGRES_PASSWORD=...
docker compose up -d --build
docker compose exec web flask --app wsgi create-admin
```

- يعمل الموقع على `127.0.0.1:8000` خلف Nginx (`deploy/nginx.conf`).
- للحصول على شهادة HTTPS: `certbot --nginx`.
- حاوية `scheduler` تشغّل كل دقيقة التذكير وصندوق الإرسال وإغلاق النداءات، وتشغّل النسخ الاحتياطي يوميًا الساعة 2 صباحًا.

### بدون Docker

```bash
sudo apt install python3-venv postgresql nginx
sudo -u postgres createuser qatrat -P && sudo -u postgres createdb -O qatrat qatrat
cd /opt/qatrat-hayah && python3 -m venv .venv && .venv/bin/pip install -r requirements.txt
.venv/bin/playwright install --with-deps chromium     # لتصدير PDF
.venv/bin/flask --app wsgi init-db && .venv/bin/flask --app wsgi create-admin
.venv/bin/gunicorn -w 3 -b 127.0.0.1:8000 wsgi:app    # عبر systemd
crontab deploy/crontab
```

## المرحلة 2: التوسع لكل الولايات

1. من لوحة الإدارة: تفعيل الولاية ← إضافة محلياتها ومدنها ← إضافة المراكز ← إنشاء مدير الولاية ومديري المراكز. لا حاجة لأي تعديل برمجي.
2. رفع الخادم إلى 4 vCPU و8GB، وفصل PostgreSQL على خادم مستقل مع نسخة متماثلة (streaming replica).
3. تشغيل عدة نسخ من التطبيق خلف موازن أحمال. التطبيق stateless، وحدود المحاولات محفوظة في قاعدة البيانات.
4. تفعيل مزود SMS محلي في `notifications.PROVIDERS`، وإضافة `sms` إلى `QH_NOTIFY_CHANNELS`.
5. تطبيق هاتف (Android أولًا) يستخدم `/api/v1` كما هي، مع إضافة FCM كمزود Push.

## الاستمرارية والنسخ الاحتياطي

| البند | التفصيل |
|---|---|
| النسخ اليومي | `pg_dump` بصيغة custom، مع الاحتفاظ بآخر 30 نسخة، ونسخها بـ `rsync` إلى خادم آخر |
| الاستعادة | `pg_restore -d qatrat qatrat-YYYYMMDD.dump`، وتُجرَّب شهريًا |
| المراقبة | `/health` للفحص الدوري، وسجلات Gunicorn وNginx، وتنبيه عند فشل النسخ |
| الانقطاعات | الصفحات خفيفة وبلا مصادر خارجية، وتعمل على اتصال 2G/3G |

## خطة الإطلاق المقترحة

| الأسبوع | العمل |
|---|---|
| 1 | إعداد الخادم والنطاق، وإدخال البيانات الحقيقية للمراكز والمحليات، وإنشاء الحسابات |
| 2 | تدريب موظفي المركز الرئيسي بالأبيض، وتشغيل تجريبي داخلي |
| 3–4 | إطلاق للمتبرعين في شيكان، ومتابعة سجل العمليات والملاحظات |
| 5–8 | تعميم على بقية محليات شمال كردفان |
