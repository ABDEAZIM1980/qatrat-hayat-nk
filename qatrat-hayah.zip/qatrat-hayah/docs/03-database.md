# 3. مخطط قاعدة البيانات

المخطط الكامل (DDL) في `app/schema.py`. يُكتب مرة واحدة ويُحوَّل تلقائيًا إلى SQLite أو PostgreSQL، وقد جُرّب على PostgreSQL 16 فعليًا. كل تغيير مستقبلي يُضاف كترحيل جديد في قائمة `MIGRATIONS`.

## الجداول (28 جدولًا)

| المجموعة | الجداول |
|---|---|
| الهوية والصلاحيات | `users`, `roles`, `permissions`, `role_permissions`, `user_roles` |
| الجغرافيا | `governorates` ← `localities` ← `cities` |
| المراكز | `blood_centers`, `blood_banks`, `center_schedules` |
| المتبرعون | `donors`, `donor_profiles` |
| المواعيد والتبرع | `appointments`, `medical_assessments`, `donations` |
| الطلبات والنداءات | `blood_requests`, `emergency_appeals` |
| المخزون | `blood_inventory`, `blood_inventory_transactions` |
| الإشعارات والمحتوى | `notifications`, `notification_outbox`, `educational_content` |
| التدقيق والنظام | `audit_logs`, `reports`, `system_settings`, `rate_limits`, `schema_migrations` |

الجداول المضافة على المقترح الأصلي:

| الجدول | سبب إضافته |
|---|---|
| `center_schedules` | لحساب الأوقات المتاحة للحجز |
| `medical_assessments` | لتوثيق قرار المختص |
| `notification_outbox` | لقنوات SMS وPush |
| `rate_limits` | لتحديد المحاولات بشكل يعمل مع عدة عمليات خادم |

## العلاقات

```mermaid
erDiagram
  governorates ||--o{ localities : تضم
  localities ||--o{ cities : تضم
  governorates ||--o{ blood_centers : ""
  localities ||--o{ blood_centers : ""
  cities |o--o{ blood_centers : ""
  blood_centers ||--o| blood_banks : ""
  blood_centers ||--o{ center_schedules : ""
  users ||--o{ user_roles : ""
  roles ||--o{ user_roles : ""
  roles ||--o{ role_permissions : ""
  permissions ||--o{ role_permissions : ""
  user_roles }o--o| governorates : "نطاق"
  user_roles }o--o| localities : "نطاق"
  user_roles }o--o| blood_centers : "نطاق"
  users ||--o| donors : ""
  donors ||--|| donor_profiles : ""
  donors ||--o{ appointments : ""
  blood_centers ||--o{ appointments : ""
  appointments ||--o{ medical_assessments : ""
  appointments ||--o| donations : ""
  donors ||--o{ donations : ""
  blood_centers ||--o{ blood_inventory : "8 فصائل"
  blood_inventory ||--o{ blood_inventory_transactions : ""
  blood_centers ||--o{ blood_requests : ""
  blood_requests |o--o{ emergency_appeals : ""
  users ||--o{ notifications : ""
  notifications ||--o{ notification_outbox : ""
  users ||--o{ audit_logs : ""
```

## قيود السلامة

- **قيم مقيدة (CHECK):** الفصائل الثمانية فقط، ودرجات الاستعجال الأربع فقط، وكل الحالات، والأعداد موجبة. مثال: `units_required BETWEEN 1 AND 100` و`available_units >= 0`، فلا يمكن أن يُخزَّن `-0` أو رصيد سالب أصلًا.
- **قيم فريدة:** رقم هاتف المستخدم، رمز المتبرع، رقم الطلب، رقم وحدة الدم، ورصيد واحد لكل (مركز + فصيلة)، وتبرع واحد لكل موعد، واسم المحلية داخل الولاية.
- **سجل حركات لا يُعدَّل:** لا يتغير رصيد المخزون إلا بحركة في `blood_inventory_transactions` تحفظ الرصيد بعدها والمرجع والسبب والمستخدم.
- **الفصيلة المثبتة:** بعد أول اعتماد مخبري تصبح `blood_type_verified = 1`، ولا يستطيع المتبرع تغييرها.

## الفهارس

| الاستعلام المتكرر | الفهرس |
|---|---|
| مواعيد مركز في يوم | `ix_appt_center_date (center_id, appointment_date, appointment_time)` |
| مواعيد متبرع | `ix_appt_donor` |
| التبرعات حسب المركز والتاريخ | `ix_donations_center` |
| الوحدات بانتظار الاعتماد | `ix_donations_status (status, blood_type)` |
| البحث عن متبرعين حسب الفصيلة | `ix_donors_bt (blood_type, status)` |
| المتبرعون حسب الموقع | `ix_donors_gov (governorate_id, locality_id)` |
| الطلبات المفتوحة | `ix_req_status (status, urgency)` |
| الإشعارات غير المقروءة | `ix_notif_user (user_id, is_read, created_at)` |
| سجل التدقيق | `ix_audit_created`, `ix_audit_user`, `ix_audit_entity` |
| المراكز حسب الولاية/المحلية | `ix_centers_gov`, `ix_centers_loc` |

**عند التوسع الوطني (PostgreSQL):**
- إضافة فهرس `pg_trgm` على `users.full_name` و`blood_centers.name` لتسريع البحث النصي.
- تقسيم `audit_logs` حسب الشهر (partitioning) عندما يتجاوز عدة ملايين سجل.

## التوقيت

- تُخزَّن الطوابع الزمنية بتوقيت UTC، وتُعرض بتوقيت السودان (`Africa/Khartoum`).
- تواريخ المواعيد وأوقاتها محلية، لأنها مواعيد عمل في المركز.
