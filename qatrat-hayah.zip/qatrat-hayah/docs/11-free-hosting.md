# 11. الرفع المجاني على الإنترنت

توجد طرق مجانية فعلًا لتشغيل «قطرة حياة» على رابط عام يفتحه الناس من هواتفهم. لكل طريقة حدود، مذكورة بصراحة تحت كل واحدة.

| الطريقة | بطاقة دفع؟ | قاعدة البيانات | أنسب لـ |
|---|---|---|---|
| **1. Render + Neon + cron-job.org** (الموصى بها) | لا | PostgreSQL مجاني دائم (0.5GB) | التشغيل التجريبي الحقيقي في شمال كردفان |
| **2. PythonAnywhere** | لا | SQLite داخل الحساب | أبسط طريقة، لعدد محدود من المستخدمين |
| **3. Oracle Cloud «Always Free»** | نعم للتحقق فقط، دون خصم | PostgreSQL على خادم كامل | أقوى خيار مجاني إن توفرت بطاقة |

> **لماذا لا يكفي Render وحده مجانًا؟** قاعدة بيانات Render المجانية تُحذف بعد 30 يومًا، وقرص الموقع المجاني يُمسح عند كل إعادة تشغيل. لذلك نضع قاعدة البيانات عند Neon، فخطتها المجانية دائمة ولا تحتاج بطاقة.

---

## الطريقة 1: Render + Neon + cron-job.org (بدون أي تكلفة)

### الخطوة 1: ارفع الكود على GitHub
1. أنشئ حسابًا في [github.com](https://github.com).
2. أنشئ مستودعًا خاصًا (Private) باسم `qatrat-hayah`.
3. ارفع محتويات مجلد المشروع بزر **Add file ← Upload files**.

### الخطوة 2: قاعدة البيانات على Neon
1. سجّل في [neon.com](https://neon.com) بحساب GitHub.
2. أنشئ مشروعًا باسم `qatrat`، واختر المنطقة **Frankfurt (eu-central-1)** لأنها الأقرب للسودان.
3. من **Connect** انسخ «Connection string». يبدأ بـ `postgresql://` وينتهي بـ `?sslmode=require`.

### الخطوة 3: الموقع على Render
1. سجّل في [render.com](https://render.com) بحساب GitHub.
2. في المستودع على GitHub: احذف `render.yaml`، ثم أعد تسمية `render.free.yaml` إلى `render.yaml`.
3. في Render اضغط **New ← Blueprint**، واختر المستودع.
4. سيطلب منك قيمة `QH_DATABASE_URL`. الصق رابط Neon، ثم اضغط **Apply**.
5. بعد 3–5 دقائق تظهر حالة الموقع **Live**، ويكون رابطه مثل `https://qatrat-hayah.onrender.com`.
6. من **Environment** انسخ قيمتي `QH_SETUP_TOKEN` و`QH_TASKS_TOKEN`.
7. افتح `https://qatrat-hayah.onrender.com/setup` وأنشئ حساب مدير النظام.

### الخطوة 4: إبقاء الموقع مستيقظًا وتشغيل التذكيرات (cron-job.org)
الموقع المجاني على Render «ينام» بعد 15 دقيقة بلا زيارات، فتصبح أول زيارة بعدها بطيئة (نحو دقيقة). الحل خدمة مجانية تزوره تلقائيًا:

1. سجّل في [cron-job.org](https://cron-job.org) (مجاني).
2. أنشئ مهمة أولى: الرابط `https://qatrat-hayah.onrender.com/ping` كل **14 دقيقة**. هذه تُبقي الموقع مستيقظًا.
3. أنشئ مهمة ثانية: الرابط `https://qatrat-hayah.onrender.com/tasks/run?token=قيمة_QH_TASKS_TOKEN` كل **30 دقيقة**. هذه ترسل تذكيرات المواعيد وتغلق النداءات المنتهية.

> ساعات Render المجانية (750 ساعة شهريًا) تكفي لتشغيل موقع واحد طوال الشهر.

### الخطوة 5: النسخ الاحتياطي (مهم جدًا في الخطة المجانية)
- من «الإعدادات والنسخ الاحتياطي» اضغط **إنشاء وتنزيل نسخة احتياطية** مرة كل أسبوع على الأقل.
- احفظ الملف (`qatrat-….json.zip`) في Google Drive أو على جهازك.
- Neon يحتفظ أيضًا بتاريخ قصير للاستعادة.

### حدود هذه الطريقة
- المساحة 0.5GB تكفي عشرات الآلاف من المتبرعين والتبرعات، لكن سجل العمليات يكبر مع الوقت.
- الموقع خادم صغير واحد؛ مناسب لولاية واحدة في البداية.
- تصدير PDF يظهر كصفحة طباعة: يضغط المستخدم «حفظ كـ PDF» من المتصفح.
- الخطط المجانية قد تتغير شروطها. عند التوسع انقل المنصة إلى خادم مدفوع أو حكومي بأمرين (انظر «النقل لاحقًا» في آخر هذا الملف).

---

## الطريقة 2: PythonAnywhere (الأبسط، بدون بطاقة)

1. سجّل حساب **Beginner** مجانيًا في [pythonanywhere.com](https://www.pythonanywhere.com). رابطك سيكون `https://اسمك.pythonanywhere.com`.
2. افتح **Consoles ← Bash** ونفّذ:
   ```bash
   git clone https://github.com/حسابك/qatrat-hayah.git
   cd qatrat-hayah
   pip install --user -r requirements.txt
   cp .env.example .env
   python3 -c "import secrets;print(secrets.token_hex(32))"   # انسخ الناتج
   nano .env
   ```
3. عدّل في `.env`:
   - `QH_SECRET_KEY` و`QH_JWT_SECRET`: الناتج العشوائي من الأمر السابق.
   - احذف سطر `QH_DATABASE_URL` لتُستخدم SQLite تلقائيًا.
   - اكتب قيمة من اختيارك لكل من `QH_SETUP_TOKEN` و`QH_TASKS_TOKEN`.
4. من تبويب **Web**:
   - اضغط **Add a new web app ← Manual configuration** واختر أحدث Python.
   - افتح ملف **WSGI configuration**، واستبدل محتواه بمحتوى `deploy/pythonanywhere_wsgi.py` بعد وضع اسم حسابك مكان `YOURNAME`.
   - في **Static files** أضف: URL = `/static/`، Directory = `/home/اسمك/qatrat-hayah/app/static`.
   - فعّل **Force HTTPS**، ثم اضغط **Reload**.
5. افتح `https://اسمك.pythonanywhere.com/setup` وأنشئ حساب المدير.
6. أضف مهمة `/tasks/run?token=...` على cron-job.org كل 30 دقيقة، كما في الطريقة 1.

### حدود هذه الطريقة
- **يجب الدخول مرة كل شهر** إلى تبويب Web والضغط على **Run until 1 month from today**، وإلا يتوقف الموقع.
- عامل واحد فقط: مناسب لعشرات المستخدمين في الوقت نفسه، لا لحملة كبيرة.
- الاتصال الخارجي مقيّد بقائمة مواقع مسموحة، فقد لا تعمل بوابة الرسائل النصية.
- لا يوجد نطاق خاص في الخطة المجانية.

---

## الطريقة 3: Oracle Cloud Always Free

- خادم مجاني دائم بمواصفات قوية.
- التسجيل يطلب بطاقة دفع للتحقق من الهوية فقط، دون خصم.
- بعد إنشاء خادم Ubuntu ينطبق عليه أمر التثبيت الواحد نفسه من [10-publishing.md](10-publishing.md):
  ```bash
  bash deploy/install.sh النطاق البريد
  ```

---

## النطاق (اسم الموقع)

- الروابط المجانية تعمل فورًا: `…onrender.com` أو `…pythonanywhere.com`.
- اسم خاص مثل `qatrathayah.sd` يحتاج رسوم تسجيل النطاق فقط. يُربط مجانًا في Render مع شهادة HTTPS تلقائية.

## النقل لاحقًا إلى خادم مدفوع أو حكومي دون فقد البيانات

```bash
# على الخادم القديم (أو نزّل نسخة JSON من لوحة الإدارة)
flask --app wsgi export-json qatrat-backup.json.zip
# على الخادم الجديد بعد التثبيت
flask --app wsgi restore-json qatrat-backup.json.zip --yes
```

النقل يعمل بين SQLite وPostgreSQL في الاتجاهين، وهو مختبَر آليًا.
