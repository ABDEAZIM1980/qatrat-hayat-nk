# 12. الخيار المختار: Oracle Cloud «Always Free» (مجاني بلا مدة)

## لماذا هذا الخيار؟

| | Oracle Always Free | Render + Neon | PythonAnywhere |
|---|---|---|---|
| مجاني بلا مدة محددة | نعم ✅ | نعم ✅ | نعم، مع تجديد يدوي شهري |
| خادم كامل لك وحدك | نعم (حتى 4 معالجات و24GB ذاكرة ARM) | لا | لا |
| لا «ينام» ولا يحتاج زيارات دورية | نعم ✅ | يحتاج cron-job.org | نعم |
| قاعدة بيانات على الخادم نفسه | PostgreSQL بلا حد إلا مساحة القرص | 0.5GB | SQLite |
| تصدير PDF من الخادم | نعم | صفحة طباعة | صفحة طباعة |
| نسخ احتياطي تلقائي يومي | نعم (السكربت يضبطه) | يدوي | يدوي |
| بطاقة دفع | **مطلوبة للتحقق من الهوية فقط، دون خصم** | لا | لا |

**الشرط الوحيد:** بطاقة Visa أو Mastercard (مدينة أو ائتمانية) تقبلها Oracle للتحقق. إذا لم تتوفر لك، فاستخدم Render + Neon من [11-free-hosting.md](11-free-hosting.md)؛ المنصة مجهزة لها أيضًا.

> لا توجد شركة تضمن «مدى الحياة» حرفيًا، فأي مزود يمكن أن يغيّر شروطه. لذلك نزّل نسخة احتياطية كل أسبوع، ويمكن النقل لأي خادم آخر بأمرين (`export-json` ثم `restore-json`).

---

## الخطوات (بدون أي أوامر يدوية)

جهّزت سكربتًا يُلصق عند إنشاء الخادم (`deploy/oracle-cloud-init.sh`). يثبّت كل شيء وحده، ويربط النطاق المجاني تلقائيًا.

### 1) ارفع ملف المشروع على GitHub (ملف واحد)
1. أنشئ حسابًا في [github.com](https://github.com).
2. **New repository** باسم `qatrat-hayah`، واختر **Public**. الكود لا يحتوي أي أسرار؛ كل المفاتيح تُولَّد على الخادم.
3. في المستودع اضغط **uploading an existing file**، واسحب ملف **`qatrat-hayah.zip`** كما هو دون فك ضغطه، ثم اضغط **Commit changes**.
4. رابط الكود الذي ستضعه في السكربت: `https://github.com/اسمك/qatrat-hayah/raw/main/qatrat-hayah.zip`

### 2) احجز اسمًا مجانيًا في DuckDNS
1. ادخل [duckdns.org](https://www.duckdns.org) بحساب Google.
2. اكتب اسمًا (مثل `qatrathayah`) واضغط **add domain**.
3. انسخ **token** الظاهر أعلى الصفحة.

### 3) أنشئ حساب Oracle Cloud
1. من [oracle.com/cloud/free](https://www.oracle.com/cloud/free/) اضغط **Start for free**.
2. اختر Home Region قريبة، مثل جدة أو دبي أو فرانكفورت. **لا يمكن تغييرها لاحقًا.**
3. أدخل البطاقة للتحقق فقط.

### 4) أنشئ الخادم والصق السكربت
1. **Compute ← Instances ← Create instance**.
2. **Image:** Ubuntu 24.04. **Shape:** Ampere `VM.Standard.A1.Flex`، بمعالجين (2 OCPU) و12GB ذاكرة.
3. **SSH keys:** اختر Generate وانزّل المفتاح واحفظه (للطوارئ فقط).
4. افتح **Show advanced options ← Management ← Paste cloud-init script**.
5. الصق محتوى `deploy/oracle-cloud-init.sh` بعد تعديل القيم الخمس في أعلاه:
   - رابط الكود (`CODE_URL`)
   - اسم DuckDNS
   - الـ token
   - بريدك
   - كلمة سرية لصفحة الإعداد
6. اضغط **Create**.

> إذا ظهرت رسالة «Out of capacity»، جرّب Availability Domain آخر أو أعد المحاولة بعد ساعات.

### 5) افتح منفذي الويب (خطوة إلزامية)
1. من صفحة الخادم: اضغط اسم **Subnet** ← **Default Security List** ← **Add Ingress Rules**.
2. قاعدة أولى: Source CIDR `0.0.0.0/0`، IP Protocol `TCP`، Destination Port `80`.
3. قاعدة ثانية مثلها للمنفذ `443`.

### 6) انتظر 15–25 دقيقة ثم افتح موقعك
- افتح `https://qatrathayah.duckdns.org/setup`.
- أدخل الكلمة السرية التي كتبتها في السكربت، ثم أنشئ حساب مدير النظام.
- إذا لم يفتح الموقع بعد 30 دقيقة، ادخل للخادم بالمفتاح وشغّل `sudo tail -50 /var/log/qatrat-install.log`، وأرسل الناتج لمن يساعدك.

## المحافظة على الحساب المجاني
- **سجّل الدخول إلى لوحة Oracle Cloud مرة كل شهر على الأقل.** الحسابات الخاملة 30 يومًا قد تُعد مهجورة.
- لا تضغط «Upgrade to Paid» إلا إذا أردت ذلك؛ الموارد المجانية تبقى مجانية.
- نزّل نسخة احتياطية أسبوعيًا من «الإعدادات والنسخ الاحتياطي» واحفظها خارج الخادم.
- لتحديث المنصة: `cd /opt/qatrat-hayah && git pull && docker compose up -d --build`
