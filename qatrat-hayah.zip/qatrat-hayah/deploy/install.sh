#!/usr/bin/env bash
# تثبيت «قطرة حياة» على خادم Ubuntu 22.04/24.04 جديد بأمر واحد.
# الاستخدام (كمستخدم root، من داخل مجلد المشروع):
#   bash deploy/install.sh qatrat.example.sd admin@example.sd
set -euo pipefail
DOMAIN="${1:?اكتب اسم النطاق، مثال: qatrat.example.sd}"
EMAIL="${2:?اكتب بريدًا لتنبيهات شهادة HTTPS}"
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "==> تثبيت المتطلبات"
apt-get update -y
apt-get install -y ca-certificates curl nginx certbot python3-certbot-nginx ufw
if ! command -v docker >/dev/null; then curl -fsSL https://get.docker.com | sh; fi

echo "==> الجدار الناري"
if [ -f /etc/iptables/rules.v4 ] && grep -q "REJECT" /etc/iptables/rules.v4; then
  # صور Oracle Cloud تستخدم iptables مباشرة (لا تستخدم ufw عليها)
  iptables -C INPUT -p tcp --dport 80 -j ACCEPT 2>/dev/null || iptables -I INPUT 5 -p tcp --dport 80 -j ACCEPT
  iptables -C INPUT -p tcp --dport 443 -j ACCEPT 2>/dev/null || iptables -I INPUT 5 -p tcp --dport 443 -j ACCEPT
  apt-get install -y iptables-persistent && netfilter-persistent save
else
  ufw allow OpenSSH && ufw allow 'Nginx Full' && ufw --force enable
fi

echo "==> ملف الإعدادات .env"
cd "$APP_DIR"
rnd() { python3 -c "import secrets;print(secrets.token_hex(32))"; }
set_kv() {  # يضبط مفتاحًا في .env (يستبدله إن وُجد أو يضيفه)
  if grep -q "^$1=" .env; then sed -i "s|^$1=.*|$1=$2|" .env; else echo "$1=$2" >> .env; fi
}
if [ ! -f .env ]; then
  cp .env.example .env
  PGPASS=$(rnd)
  set_kv QH_SECRET_KEY "$(rnd)"
  set_kv QH_JWT_SECRET "$(rnd)"
  set_kv QH_DATABASE_URL "postgresql://qatrat:${PGPASS}@db:5432/qatrat"
  set_kv POSTGRES_PASSWORD "$PGPASS"
  set_kv QH_SETUP_TOKEN "${SETUP_TOKEN:-$(python3 -c 'import secrets;print(secrets.token_urlsafe(12))')}"
  set_kv QH_TASKS_TOKEN "$(rnd)"
  set_kv QH_SITE_URL "https://${DOMAIN}"
  set_kv QH_ENV production
  set_kv QH_SEED_DEMO 0
  chmod 600 .env
fi
set -a; . ./.env; set +a

echo "==> تشغيل التطبيق وقاعدة البيانات"
docker compose up -d --build

echo "==> Nginx و HTTPS"
sed "s/qatrat.example.sd/${DOMAIN}/g; s|/opt/qatrat-hayah|${APP_DIR}|g" deploy/nginx.conf > /etc/nginx/sites-available/qatrat-hayah
# قبل وجود الشهادة: إعداد HTTP مؤقت
cat > /etc/nginx/sites-available/qatrat-bootstrap <<NGX
server { listen 80; server_name ${DOMAIN}; location / { proxy_pass http://127.0.0.1:8000; proxy_set_header Host \$host; proxy_set_header X-Forwarded-For \$remote_addr; proxy_set_header X-Forwarded-Proto \$scheme; } }
NGX
ln -sf /etc/nginx/sites-available/qatrat-bootstrap /etc/nginx/sites-enabled/qatrat
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx
# إعادة المحاولة حتى 45 دقيقة: قد لا يكون النطاق أو المنفذ 80 جاهزًا بعد
for i in $(seq 1 45); do
  if certbot certonly --nginx -d "$DOMAIN" -m "$EMAIL" --agree-tos -n; then break; fi
  echo "لم تنجح الشهادة بعد (المحاولة $i). تأكد من فتح المنفذين 80 و443 ومن توجيه النطاق. إعادة بعد دقيقة…"
  sleep 60
done
[ -d "/etc/letsencrypt/live/${DOMAIN}" ] || { echo "تعذر إصدار شهادة HTTPS. أعد تشغيل: bash deploy/install.sh ${DOMAIN} ${EMAIL}"; exit 1; }
ln -sf /etc/nginx/sites-available/qatrat-hayah /etc/nginx/sites-enabled/qatrat
nginx -t && systemctl reload nginx

echo
echo "=============================================================="
echo " تم! افتح: https://${DOMAIN}/setup"
echo " رمز الإعداد الأول (QH_SETUP_TOKEN): $(grep ^QH_SETUP_TOKEN .env | cut -d= -f2)"
echo " احفظ ملف .env في مكان آمن؛ فيه مفاتيح المنصة وكلمة مرور قاعدة البيانات."
echo "=============================================================="
