# انسخ محتوى هذا الملف إلى ملف WSGI في تبويب Web على PythonAnywhere
# (استبدل YOURNAME باسم حسابك)
import sys

path = "/home/YOURNAME/qatrat-hayah"
if path not in sys.path:
    sys.path.insert(0, path)

# الإعدادات تُقرأ من الملف /home/YOURNAME/qatrat-hayah/.env
from wsgi import app as application  # noqa: E402,F401
