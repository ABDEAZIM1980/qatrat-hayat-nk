#!/bin/bash
# =====================================================================
#  قطرة حياة — تثبيت تلقائي كامل على Oracle Cloud (بدون أي أوامر يدوية)
#  الصق هذا الملف في خانة «Cloud-init script» عند إنشاء الخادم
#  بعد تعديل القيم الخمس التالية فقط:
# =====================================================================
# رابط الكود: إما ملف qatrat-hayah.zip المرفوع في مستودعك (الأسهل)، أو رابط المستودع .git
CODE_URL="https://github.com/YOUR-ACCOUNT/qatrat-hayah/raw/main/qatrat-hayah.zip"
DUCKDNS_SUBDOMAIN="qatrathayah"                              # الاسم الذي حجزته في duckdns.org (بدون .duckdns.org)
DUCKDNS_TOKEN="00000000-0000-0000-0000-000000000000"         # الرمز (token) من صفحة duckdns.org
ADMIN_EMAIL="you@example.com"                                # بريدك (لتنبيهات شهادة HTTPS)
SETUP_TOKEN="اكتب-كلمة-سرية-لصفحة-الإعداد"                  # ستستخدمها مرة واحدة في صفحة /setup
# =====================================================================

exec > /var/log/qatrat-install.log 2>&1
set -x
DOMAIN="${DUCKDNS_SUBDOMAIN}.duckdns.org"

# 1) ربط النطاق بعنوان هذا الخادم تلقائيًا، وتحديثه كل 5 دقائق
curl -fsS "https://www.duckdns.org/update?domains=${DUCKDNS_SUBDOMAIN}&token=${DUCKDNS_TOKEN}&ip=" || true
echo "*/5 * * * * root curl -fsS 'https://www.duckdns.org/update?domains=${DUCKDNS_SUBDOMAIN}&token=${DUCKDNS_TOKEN}&ip=' >/dev/null 2>&1" > /etc/cron.d/duckdns

# 2) تنزيل المنصة
apt-get update -y
apt-get install -y git unzip curl
rm -rf /opt/qatrat-hayah
case "$CODE_URL" in
  *.zip)
    curl -fL --retry 5 -o /tmp/qatrat.zip "$CODE_URL"
    unzip -q /tmp/qatrat.zip -d /opt/
    [ -d /opt/qatrat-hayah ] || mv /opt/qatrat-hayah-* /opt/qatrat-hayah ;;
  *)
    git clone --depth 1 "$CODE_URL" /opt/qatrat-hayah ;;
esac

# 3) التثبيت الكامل (Docker + PostgreSQL + Nginx + HTTPS + النسخ الاحتياطي)
cd /opt/qatrat-hayah
SETUP_TOKEN="$SETUP_TOKEN" bash deploy/install.sh "$DOMAIN" "$ADMIN_EMAIL"
echo "QATRAT_INSTALL_DONE https://${DOMAIN}/setup"
