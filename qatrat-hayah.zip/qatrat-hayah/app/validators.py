"""التحقق من المدخلات (Input Validation) — كل قيمة تأتي من المستخدم تمر من هنا."""
import re
from datetime import datetime

from .schema import BLOOD_TYPES

URGENCY = {"normal": "عادي", "medium": "متوسط", "urgent": "عاجل", "critical": "حرج"}
URGENCY_ORDER = ["critical", "urgent", "medium", "normal"]

_ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def to_western_digits(s):
    return (s or "").translate(_ARABIC_DIGITS)


class ValidationError(Exception):
    pass


class Form:
    """جامع بسيط للقيم والأخطاء لنماذج HTML وطلبات JSON."""

    def __init__(self, data):
        self.data = data or {}
        self.errors = {}
        self.clean = {}

    def raw(self, name):
        v = self.data.get(name)
        if isinstance(v, str):
            v = to_western_digits(v).strip()
        return v

    def error(self, name, msg):
        self.errors.setdefault(name, msg)

    @property
    def ok(self):
        return not self.errors

    # ---- أنواع الحقول ----
    def text(self, name, label, required=True, min_len=0, max_len=255):
        v = self.raw(name)
        v = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", v or "") if isinstance(v, str) or v is None else str(v)
        if not v:
            if required:
                self.error(name, f"حقل «{label}» مطلوب.")
            self.clean[name] = None
            return None
        if len(v) < min_len:
            self.error(name, f"«{label}» يجب ألا يقل عن {min_len} أحرف.")
        if len(v) > max_len:
            self.error(name, f"«{label}» يجب ألا يزيد عن {max_len} حرفًا.")
        self.clean[name] = v
        return v

    def integer(self, name, label, required=True, min_value=None, max_value=None):
        v = self.raw(name)
        if v in (None, ""):
            if required:
                self.error(name, f"حقل «{label}» مطلوب.")
            self.clean[name] = None
            return None
        s = str(v)
        # نرفض القيم مثل -0 و 0- والنصوص العشوائية: أرقام موجبة فقط
        if not re.fullmatch(r"\d{1,9}", s):
            self.error(name, f"«{label}» يجب أن يكون رقمًا صحيحًا موجبًا.")
            self.clean[name] = None
            return None
        n = int(s)
        if min_value is not None and n < min_value:
            self.error(name, f"«{label}» يجب ألا يقل عن {min_value}.")
        if max_value is not None and n > max_value:
            self.error(name, f"«{label}» يجب ألا يزيد عن {max_value}.")
        self.clean[name] = n
        return n

    def decimal(self, name, label, required=False, min_value=None, max_value=None):
        v = self.raw(name)
        if v in (None, ""):
            if required:
                self.error(name, f"حقل «{label}» مطلوب.")
            self.clean[name] = None
            return None
        if not re.fullmatch(r"-?\d{1,3}(\.\d{1,8})?", str(v)):
            self.error(name, f"«{label}» غير صالح.")
            self.clean[name] = None
            return None
        n = float(v)
        if (min_value is not None and n < min_value) or (max_value is not None and n > max_value):
            self.error(name, f"«{label}» خارج النطاق المسموح.")
        self.clean[name] = n
        return n

    def choice(self, name, label, choices, required=True):
        v = self.raw(name)
        if v in (None, ""):
            if required:
                self.error(name, f"يرجى اختيار «{label}».")
            self.clean[name] = None
            return None
        if v not in choices:
            self.error(name, f"قيمة «{label}» غير صالحة.")
            self.clean[name] = None
            return None
        self.clean[name] = v
        return v

    def blood_type(self, name="blood_type", label="فصيلة الدم", required=True):
        return self.choice(name, label, BLOOD_TYPES, required)

    def urgency(self, name="urgency", label="درجة الاستعجال"):
        return self.choice(name, label, list(URGENCY), True)

    def phone(self, name="phone", label="رقم الهاتف", required=True):
        v = self.raw(name)
        if not v:
            if required:
                self.error(name, f"حقل «{label}» مطلوب.")
            self.clean[name] = None
            return None
        n = normalize_phone(v)
        if not n:
            self.error(name, "رقم الهاتف غير صحيح. أدخل رقمًا سودانيًا مثل 0912345678.")
            self.clean[name] = None
            return None
        self.clean[name] = n
        return n

    def email(self, name="email", label="البريد الإلكتروني", required=False):
        v = self.raw(name)
        if not v:
            if required:
                self.error(name, f"حقل «{label}» مطلوب.")
            self.clean[name] = None
            return None
        v = v.lower()
        if len(v) > 160 or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", v):
            self.error(name, "البريد الإلكتروني غير صحيح.")
        self.clean[name] = v
        return v

    def password(self, name="password", label="كلمة المرور", confirm=None):
        v = self.data.get(name) or ""
        if len(v) < 8:
            self.error(name, "كلمة المرور يجب ألا تقل عن 8 أحرف.")
        elif len(v) > 128:
            self.error(name, "كلمة المرور طويلة جدًا.")
        elif not (re.search(r"[A-Za-z؀-ۿ]", v) and re.search(r"\d", to_western_digits(v))):
            self.error(name, "كلمة المرور يجب أن تحتوي على حروف وأرقام.")
        if confirm is not None and v != (self.data.get(confirm) or ""):
            self.error(confirm, "تأكيد كلمة المرور غير مطابق.")
        self.clean[name] = v
        return v

    def date(self, name, label, required=True, min_date=None, max_date=None):
        v = self.raw(name)
        if not v:
            if required:
                self.error(name, f"حقل «{label}» مطلوب.")
            self.clean[name] = None
            return None
        try:
            d = datetime.strptime(v, "%Y-%m-%d").date()
        except ValueError:
            self.error(name, f"«{label}» تاريخ غير صالح.")
            self.clean[name] = None
            return None
        if min_date and d < min_date:
            self.error(name, f"«{label}» لا يمكن أن يكون قبل {min_date.isoformat()}.")
        if max_date and d > max_date:
            self.error(name, f"«{label}» لا يمكن أن يكون بعد {max_date.isoformat()}.")
        self.clean[name] = d.isoformat()
        return d

    def time(self, name, label, required=True):
        v = self.raw(name)
        if not v:
            if required:
                self.error(name, f"حقل «{label}» مطلوب.")
            self.clean[name] = None
            return None
        if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", v):
            self.error(name, f"«{label}» وقت غير صالح.")
            self.clean[name] = None
            return None
        self.clean[name] = v
        return v

    def fk(self, name, label, db, table, required=True, where="1=1"):
        """معرف لسجل موجود في جدول (قائمة بيضاء للجداول)."""
        assert table in {"governorates", "localities", "cities", "blood_centers", "roles", "blood_requests", "users"}
        v = self.integer(name, label, required=required, min_value=1)
        if v is None:
            return None
        row = db.one(f"SELECT * FROM {table} WHERE id = ? AND {where}", (v,))
        if not row:
            self.error(name, f"«{label}» غير موجود.")
            self.clean[name] = None
            return None
        return row

    def boolean(self, name):
        v = self.data.get(name)
        b = 1 if v in ("1", "on", "true", True, 1) else 0
        self.clean[name] = b
        return b


def normalize_phone(v):
    """يحوّل الرقم السوداني إلى الصيغة الدولية +2499XXXXXXXX أو +2491XXXXXXXX."""
    s = re.sub(r"[\s\-()]", "", to_western_digits(str(v)))
    if s.startswith("00249"):
        s = "+" + s[2:]
    if s.startswith("249"):
        s = "+" + s
    if s.startswith("0") and len(s) == 10:
        s = "+249" + s[1:]
    if re.fullmatch(r"\+249[19]\d{8}", s):
        return s
    return None


def display_phone(p):
    if p and p.startswith("+249") and len(p) == 13:
        return "0" + p[4:]
    return p or ""


def mask_phone(p):
    d = display_phone(p)
    if len(d) >= 10:
        return d[:3] + "****" + d[-3:]
    return "***"


def today():
    from .timeutil import local_today
    return local_today()
