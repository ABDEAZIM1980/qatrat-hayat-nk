"""نظام الإشعارات.

كل إشعار يُحفظ داخل التطبيق (in_app)، ويُضاف إلى صندوق الإرسال (outbox) لكل قناة
خارجية مفعّلة (SMS / Push / Email). عامل خلفي (flask process-outbox) يرسلها عبر
مزوّد قابل للاستبدال — وبذلك يمكن إضافة Push Notifications لاحقًا دون تغيير منطق الأعمال.
"""
import logging

from flask import current_app

from .db import get_db, utcnow

log = logging.getLogger("qatrat.notify")

CATEGORIES = {
    "appointment_confirmed": "تأكيد الموعد",
    "appointment_reminder": "تذكير بالموعد",
    "appointment_status": "تغيير حالة الموعد",
    "donation_approved": "اعتماد التبرع",
    "emergency_appeal": "نداء عاجل",
    "admin": "إشعار إداري",
    "request_status": "حالة طلب الدم",
    "center": "إشعار للمركز",
}


def notify(user_ids, category, title, body, link=None, respect_prefs=True):
    db = get_db()
    if isinstance(user_ids, int):
        user_ids = [user_ids]
    user_ids = sorted(set(int(u) for u in user_ids if u))
    if not user_ids:
        return 0
    channels = [c for c in current_app.config.get("NOTIFY_CHANNELS", ["in_app"]) if c != "in_app"]
    now = utcnow()
    count = 0
    for uid in user_ids:
        prefs = db.one(
            """SELECT p.* FROM donor_profiles p JOIN donors d ON d.id = p.donor_id WHERE d.user_id = ?""", (uid,)
        ) if respect_prefs else None
        if prefs:
            if category == "emergency_appeal" and not prefs["notify_emergency"]:
                continue
            if category == "appointment_reminder" and not prefs["notify_reminders"]:
                continue
        nid = db.insert("notifications", {
            "user_id": uid, "category": category, "title": title[:150], "body": body[:1000],
            "link": link, "is_read": 0, "created_at": now})
        for ch in channels:
            if ch == "sms" and prefs is not None and not prefs["notify_sms"]:
                continue
            db.insert("notification_outbox", {"notification_id": nid, "user_id": uid, "channel": ch,
                                              "status": "queued", "attempts": 0, "created_at": now})
        count += 1
    return count


def notify_center_staff(center_id, category, title, body, link=None):
    db = get_db()
    rows = db.query(
        """SELECT DISTINCT ur.user_id FROM user_roles ur JOIN roles r ON r.id = ur.role_id
           JOIN users u ON u.id = ur.user_id
           WHERE ur.center_id = ? AND r.code IN ('center_manager','center_staff') AND u.status = 'active'""",
        (center_id,))
    return notify([r["user_id"] for r in rows], category, title, body, link, respect_prefs=False)


class LogProvider:
    """مزوّد افتراضي يسجّل الرسالة فقط. استبدله بمزوّد SMS محلي أو FCM للـ Push."""
    def send(self, channel, user, notification):
        log.info("[%s] to %s: %s", channel, user["phone"], notification["title"])
        return True


class HttpSmsGateway:
    """بوابة SMS عامة عبر HTTP (POST JSON). اضبط QH_SMS_GATEWAY_URL و QH_SMS_GATEWAY_TOKEN.

    يُرسل: {"to": "+2499xxxxxxxx", "message": "...", "sender": "QatratHayah"}
    مع الترويسة Authorization: Bearer <token>. عدّل _payload إن كان مزودك يتطلب صيغة مختلفة.
    """

    def __init__(self, url, token, sender):
        self.url, self.token, self.sender = url, token, sender

    def _payload(self, phone, text):
        return {"to": phone, "message": text, "sender": self.sender}

    def send_text(self, phone, text):
        import json
        import urllib.request
        req = urllib.request.Request(self.url, data=json.dumps(self._payload(phone, text)).encode(), method="POST",
                                     headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.token}"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return 200 <= r.status < 300

    def send(self, channel, user, notification):
        return self.send_text(user["phone"], f"{notification['title']}: {notification['body']}"[:600])


PROVIDERS = {"sms": LogProvider(), "push": LogProvider(), "email": LogProvider()}


def sms_provider():
    """مزود SMS الفعلي إن كانت البوابة مضبوطة، وإلا None."""
    cfg = current_app.config
    if cfg.get("SMS_GATEWAY_URL"):
        return HttpSmsGateway(cfg["SMS_GATEWAY_URL"], cfg.get("SMS_GATEWAY_TOKEN", ""), cfg.get("SMS_SENDER", "QatratHayah"))
    return None


def process_outbox(limit=200):
    db = get_db()
    rows = db.query(
        """SELECT o.*, n.title, n.body, u.phone FROM notification_outbox o
           JOIN notifications n ON n.id = o.notification_id JOIN users u ON u.id = o.user_id
           WHERE o.status = 'queued' AND o.attempts < 5 ORDER BY o.id LIMIT ?""", (limit,))
    sent = 0
    for r in rows:
        prov = (sms_provider() if r["channel"] == "sms" else None) or PROVIDERS.get(r["channel"])
        try:
            ok = prov.send(r["channel"], {"phone": r["phone"]}, {"title": r["title"], "body": r["body"]}) if prov else False
            err = None
        except Exception as e:  # pragma: no cover
            ok, err = False, str(e)[:255]
        if ok:
            db.execute("UPDATE notification_outbox SET status = 'sent', attempts = attempts + 1, sent_at = ? WHERE id = ?",
                       (utcnow(), r["id"]))
            sent += 1
        else:  # يُعاد المحاولة حتى 5 مرات ثم يُعلَّم فاشلًا
            db.execute("UPDATE notification_outbox SET attempts = attempts + 1, last_error = ?, "
                       "status = CASE WHEN attempts + 1 >= 5 THEN 'failed' ELSE 'queued' END WHERE id = ?",
                       (err or "provider returned failure", r["id"]))
    return sent
