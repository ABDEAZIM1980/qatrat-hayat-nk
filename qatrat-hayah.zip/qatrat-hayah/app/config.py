"""إعدادات التطبيق — تُقرأ من متغيرات البيئة (راجع .env.example)."""
import os
import secrets
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def _load_dotenv(path=BASE_DIR / ".env"):
    """قراءة ملف .env إن وُجد (مفيد في الاستضافات التي لا توفر متغيرات بيئة مثل PythonAnywhere).
    المتغيرات المضبوطة مسبقًا في البيئة لها الأولوية."""
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    except FileNotFoundError:
        pass


if not os.environ.get("QH_NO_DOTENV"):
    _load_dotenv()


def _bool(name, default=False):
    v = os.environ.get(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


class Config:
    APP_NAME = "قطرة حياة"
    APP_NAME_EN = "QATRAT HAYAH"
    APP_SLOGAN = "قطرة منك... تنقذ حياة"
    OWNER_NAME = "الإدارة العامة لخدمات نقل الدم"

    ENV = os.environ.get("QH_ENV", "development")
    SECRET_KEY = os.environ.get("QH_SECRET_KEY") or secrets.token_hex(32)
    JWT_SECRET = os.environ.get("QH_JWT_SECRET") or SECRET_KEY
    JWT_TTL_MINUTES = int(os.environ.get("QH_JWT_TTL_MINUTES", "720"))

    # قاعدة البيانات: sqlite:///path/to/file.db  أو  postgresql://user:pass@host/db
    DATABASE_URL = (os.environ.get("QH_DATABASE_URL") or os.environ.get("DATABASE_URL")
                    or f"sqlite:///{BASE_DIR / 'instance' / 'qatrat_hayah.db'}")
    # رمز اختياري يحمي صفحة الإعداد الأول (/setup) حتى يُنشأ حساب مدير النظام
    SETUP_TOKEN = os.environ.get("QH_SETUP_TOKEN", "")
    SITE_URL = os.environ.get("QH_SITE_URL", "")
    # رمز تشغيل المهام الدورية عبر رابط (للاستضافة المجانية التي لا تدعم cron) — انظر docs/11-free-hosting.md
    TASKS_TOKEN = os.environ.get("QH_TASKS_TOKEN", "")

    # بوابة الرسائل النصية (SMS) عبر HTTP — تعمل مع أغلب مزودي الرسائل في السودان
    SMS_GATEWAY_URL = os.environ.get("QH_SMS_GATEWAY_URL", "")
    SMS_GATEWAY_TOKEN = os.environ.get("QH_SMS_GATEWAY_TOKEN", "")
    SMS_SENDER = os.environ.get("QH_SMS_SENDER", "QatratHayah")
    BACKUP_DIR = os.environ.get("QH_BACKUP_DIR", str(BASE_DIR / "instance" / "backups"))
    BACKUP_RETENTION = int(os.environ.get("QH_BACKUP_RETENTION", "30"))
    REPORTS_DIR = os.environ.get("QH_REPORTS_DIR", str(BASE_DIR / "instance" / "reports"))

    TIMEZONE = os.environ.get("QH_TIMEZONE", "Africa/Khartoum")

    SESSION_COOKIE_NAME = "qh_session"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool("QH_SECURE_COOKIES", ENV == "production")
    PERMANENT_SESSION_LIFETIME = int(os.environ.get("QH_SESSION_HOURS", "8")) * 3600
    MAX_CONTENT_LENGTH = 2 * 1024 * 1024  # 2MB لكل طلب

    # حدود المحاولات (Rate limiting)
    LOGIN_MAX_ATTEMPTS = int(os.environ.get("QH_LOGIN_MAX_ATTEMPTS", "5"))
    LOGIN_WINDOW_SECONDS = int(os.environ.get("QH_LOGIN_WINDOW_SECONDS", "900"))
    ACCOUNT_LOCK_MINUTES = int(os.environ.get("QH_ACCOUNT_LOCK_MINUTES", "15"))
    RATELIMIT_ENABLED = _bool("QH_RATELIMIT_ENABLED", True)

    # مزودو الإشعارات (قابلة للإضافة لاحقًا: sms / push)
    NOTIFY_CHANNELS = [c.strip() for c in os.environ.get("QH_NOTIFY_CHANNELS", "in_app").split(",") if c.strip()]

    SEED_DEMO_DATA = _bool("QH_SEED_DEMO", ENV != "production")
    TESTING = False


class TestConfig(Config):
    TESTING = True
    SECRET_KEY = "test-secret-key-for-unit-tests-only-0001"
    JWT_SECRET = "test-jwt-secret-for-unit-tests-only-0002"
    SESSION_COOKIE_SECURE = False
    RATELIMIT_ENABLED = True
    SEED_DEMO_DATA = True
