"""نظام الأدوار والصلاحيات (RBAC) مع النطاق الإداري (Scope).

كل مستخدم يملك إسنادًا أو أكثر (user_roles). كل إسناد = دور + نطاق:
  global       → الإدارة العامة / مدير النظام (كل الولايات)
  governorate  → مدير الولاية (ولاية محددة)
  locality     → مدير المحلية (محلية محددة)
  center       → مدير/موظف المركز (مركز محدد)
  self         → المتبرع (بياناته فقط)
"""
from dataclasses import dataclass, field

ROLES = [
    # code, name_ar, scope_level, rank (الأعلى = صلاحية أوسع)
    ("super_admin", "مدير النظام", "global", 100),
    ("general_admin", "الإدارة العامة لخدمات نقل الدم", "global", 90),
    ("state_manager", "مدير الولاية", "governorate", 70),
    ("locality_manager", "مدير المحلية", "locality", 60),
    ("center_manager", "مدير بنك الدم / المركز", "center", 50),
    ("center_staff", "موظف بنك الدم", "center", 40),
    ("donor", "متبرع", "self", 10),
]
ROLE_NAMES = {r[0]: r[1] for r in ROLES}
ROLE_RANK = {r[0]: r[3] for r in ROLES}
ROLE_SCOPE = {r[0]: r[2] for r in ROLES}

PERMISSIONS = [
    ("dashboard.view", "عرض لوحة التحكم", "dashboard"),
    ("geography.manage", "إدارة الولايات والمحليات والمدن", "geography"),
    ("centers.view", "عرض المراكز", "centers"),
    ("centers.manage", "إضافة وتعديل وتعطيل المراكز", "centers"),
    ("users.view", "عرض المستخدمين", "users"),
    ("users.manage", "إدارة المستخدمين", "users"),
    ("roles.assign", "إسناد الأدوار وتغيير الصلاحيات", "users"),
    ("donors.view", "عرض المتبرعين", "donors"),
    ("donors.manage", "تعديل بيانات المتبرعين", "donors"),
    ("appointments.view", "عرض المواعيد", "appointments"),
    ("appointments.manage", "إدارة المواعيد وتسجيل الحضور", "appointments"),
    ("donations.record", "تسجيل التقييم الطبي وعمليات التبرع", "donations"),
    ("donations.approve", "اعتماد وحدات الدم", "donations"),
    ("inventory.view", "عرض المخزون", "inventory"),
    ("inventory.manage", "تعديل المخزون", "inventory"),
    ("requests.view", "عرض طلبات الدم", "requests"),
    ("requests.create", "إنشاء طلبات الدم", "requests"),
    ("requests.approve", "اعتماد طلبات الدم وصرفها", "requests"),
    ("appeals.view", "عرض النداءات العاجلة", "appeals"),
    ("appeals.create", "إنشاء نداء عاجل", "appeals"),
    ("appeals.approve", "اعتماد ونشر النداءات العاجلة", "appeals"),
    ("content.manage", "إدارة المحتوى التوعوي", "content"),
    ("notifications.send", "إرسال الإشعارات الإدارية", "notifications"),
    ("reports.view", "عرض وتصدير التقارير", "reports"),
    ("audit.view", "عرض سجل العمليات", "audit"),
    ("settings.manage", "إدارة إعدادات النظام", "settings"),
    ("backups.manage", "إدارة النسخ الاحتياطي", "settings"),
]
ALL_PERMS = [p[0] for p in PERMISSIONS]

_STAFF_BASE = ["dashboard.view", "centers.view", "donors.view", "appointments.view", "inventory.view",
               "requests.view", "appeals.view"]

ROLE_PERMISSIONS = {
    "super_admin": ALL_PERMS,
    "general_admin": [p for p in ALL_PERMS if p != "backups.manage"],
    "state_manager": _STAFF_BASE + [
        "centers.manage", "users.view", "users.manage", "roles.assign", "donors.manage",
        "requests.create", "requests.approve", "appeals.create", "appeals.approve",
        "notifications.send", "reports.view", "audit.view"],
    "locality_manager": _STAFF_BASE + [
        "centers.manage", "users.view", "users.manage", "roles.assign",
        "requests.create", "requests.approve", "appeals.create", "notifications.send", "reports.view"],
    "center_manager": _STAFF_BASE + [
        "users.view", "users.manage", "roles.assign", "donors.manage", "appointments.manage",
        "donations.record", "donations.approve", "inventory.manage", "requests.create",
        "requests.approve", "appeals.create", "appeals.approve", "notifications.send", "reports.view"],
    "center_staff": _STAFF_BASE + [
        "appointments.manage", "donations.record", "inventory.manage", "requests.create", "appeals.create"],
    "donor": [],
}


@dataclass
class Scope:
    """النطاق الفعلي للمستخدم بعد دمج كل إسناداته."""
    is_global: bool = False
    governorate_ids: set = field(default_factory=set)
    locality_ids: set = field(default_factory=set)
    center_ids: set = field(default_factory=set)
    max_rank: int = 0
    roles: list = field(default_factory=list)

    @property
    def is_empty(self):
        return not (self.is_global or self.governorate_ids or self.locality_ids or self.center_ids)


def load_user_access(db, user_id):
    """يُرجع (قائمة الصلاحيات, النطاق) للمستخدم."""
    rows = db.query(
        """SELECT r.code, ur.governorate_id, ur.locality_id, ur.center_id
           FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?""",
        (user_id,),
    )
    scope = Scope()
    perms = set()
    for r in rows:
        code = r["code"]
        scope.roles.append(code)
        perms.update(ROLE_PERMISSIONS.get(code, []))
        scope.max_rank = max(scope.max_rank, ROLE_RANK.get(code, 0))
        level = ROLE_SCOPE.get(code)
        if level == "global":
            scope.is_global = True
        elif level == "governorate" and r["governorate_id"]:
            scope.governorate_ids.add(r["governorate_id"])
        elif level == "locality" and r["locality_id"]:
            scope.locality_ids.add(r["locality_id"])
        elif level == "center" and r["center_id"]:
            scope.center_ids.add(r["center_id"])
    return perms, scope


def _in(col, ids):
    ids = sorted(int(i) for i in ids)
    return f"{col} IN ({', '.join('?' for _ in ids)})", ids


def center_filter(scope, center_col="c.id", gov_col="c.governorate_id", loc_col="c.locality_id"):
    """شرط SQL يحصر السجلات في المراكز المسموح بها. يُرجع (sql, params)."""
    if scope.is_global:
        return "1=1", []
    parts, params = [], []
    for col, ids in ((gov_col, scope.governorate_ids), (loc_col, scope.locality_ids), (center_col, scope.center_ids)):
        if ids:
            s, p = _in(col, ids)
            parts.append(s)
            params += p
    if not parts:
        return "1=0", []
    return "(" + " OR ".join(parts) + ")", params


def accessible_center_ids(db, scope):
    """None يعني كل المراكز."""
    if scope.is_global:
        return None
    where, params = center_filter(scope)
    return [r["id"] for r in db.query(f"SELECT c.id FROM blood_centers c WHERE {where}", params)]


def donor_filter(db, scope, alias="d"):
    """المتبرعون المرئيون: حسب الولاية/المحلية، أو المرتبطون بمراكز المستخدم
    (مركز مفضل أو موعد أو تبرع في المركز)."""
    if scope.is_global:
        return "1=1", []
    parts, params = [], []
    if scope.governorate_ids:
        s, p = _in(f"{alias}.governorate_id", scope.governorate_ids)
        parts.append(s); params += p
    if scope.locality_ids:
        s, p = _in(f"{alias}.locality_id", scope.locality_ids)
        parts.append(s); params += p
    if scope.center_ids:
        ids = sorted(scope.center_ids)
        ph = ", ".join("?" for _ in ids)
        parts.append(
            f"({alias}.preferred_center_id IN ({ph}) OR {alias}.id IN "
            f"(SELECT donor_id FROM appointments WHERE center_id IN ({ph})) OR {alias}.id IN "
            f"(SELECT donor_id FROM donations WHERE center_id IN ({ph})))")
        params += ids * 3
    if not parts:
        return "1=0", []
    return "(" + " OR ".join(parts) + ")", params


def can_access_center(db, scope, center_id):
    if scope.is_global:
        return True
    c = db.one("SELECT id, governorate_id, locality_id FROM blood_centers WHERE id = ?", (center_id,))
    if not c:
        return False
    return (c["governorate_id"] in scope.governorate_ids or c["locality_id"] in scope.locality_ids
            or c["id"] in scope.center_ids)


def can_access_governorate(scope, governorate_id):
    return scope.is_global or governorate_id in scope.governorate_ids


def assignable_roles(scope, perms):
    """الأدوار التي يحق للمستخدم إسنادها: أقل من رتبته فقط (ماعدا مدير النظام)."""
    if "roles.assign" not in perms:
        return []
    out = []
    for code, name, level, rank in ROLES:
        if "super_admin" in scope.roles:
            out.append(code)
        elif rank < scope.max_rank:
            out.append(code)
    return out
