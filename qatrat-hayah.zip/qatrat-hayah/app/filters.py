"""مرشحات Jinja ومتغيرات القوالب العامة."""
from urllib.parse import urlencode

from flask import g, request

from .rbac import ROLE_NAMES
from .schema import BLOOD_TYPES
from .services.common import CENTER_TYPES, CONTENT_CATEGORIES, TX_TYPES, WEEKDAYS, label
from .timeutil import local_now, parse_ts
from .validators import URGENCY, display_phone, mask_phone

MONTHS = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def fmt_dt(v, with_time=True):
    dt = parse_ts(v)
    if not dt:
        return "—"
    s = f"{dt.day} {MONTHS[dt.month - 1]} {dt.year}"
    if with_time:
        h = dt.hour % 12 or 12
        s += f"، {h}:{dt.minute:02d} {'ص' if dt.hour < 12 else 'م'}"
    return s


def fmt_date(v):
    if not v:
        return "—"
    s = str(v)[:10]
    try:
        y, m, d = s.split("-")
        from datetime import date
        dd = date(int(y), int(m), int(d))
        return f"{WEEKDAYS[dd.weekday()]} {int(d)} {MONTHS[int(m) - 1]} {y}"
    except Exception:
        return s


def fmt_time(v):
    if not v:
        return "—"
    s = str(v)[:5]
    try:
        h, m = int(s[:2]), s[3:5]
        return f"{h % 12 or 12}:{m} {'ص' if h < 12 else 'م'}"
    except Exception:
        return s


def fmt_num(v):
    """عرض الأعداد بشكل سليم: لا يظهر -0 أو قيم فارغة غريبة."""
    if v is None or v == "":
        return "0"
    try:
        n = int(round(float(v)))
    except (TypeError, ValueError):
        return "0"
    if n == 0:
        return "0"
    return f"{n:,}"


def pct(a, b):
    try:
        return max(0, min(100, round(100 * float(a) / float(b)))) if b else 0
    except (TypeError, ValueError):
        return 0


def register(app):
    app.jinja_env.filters.update({
        "dt": fmt_dt, "date_ar": fmt_date, "time_ar": fmt_time, "num": fmt_num, "phone": display_phone,
        "mask_phone": mask_phone, "urgency": lambda v: URGENCY.get(v, "—"),
        "center_type": lambda v: CENTER_TYPES.get(v, v), "tx_type": lambda v: TX_TYPES.get(v, v),
        "role_name": lambda v: ROLE_NAMES.get(v, v), "category": lambda v: CONTENT_CATEGORIES.get(v, v),
        "d": fmt_date,
    })
    app.jinja_env.trim_blocks = True
    app.jinja_env.lstrip_blocks = True

    @app.context_processor
    def _ctx():
        from .security import csrf_token

        def _site_setting(key):
            try:
                from .services.common import get_setting
                return get_setting(key)
            except Exception:  # صفحات الأخطاء أو قبل تهيئة قاعدة البيانات
                return None

        def qs(**kw):
            args = request.args.to_dict()
            args.update({k: v for k, v in kw.items()})
            args = {k: v for k, v in args.items() if v not in (None, "")}
            return "?" + urlencode(args)
        unread = 0
        if g.get("user") is not None:
            from .db import get_db
            unread = get_db().scalar("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0",
                                     (g.user.id,), 0)
        return {
            "csrf_token": csrf_token, "current_user": g.get("user"), "label": label, "BLOOD_TYPES": BLOOD_TYPES,
            "URGENCY": URGENCY, "CENTER_TYPES": CENTER_TYPES, "CONTENT_CATEGORIES": CONTENT_CATEGORIES,
            "WEEKDAYS": WEEKDAYS, "APP": app.config, "qs": qs, "pct": pct, "unread_count": unread,
            "now_local": local_now(), "is_demo": app.config.get("SEED_DEMO_DATA"),
            "site_setting": _site_setting,
        }
