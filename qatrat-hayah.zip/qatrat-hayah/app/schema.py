"""مخطط قاعدة البيانات (Database Schema) مع نظام ترحيل بسيط (migrations).

يُكتب المخطط مرة واحدة برموز عامة ثم يُحوّل حسب نوع القاعدة:
  {PK}   مفتاح أساسي تلقائي
  {TS}   طابع زمني
  {DATE} تاريخ
  {TIME} وقت
  {BOOL} قيمة منطقية (SMALLINT 0/1 لضمان التوافق)
  {JSON} بيانات JSON
"""

TYPES = {
    "sqlite": {"PK": "INTEGER PRIMARY KEY AUTOINCREMENT", "TS": "TEXT", "DATE": "TEXT", "TIME": "TEXT",
               "BOOL": "INTEGER", "JSON": "TEXT", "DEC": "REAL", "BLOB": "BLOB"},
    "postgres": {"PK": "BIGSERIAL PRIMARY KEY", "TS": "TIMESTAMP", "DATE": "DATE", "TIME": "TIME",
                 "BOOL": "SMALLINT", "JSON": "JSONB", "DEC": "NUMERIC(9,6)", "BLOB": "BYTEA"},
}

BLOOD_TYPES = ("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")
_BT = ", ".join(f"'{b}'" for b in BLOOD_TYPES)

SCHEMA_V1 = f"""
-- ========== الهوية والصلاحيات ==========
CREATE TABLE users (
  id {{PK}},
  full_name VARCHAR(120) NOT NULL,
  phone VARCHAR(20) NOT NULL UNIQUE,
  email VARCHAR(160),
  password_hash VARCHAR(255) NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','disabled')),
  is_staff {{BOOL}} NOT NULL DEFAULT 0,
  auth_version INTEGER NOT NULL DEFAULT 1,
  failed_logins INTEGER NOT NULL DEFAULT 0,
  locked_until {{TS}},
  last_login_at {{TS}},
  created_at {{TS}} NOT NULL,
  updated_at {{TS}} NOT NULL
);
CREATE UNIQUE INDEX ux_users_email ON users(email);

CREATE TABLE roles (
  id {{PK}},
  code VARCHAR(40) NOT NULL UNIQUE,
  name_ar VARCHAR(80) NOT NULL,
  scope_level VARCHAR(16) NOT NULL CHECK (scope_level IN ('global','governorate','locality','center','self')),
  rank INTEGER NOT NULL
);

CREATE TABLE permissions (
  id {{PK}},
  code VARCHAR(60) NOT NULL UNIQUE,
  name_ar VARCHAR(120) NOT NULL,
  module VARCHAR(40) NOT NULL
);

CREATE TABLE role_permissions (
  role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id INTEGER NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);

-- ========== الهيكل الجغرافي ==========
CREATE TABLE governorates (
  id {{PK}},
  name_ar VARCHAR(80) NOT NULL UNIQUE,
  name_en VARCHAR(80),
  code VARCHAR(10) UNIQUE,
  is_active {{BOOL}} NOT NULL DEFAULT 1,
  created_at {{TS}} NOT NULL
);

CREATE TABLE localities (
  id {{PK}},
  governorate_id INTEGER NOT NULL REFERENCES governorates(id),
  name_ar VARCHAR(80) NOT NULL,
  name_en VARCHAR(80),
  is_active {{BOOL}} NOT NULL DEFAULT 1,
  created_at {{TS}} NOT NULL,
  UNIQUE (governorate_id, name_ar)
);
CREATE INDEX ix_localities_gov ON localities(governorate_id);

CREATE TABLE cities (
  id {{PK}},
  locality_id INTEGER NOT NULL REFERENCES localities(id),
  name_ar VARCHAR(80) NOT NULL,
  name_en VARCHAR(80),
  is_active {{BOOL}} NOT NULL DEFAULT 1,
  created_at {{TS}} NOT NULL,
  UNIQUE (locality_id, name_ar)
);
CREATE INDEX ix_cities_loc ON cities(locality_id);

-- ========== المراكز وبنوك الدم ==========
CREATE TABLE blood_centers (
  id {{PK}},
  name VARCHAR(150) NOT NULL,
  center_type VARCHAR(20) NOT NULL DEFAULT 'donation_center'
     CHECK (center_type IN ('donation_center','blood_bank','hospital_bank','mobile_unit')),
  governorate_id INTEGER NOT NULL REFERENCES governorates(id),
  locality_id INTEGER NOT NULL REFERENCES localities(id),
  city_id INTEGER REFERENCES cities(id),
  address VARCHAR(255),
  phone VARCHAR(20),
  working_hours VARCHAR(120),
  latitude {{DEC}},
  longitude {{DEC}},
  services TEXT,
  accepts_appointments {{BOOL}} NOT NULL DEFAULT 1,
  status VARCHAR(12) NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  created_at {{TS}} NOT NULL,
  updated_at {{TS}} NOT NULL,
  UNIQUE (locality_id, name)
);
CREATE INDEX ix_centers_gov ON blood_centers(governorate_id, status);
CREATE INDEX ix_centers_loc ON blood_centers(locality_id, status);

-- بنك الدم التابع للمركز (وحدة التخزين المرخّصة)
CREATE TABLE blood_banks (
  id {{PK}},
  center_id INTEGER NOT NULL UNIQUE REFERENCES blood_centers(id),
  license_no VARCHAR(40),
  storage_capacity_units INTEGER CHECK (storage_capacity_units IS NULL OR storage_capacity_units >= 0),
  has_component_separation {{BOOL}} NOT NULL DEFAULT 0,
  is_active {{BOOL}} NOT NULL DEFAULT 1,
  created_at {{TS}} NOT NULL
);

-- جدول مواعيد المركز الأسبوعي (لحساب الأوقات المتاحة)
CREATE TABLE center_schedules (
  id {{PK}},
  center_id INTEGER NOT NULL REFERENCES blood_centers(id) ON DELETE CASCADE,
  weekday INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  start_time {{TIME}} NOT NULL,
  end_time {{TIME}} NOT NULL,
  slot_minutes INTEGER NOT NULL DEFAULT 30 CHECK (slot_minutes BETWEEN 10 AND 240),
  capacity_per_slot INTEGER NOT NULL DEFAULT 3 CHECK (capacity_per_slot BETWEEN 1 AND 100),
  UNIQUE (center_id, weekday)
);

-- ربط المستخدم بالدور مع نطاقه الجغرافي/الإداري
CREATE TABLE user_roles (
  id {{PK}},
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id INTEGER NOT NULL REFERENCES roles(id),
  governorate_id INTEGER REFERENCES governorates(id),
  locality_id INTEGER REFERENCES localities(id),
  center_id INTEGER REFERENCES blood_centers(id),
  assigned_by INTEGER REFERENCES users(id),
  created_at {{TS}} NOT NULL
);
CREATE INDEX ix_user_roles_user ON user_roles(user_id);

-- ========== المتبرعون ==========
CREATE TABLE donors (
  id {{PK}},
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  donor_code VARCHAR(20) NOT NULL UNIQUE,
  blood_type VARCHAR(3) CHECK (blood_type IS NULL OR blood_type IN ({_BT})),
  blood_type_verified {{BOOL}} NOT NULL DEFAULT 0,
  governorate_id INTEGER NOT NULL REFERENCES governorates(id),
  locality_id INTEGER NOT NULL REFERENCES localities(id),
  preferred_center_id INTEGER REFERENCES blood_centers(id),
  last_donation_at {{TS}},
  donations_count INTEGER NOT NULL DEFAULT 0 CHECK (donations_count >= 0),
  status VARCHAR(12) NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive','suspended')),
  registered_at {{TS}} NOT NULL,
  updated_at {{TS}} NOT NULL
);
CREATE INDEX ix_donors_bt ON donors(blood_type, status);
CREATE INDEX ix_donors_gov ON donors(governorate_id, locality_id);
CREATE INDEX ix_donors_center ON donors(preferred_center_id);

CREATE TABLE donor_profiles (
  id {{PK}},
  donor_id INTEGER NOT NULL UNIQUE REFERENCES donors(id) ON DELETE CASCADE,
  gender VARCHAR(8) CHECK (gender IS NULL OR gender IN ('male','female')),
  birth_year INTEGER CHECK (birth_year IS NULL OR birth_year BETWEEN 1900 AND 2100),
  notify_in_app {{BOOL}} NOT NULL DEFAULT 1,
  notify_sms {{BOOL}} NOT NULL DEFAULT 0,
  notify_emergency {{BOOL}} NOT NULL DEFAULT 1,
  notify_reminders {{BOOL}} NOT NULL DEFAULT 1,
  updated_at {{TS}} NOT NULL
);

-- ========== المواعيد والتبرعات ==========
CREATE TABLE appointments (
  id {{PK}},
  donor_id INTEGER NOT NULL REFERENCES donors(id),
  center_id INTEGER NOT NULL REFERENCES blood_centers(id),
  appointment_date {{DATE}} NOT NULL,
  appointment_time {{TIME}} NOT NULL,
  status VARCHAR(16) NOT NULL DEFAULT 'booked'
     CHECK (status IN ('booked','confirmed','checked_in','completed','deferred','cancelled','no_show')),
  donor_notes VARCHAR(500),
  staff_notes VARCHAR(500),
  cancel_reason VARCHAR(255),
  reminder_sent_at {{TS}},
  created_at {{TS}} NOT NULL,
  updated_at {{TS}} NOT NULL
);
CREATE INDEX ix_appt_center_date ON appointments(center_id, appointment_date, appointment_time);
CREATE INDEX ix_appt_donor ON appointments(donor_id, appointment_date);
CREATE INDEX ix_appt_status ON appointments(status);

CREATE TABLE donations (
  id {{PK}},
  donor_id INTEGER NOT NULL REFERENCES donors(id),
  center_id INTEGER NOT NULL REFERENCES blood_centers(id),
  appointment_id INTEGER UNIQUE REFERENCES appointments(id),
  unit_number VARCHAR(40) NOT NULL UNIQUE,
  blood_type VARCHAR(3) NOT NULL CHECK (blood_type IN ({_BT})),
  volume_ml INTEGER NOT NULL DEFAULT 450 CHECK (volume_ml BETWEEN 100 AND 600),
  donated_at {{TS}} NOT NULL,
  -- القرار الطبي يُسجَّل بواسطة المختص فقط، ولا يتخذه النظام آليًا
  medical_decision_by VARCHAR(120) NOT NULL,
  status VARCHAR(12) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  rejection_reason VARCHAR(255),
  recorded_by INTEGER NOT NULL REFERENCES users(id),
  approved_by INTEGER REFERENCES users(id),
  approved_at {{TS}},
  notes VARCHAR(500),
  created_at {{TS}} NOT NULL
);
CREATE INDEX ix_donations_center ON donations(center_id, donated_at);
CREATE INDEX ix_donations_donor ON donations(donor_id, donated_at);
CREATE INDEX ix_donations_status ON donations(status, blood_type);

-- قرارات التقييم الطبي (تأجيل/رفض) كما يسجلها المختص
CREATE TABLE medical_assessments (
  id {{PK}},
  appointment_id INTEGER NOT NULL REFERENCES appointments(id),
  donor_id INTEGER NOT NULL REFERENCES donors(id),
  decision VARCHAR(12) NOT NULL CHECK (decision IN ('accepted','deferred','rejected')),
  assessed_by_name VARCHAR(120) NOT NULL,
  reason VARCHAR(255),
  defer_until {{DATE}},
  recorded_by INTEGER NOT NULL REFERENCES users(id),
  created_at {{TS}} NOT NULL
);
CREATE INDEX ix_assess_appt ON medical_assessments(appointment_id);

-- ========== طلبات الدم والنداءات ==========
CREATE TABLE blood_requests (
  id {{PK}},
  request_code VARCHAR(20) NOT NULL UNIQUE,
  blood_type VARCHAR(3) NOT NULL CHECK (blood_type IN ({_BT})),
  units_required INTEGER NOT NULL CHECK (units_required BETWEEN 1 AND 100),
  units_fulfilled INTEGER NOT NULL DEFAULT 0 CHECK (units_fulfilled >= 0),
  center_id INTEGER NOT NULL REFERENCES blood_centers(id),
  requesting_entity VARCHAR(150) NOT NULL,
  patient_reference VARCHAR(60),
  urgency VARCHAR(10) NOT NULL CHECK (urgency IN ('normal','medium','urgent','critical')),
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
     CHECK (status IN ('pending','approved','partially_fulfilled','fulfilled','rejected','cancelled')),
  needed_by {{DATE}},
  notes VARCHAR(1000),
  requested_by INTEGER NOT NULL REFERENCES users(id),
  approved_by INTEGER REFERENCES users(id),
  approved_at {{TS}},
  created_at {{TS}} NOT NULL,
  updated_at {{TS}} NOT NULL
);
CREATE INDEX ix_req_status ON blood_requests(status, urgency);
CREATE INDEX ix_req_center ON blood_requests(center_id, created_at);

CREATE TABLE emergency_appeals (
  id {{PK}},
  title VARCHAR(150) NOT NULL,
  blood_type VARCHAR(3) NOT NULL CHECK (blood_type IN ({_BT})),
  units_needed INTEGER NOT NULL CHECK (units_needed BETWEEN 1 AND 500),
  units_collected INTEGER NOT NULL DEFAULT 0 CHECK (units_collected >= 0),
  urgency VARCHAR(10) NOT NULL CHECK (urgency IN ('normal','medium','urgent','critical')),
  center_id INTEGER NOT NULL REFERENCES blood_centers(id),
  blood_request_id INTEGER REFERENCES blood_requests(id),
  message VARCHAR(1000),
  status VARCHAR(20) NOT NULL DEFAULT 'pending_approval'
     CHECK (status IN ('pending_approval','open','completed','closed','rejected')),
  created_by INTEGER NOT NULL REFERENCES users(id),
  approved_by INTEGER REFERENCES users(id),
  published_at {{TS}},
  expires_at {{DATE}},
  closed_at {{TS}},
  created_at {{TS}} NOT NULL,
  updated_at {{TS}} NOT NULL
);
CREATE INDEX ix_appeals_status ON emergency_appeals(status, published_at);

-- ========== المخزون ==========
CREATE TABLE blood_inventory (
  id {{PK}},
  center_id INTEGER NOT NULL REFERENCES blood_centers(id),
  blood_type VARCHAR(3) NOT NULL CHECK (blood_type IN ({_BT})),
  available_units INTEGER NOT NULL DEFAULT 0 CHECK (available_units >= 0),
  reserved_units INTEGER NOT NULL DEFAULT 0 CHECK (reserved_units >= 0),
  critical_level INTEGER NOT NULL DEFAULT 3 CHECK (critical_level >= 0),
  low_level INTEGER NOT NULL DEFAULT 8 CHECK (low_level >= 0),
  updated_at {{TS}} NOT NULL,
  updated_by INTEGER REFERENCES users(id),
  UNIQUE (center_id, blood_type)
);

CREATE TABLE blood_inventory_transactions (
  id {{PK}},
  inventory_id INTEGER NOT NULL REFERENCES blood_inventory(id),
  center_id INTEGER NOT NULL REFERENCES blood_centers(id),
  blood_type VARCHAR(3) NOT NULL,
  tx_type VARCHAR(16) NOT NULL
     CHECK (tx_type IN ('donation_in','issue_out','reserve','release','expire','discard','adjust','transfer_in','transfer_out')),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  available_after INTEGER NOT NULL,
  reserved_after INTEGER NOT NULL,
  reference_type VARCHAR(30),
  reference_id INTEGER,
  reason VARCHAR(255),
  created_by INTEGER REFERENCES users(id),
  created_at {{TS}} NOT NULL
);
CREATE INDEX ix_invtx_center ON blood_inventory_transactions(center_id, created_at);

-- ========== الإشعارات والمحتوى ==========
CREATE TABLE notifications (
  id {{PK}},
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category VARCHAR(30) NOT NULL,
  title VARCHAR(150) NOT NULL,
  body VARCHAR(1000) NOT NULL,
  link VARCHAR(255),
  is_read {{BOOL}} NOT NULL DEFAULT 0,
  read_at {{TS}},
  created_at {{TS}} NOT NULL
);
CREATE INDEX ix_notif_user ON notifications(user_id, is_read, created_at);

-- صندوق الإرسال للقنوات الخارجية (SMS / Push) — يُعالج بواسطة عامل خلفي
CREATE TABLE notification_outbox (
  id {{PK}},
  notification_id INTEGER REFERENCES notifications(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  channel VARCHAR(12) NOT NULL CHECK (channel IN ('sms','push','email')),
  status VARCHAR(10) NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','failed','skipped')),
  attempts INTEGER NOT NULL DEFAULT 0,
  last_error VARCHAR(255),
  created_at {{TS}} NOT NULL,
  sent_at {{TS}}
);
CREATE INDEX ix_outbox_status ON notification_outbox(status, channel);

CREATE TABLE educational_content (
  id {{PK}},
  title VARCHAR(200) NOT NULL,
  slug VARCHAR(120) NOT NULL UNIQUE,
  category VARCHAR(30) NOT NULL CHECK (category IN ('before','after','eligibility','myths','general','news')),
  summary VARCHAR(400),
  body TEXT NOT NULL,
  is_published {{BOOL}} NOT NULL DEFAULT 0,
  published_at {{TS}},
  author_id INTEGER REFERENCES users(id),
  created_at {{TS}} NOT NULL,
  updated_at {{TS}} NOT NULL
);

-- ========== التدقيق والتقارير والإعدادات ==========
CREATE TABLE audit_logs (
  id {{PK}},
  user_id INTEGER REFERENCES users(id),
  user_name VARCHAR(120),
  action VARCHAR(40) NOT NULL,
  entity_type VARCHAR(40),
  entity_id INTEGER,
  details {{JSON}},
  ip_address VARCHAR(45),
  user_agent VARCHAR(255),
  created_at {{TS}} NOT NULL
);
CREATE INDEX ix_audit_created ON audit_logs(created_at);
CREATE INDEX ix_audit_user ON audit_logs(user_id, created_at);
CREATE INDEX ix_audit_entity ON audit_logs(entity_type, entity_id);

CREATE TABLE reports (
  id {{PK}},
  report_type VARCHAR(40) NOT NULL,
  params {{JSON}},
  file_format VARCHAR(8) NOT NULL,
  row_count INTEGER NOT NULL DEFAULT 0,
  generated_by INTEGER REFERENCES users(id),
  created_at {{TS}} NOT NULL
);

CREATE TABLE system_settings (
  key VARCHAR(60) PRIMARY KEY,
  value VARCHAR(1000),
  description VARCHAR(255),
  updated_by INTEGER REFERENCES users(id),
  updated_at {{TS}} NOT NULL
);

CREATE TABLE rate_limits (
  key VARCHAR(160) PRIMARY KEY,
  window_start INTEGER NOT NULL,
  hits INTEGER NOT NULL
);
"""

SCHEMA_V2 = """
-- استعادة كلمة المرور برمز يُرسل عبر SMS
CREATE TABLE password_resets (
  id {PK},
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  code_hash VARCHAR(255) NOT NULL,
  expires_at {TS} NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  used_at {TS},
  created_at {TS} NOT NULL
);
CREATE INDEX ix_pwreset_user ON password_resets(user_id, created_at);
"""

SCHEMA_V3 = """
-- ملفات منشورة (مثل تطبيق أندرويد) تُحفظ في قاعدة البيانات
-- حتى لا تضيع في الاستضافات ذات القرص المؤقت (مثل Render المجاني)
CREATE TABLE stored_files (
  name VARCHAR(80) PRIMARY KEY,
  data {BLOB} NOT NULL,
  meta TEXT NOT NULL,
  updated_at {TS} NOT NULL
);
"""

MIGRATIONS = [
    (1, "initial schema", SCHEMA_V1),
    (2, "password resets", SCHEMA_V2),
    (3, "stored files", SCHEMA_V3),
]


def render(sql, dialect):
    for k, v in TYPES[dialect].items():
        sql = sql.replace("{" + k + "}", v)
    return sql


def migrate(db):
    """تطبيق الترحيلات غير المطبقة بالترتيب."""
    db.execute(
        "CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, name VARCHAR(120), applied_at VARCHAR(32))"
    )
    applied = {r["version"] for r in db.query("SELECT version FROM schema_migrations")}
    from .db import utcnow
    done = []
    for version, name, sql in MIGRATIONS:
        if version in applied:
            continue
        with db.transaction():
            for stmt in _split(render(sql, db.dialect)):
                db.execute(stmt)
            db.execute("INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)",
                       (version, name, utcnow()))
        done.append(version)
    return done


def _split(script):
    out, buf = [], []
    for line in script.splitlines():
        s = line.strip()
        if not s or s.startswith("--"):
            continue
        buf.append(line)
        if s.endswith(";"):
            out.append("\n".join(buf).rstrip().rstrip(";"))
            buf = []
    if buf:
        out.append("\n".join(buf))
    return out
