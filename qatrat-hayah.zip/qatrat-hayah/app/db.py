"""طبقة الوصول لقاعدة البيانات.

تدعم SQLite (للتجربة والنشر الصغير) و PostgreSQL (للإنتاج على مستوى السودان)
عبر واجهة موحّدة. كل الاستعلامات تستخدم معاملات (parameters) لمنع SQL Injection،
ولا يُسمح بتمرير أسماء أعمدة من المستخدم إلا عبر قوائم بيضاء.
"""
import re
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from flask import current_app, g

_IDENT = re.compile(r"^[a-z_][a-z0-9_]*$")


def utcnow():
    return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def _ident(name):
    if not _IDENT.match(name):
        raise ValueError(f"invalid identifier: {name}")
    return name


class Database:
    def __init__(self, url):
        self.url = url
        if url.startswith("sqlite:///"):
            self.dialect = "sqlite"
            self.path = url[len("sqlite:///"):]
        elif url.startswith(("postgresql://", "postgres://")):
            self.dialect = "postgres"
        else:
            raise ValueError("QH_DATABASE_URL غير مدعوم")
        self._conn = None
        self._tx_depth = 0

    # ---------- الاتصال ----------
    def connect(self):
        if self._conn is not None:
            return self._conn
        if self.dialect == "sqlite":
            conn = sqlite3.connect(self.path, timeout=15, isolation_level=None)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
            conn.execute("PRAGMA busy_timeout = 15000")
        else:  # PostgreSQL عبر psycopg 3 (المُوصى به)، أو psycopg2 كبديل
            try:
                import psycopg
                from psycopg.rows import dict_row
                conn = psycopg.connect(self.url, autocommit=True, row_factory=dict_row)
            except ImportError:  # pragma: no cover
                import psycopg2
                import psycopg2.extras
                conn = psycopg2.connect(self.url, cursor_factory=psycopg2.extras.RealDictCursor)
                conn.autocommit = True
        self._conn = conn
        return conn

    def close(self):
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def _sql(self, sql):
        if self.dialect == "postgres":
            sql = sql.replace("%", "%%").replace("?", "%s")
        return sql

    # ---------- التنفيذ ----------
    def execute(self, sql, params=()):
        conn = self.connect()
        if self.dialect == "sqlite":
            return conn.execute(sql, tuple(params))
        cur = conn.cursor()
        cur.execute(self._sql(sql), tuple(params))
        return cur

    def executescript(self, script):
        conn = self.connect()
        if self.dialect == "sqlite":
            conn.executescript(script)
        else:
            conn.cursor().execute(script)

    def query(self, sql, params=()):
        cur = self.execute(sql, params)
        return [dict(r) for r in cur.fetchall()]

    def one(self, sql, params=()):
        cur = self.execute(sql, params)
        r = cur.fetchone()
        return dict(r) if r is not None else None

    def scalar(self, sql, params=(), default=None):
        cur = self.execute(sql, params)
        r = cur.fetchone()
        if r is None:
            return default
        v = list(dict(r).values())[0] if not isinstance(r, tuple) else r[0]
        return default if v is None else v

    def insert(self, table, data):
        cols = [_ident(c) for c in data]
        ph = ", ".join("?" for _ in cols)
        sql = f"INSERT INTO {_ident(table)} ({', '.join(cols)}) VALUES ({ph})"
        if self.dialect == "postgres":
            cur = self.execute(sql + " RETURNING id", list(data.values()))
            return cur.fetchone()["id"]
        cur = self.execute(sql, list(data.values()))
        return cur.lastrowid

    def update(self, table, row_id, data):
        if not data:
            return 0
        sets = ", ".join(f"{_ident(c)} = ?" for c in data)
        cur = self.execute(f"UPDATE {_ident(table)} SET {sets} WHERE id = ?", [*data.values(), row_id])
        return cur.rowcount

    def get(self, table, row_id):
        return self.one(f"SELECT * FROM {_ident(table)} WHERE id = ?", (row_id,))

    @contextmanager
    def transaction(self):
        """معاملة ذرّية؛ تدعم التداخل عبر SAVEPOINT."""
        conn = self.connect()
        self._tx_depth += 1
        name = f"sp{self._tx_depth}"
        try:
            if self._tx_depth == 1:
                self.execute("BEGIN IMMEDIATE" if self.dialect == "sqlite" else "BEGIN")
            else:
                self.execute(f"SAVEPOINT {name}")
            yield self
            if self._tx_depth == 1:
                self.execute("COMMIT")
            else:
                self.execute(f"RELEASE SAVEPOINT {name}")
        except Exception:
            if self._tx_depth == 1:
                self.execute("ROLLBACK")
            else:
                self.execute(f"ROLLBACK TO SAVEPOINT {name}")
            raise
        finally:
            self._tx_depth -= 1

    # ---------- دوال خاصة باللهجة ----------
    def month_expr(self, col):
        _ident(col.replace(".", "_"))
        if self.dialect == "sqlite":
            return f"substr({col}, 1, 7)"
        return f"to_char({col}, 'YYYY-MM')"

    def like(self):
        return "LIKE" if self.dialect == "sqlite" else "ILIKE"


def get_db():
    if "db" not in g:
        g.db = Database(current_app.config["DATABASE_URL"])
    return g.db


def close_db(_exc=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def paginate(db, sql, params, page, per_page=20):
    """ترقيم الصفحات بشكل آمن."""
    page = max(1, int(page or 1))
    total = db.scalar(f"SELECT COUNT(*) AS c FROM ({sql}) t", params, 0)
    rows = db.query(f"{sql} LIMIT ? OFFSET ?", [*params, per_page, (page - 1) * per_page])
    pages = max(1, (total + per_page - 1) // per_page)
    return {"rows": rows, "total": total, "page": min(page, pages), "pages": pages, "per_page": per_page}
