"""التسجيل وتسجيل الدخول والخروج."""
from flask import Blueprint, abort, current_app, flash, g, redirect, render_template, request, session, url_for

from .. import audit
from ..db import get_db, utcnow
from ..security import (client_ip, dummy_verify, hash_password, is_locked, login_session, rate_limited,
                        register_login_failure, reset_rate, verify_password)
from ..services.common import get_setting, unique_code
from ..validators import Form
from .public import active_governorates

bp = Blueprint("auth", __name__)

GENERIC_LOGIN_ERROR = "رقم الهاتف أو كلمة المرور غير صحيحة."


def _safe_next(url):
    if url and url.startswith("/") and not url.startswith("//") and "\\" not in url:
        return url
    return None


def validate_donor_fields(f, db):
    """حقول ملف المتبرع المشتركة بين التسجيل وإكمال الملف والتعديل."""
    bt = f.raw("blood_type")
    if bt == "unknown":
        f.clean["blood_type"] = None
    else:
        f.blood_type(required=False)
    gov = f.fk("governorate_id", "الولاية", db, "governorates", where="is_active = 1")
    loc = None
    if gov:
        loc = f.fk("locality_id", "المحلية", db, "localities", where=f"governorate_id = {int(gov['id'])} AND is_active = 1")
    if loc and f.raw("preferred_center_id"):
        f.fk("preferred_center_id", "المركز المفضل", db, "blood_centers",
             required=False, where=f"governorate_id = {int(gov['id'])} AND status = 'active'")
    else:
        f.clean["preferred_center_id"] = None
    f.choice("gender", "الجنس", ["male", "female"], required=False)
    f.integer("birth_year", "سنة الميلاد", required=False, min_value=1930, max_value=2012)


def create_donor_record(db, user_id, f):
    now = utcnow()
    did = db.insert("donors", {
        "user_id": user_id, "donor_code": unique_code("donors", "donor_code", "D-"),
        "blood_type": f.clean.get("blood_type"), "blood_type_verified": 0,
        "governorate_id": f.clean["governorate_id"], "locality_id": f.clean["locality_id"],
        "preferred_center_id": f.clean.get("preferred_center_id"), "donations_count": 0, "status": "active",
        "registered_at": now, "updated_at": now})
    db.insert("donor_profiles", {"donor_id": did, "gender": f.clean.get("gender"), "birth_year": f.clean.get("birth_year"),
                                 "notify_in_app": 1, "notify_sms": 0, "notify_emergency": 1, "notify_reminders": 1,
                                 "updated_at": now})
    return did


@bp.route("/register", methods=["GET", "POST"])
def register():
    if g.user:
        return redirect(url_for("donor.dashboard"))
    db = get_db()
    if get_setting("public_registration", "1") != "1":
        flash("التسجيل عبر الموقع متوقف مؤقتًا. يمكنك التسجيل في أقرب مركز.", "info")
        return redirect(url_for("public.home"))
    form = Form(request.form)
    if request.method == "POST":
        if rate_limited(f"register:{client_ip()}", 10, 3600):
            abort(429)
        form.text("full_name", "الاسم الكامل", min_len=5, max_len=120)
        form.phone()
        form.password(confirm="password_confirm")
        form.email()
        validate_donor_fields(form, db)
        if not request.form.get("consent"):
            form.error("consent", "يجب الموافقة على سياسة الخصوصية للمتابعة.")
        if form.ok and db.one("SELECT id FROM users WHERE phone = ?", (form.clean["phone"],)):
            form.error("phone", "هذا الرقم مسجل مسبقًا. يمكنك تسجيل الدخول.")
        if form.ok and form.clean.get("email") and db.one("SELECT id FROM users WHERE email = ?", (form.clean["email"],)):
            form.error("email", "هذا البريد مستخدم مسبقًا.")
        if form.ok:
            with db.transaction():
                now = utcnow()
                uid = db.insert("users", {"full_name": form.clean["full_name"], "phone": form.clean["phone"],
                                          "email": form.clean.get("email"), "password_hash": hash_password(form.clean["password"]),
                                          "status": "active", "is_staff": 0, "created_at": now, "updated_at": now})
                db.insert("user_roles", {"user_id": uid, "role_id": db.scalar("SELECT id FROM roles WHERE code='donor'"),
                                         "created_at": now})
                create_donor_record(db, uid, form)
            user = db.get("users", uid)
            audit.log("register", "user", uid, user=user)
            login_session(user)
            flash("تم إنشاء حسابك بنجاح. مرحبًا بك في قطرة حياة!", "success")
            return redirect(url_for("donor.dashboard"))
    return render_template("auth/register.html", form=form, governorates=active_governorates())


@bp.route("/login", methods=["GET", "POST"])
def login():
    if g.user:
        return redirect(url_for("admin.dashboard") if g.user.is_staff else url_for("donor.dashboard"))
    form = Form(request.form)
    if request.method == "POST":
        db = get_db()
        ip = client_ip()
        form.phone()
        pw = request.form.get("password") or ""
        cfg = current_app.config
        if rate_limited(f"login-ip:{ip}", cfg["LOGIN_MAX_ATTEMPTS"] * 4, cfg["LOGIN_WINDOW_SECONDS"]):
            abort(429)
        user = db.one("SELECT * FROM users WHERE phone = ?", (form.clean.get("phone"),)) if form.clean.get("phone") else None
        if user is None:
            dummy_verify(pw)
            form.errors = {"_": GENERIC_LOGIN_ERROR}
            audit.log("login_failed", "user", None, {"phone": (form.clean.get("phone") or "")[-4:]}, user={})
        elif is_locked(user):
            form.errors = {"_": "تم إيقاف الدخول مؤقتًا بسبب محاولات متكررة. حاول بعد 15 دقيقة."}
        elif not verify_password(user["password_hash"], pw):
            register_login_failure(db, user)
            form.errors = {"_": GENERIC_LOGIN_ERROR}
            audit.log("login_failed", "user", user["id"], user=user)
        elif user["status"] != "active":
            form.errors = {"_": "هذا الحساب غير مفعّل. يرجى التواصل مع الإدارة."}
        else:
            db.update("users", user["id"], {"failed_logins": 0, "locked_until": None, "last_login_at": utcnow()})
            reset_rate(f"login-ip:{ip}")
            login_session(user)
            audit.log("login", "user", user["id"], user=user)
            nxt = _safe_next(request.args.get("next"))
            if nxt:
                return redirect(nxt)
            from ..security import load_user
            u = load_user(user["id"])
            return redirect(url_for("admin.dashboard") if u and u.is_staff else url_for("donor.dashboard"))
    return render_template("auth/login.html", form=form)


@bp.route("/logout", methods=["POST"])
def logout():
    if g.user:
        audit.log("logout", "user", g.user.id)
    session.clear()
    flash("تم تسجيل الخروج بنجاح.", "success")
    return redirect(url_for("public.home"))


# ---------------- استعادة كلمة المرور برمز SMS ----------------
RESET_TTL_MIN = 10


@bp.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    from ..notifications import sms_provider
    from ..services.common import get_setting
    sms = sms_provider()
    form = Form(request.form)
    if request.method == "POST" and sms:
        form.phone()
        if form.ok:
            if rate_limited(f"reset-ip:{client_ip()}", 10, 3600) or rate_limited(f"reset-phone:{form.clean['phone']}", 3, 3600):
                abort(429)
            db = get_db()
            user = db.one("SELECT * FROM users WHERE phone = ? AND status = 'active'", (form.clean["phone"],))
            if user:
                import secrets as _s
                from datetime import datetime, timedelta, timezone
                code = f"{_s.randbelow(10 ** 6):06d}"
                exp = (datetime.now(timezone.utc) + timedelta(minutes=RESET_TTL_MIN)).strftime("%Y-%m-%d %H:%M:%S")
                db.execute("UPDATE password_resets SET used_at = ? WHERE user_id = ? AND used_at IS NULL", (utcnow(), user["id"]))
                db.insert("password_resets", {"user_id": user["id"], "code_hash": hash_password(code), "expires_at": exp,
                                              "attempts": 0, "created_at": utcnow()})
                try:
                    sms.send_text(user["phone"], f"قطرة حياة: رمز استعادة كلمة المرور {code} صالح لمدة {RESET_TTL_MIN} دقائق. لا تشاركه مع أحد.")
                except Exception:
                    current_app.logger.exception("SMS send failed")
                audit.log("password_change", "user", user["id"], {"إجراء": "طلب رمز استعادة"}, user=user)
            # نفس الرسالة دائمًا حتى لا يُكشف هل الرقم مسجل
            flash("إذا كان الرقم مسجلًا ستصلك رسالة نصية برمز الاستعادة خلال دقائق.", "info")
            return redirect(url_for("auth.reset_password", phone=request.form.get("phone", "")))
    return render_template("auth/forgot.html", form=form, sms=sms, support_phone=get_setting("support_phone"))


@bp.route("/reset-password", methods=["GET", "POST"])
def reset_password():
    from ..notifications import sms_provider
    if not sms_provider():
        return redirect(url_for("auth.forgot_password"))
    form = Form(request.form if request.method == "POST" else {"phone": request.args.get("phone", "")})
    if request.method == "POST":
        if rate_limited(f"reset-verify:{client_ip()}", 20, 3600):
            abort(429)
        form.phone()
        code = (request.form.get("code") or "").strip()
        form.password(confirm="password_confirm")
        if form.ok:
            db = get_db()
            user = db.one("SELECT * FROM users WHERE phone = ? AND status = 'active'", (form.clean["phone"],))
            pr = db.one("SELECT * FROM password_resets WHERE user_id = ? AND used_at IS NULL ORDER BY id DESC LIMIT 1",
                        (user["id"],)) if user else None
            valid = bool(pr and str(pr["expires_at"]) > utcnow() and pr["attempts"] < 5 and verify_password(pr["code_hash"], code))
            if pr and not valid:
                db.execute("UPDATE password_resets SET attempts = attempts + 1 WHERE id = ?", (pr["id"],))
            if not valid:
                form.error("code", "الرمز غير صحيح أو منتهي الصلاحية.")
            else:
                with db.transaction():
                    db.execute("UPDATE password_resets SET used_at = ? WHERE id = ?", (utcnow(), pr["id"]))
                    db.execute("UPDATE users SET password_hash = ?, auth_version = auth_version + 1, failed_logins = 0, "
                               "locked_until = NULL, updated_at = ? WHERE id = ?",
                               (hash_password(form.clean["password"]), utcnow(), user["id"]))
                audit.log("password_change", "user", user["id"], {"إجراء": "استعادة برمز SMS"}, user=user)
                flash("تم تغيير كلمة المرور. سجّل الدخول الآن.", "success")
                return redirect(url_for("auth.login"))
    return render_template("auth/reset.html", form=form)
