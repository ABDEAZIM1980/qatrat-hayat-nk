"""الإعداد الأول للنسخة الحقيقية: إنشاء حساب مدير النظام من المتصفح.

تظهر هذه الصفحة فقط عندما لا يوجد أي مدير نظام في قاعدة البيانات، وتُغلق نهائيًا بعد الإنشاء.
يمكن حمايتها برمز QH_SETUP_TOKEN حتى لا يسبقك أحد إلى إنشاء الحساب بعد رفع الموقع.
"""
import hmac

from flask import Blueprint, abort, current_app, flash, redirect, render_template, request, url_for

from .. import audit
from ..db import get_db
from ..security import client_ip, login_session, rate_limited
from ..validators import Form

bp = Blueprint("setup", __name__)

_ALLOWED = {"setup.setup", "static", "public.health", "public.service_worker", "public.manifest", "public.offline", "public.robots", "public.ping", "public.run_tasks", "public.assetlinks"}


def _has_admin():
    if current_app.config.get("_SETUP_DONE"):
        return True
    ok = bool(get_db().scalar(
        "SELECT COUNT(*) AS n FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE r.code = 'super_admin'", (), 0))
    if ok:
        current_app.config["_SETUP_DONE"] = True
    return ok


def setup_required_redirect():
    if request.endpoint in _ALLOWED or _has_admin():
        return None
    if request.path.startswith("/api/"):
        from flask import jsonify
        return jsonify(error="setup_required", message="المنصة لم تُجهَّز بعد"), 503
    return redirect(url_for("setup.setup"))


@bp.route("/setup", methods=["GET", "POST"])
def setup():
    if _has_admin():
        abort(404)
    from ..security import csrf_protect, csrf_token
    csrf_token()
    form = Form(request.form)
    token_required = bool(current_app.config.get("SETUP_TOKEN"))
    if request.method == "POST":
        csrf_protect()
        if rate_limited(f"setup:{client_ip()}", 10, 3600):
            abort(429)
        if token_required and not hmac.compare_digest(request.form.get("setup_token", ""), current_app.config["SETUP_TOKEN"]):
            form.error("setup_token", "رمز الإعداد غير صحيح.")
        form.text("full_name", "الاسم الكامل", min_len=5, max_len=120)
        form.phone()
        form.email()
        form.password(confirm="password_confirm")
        if form.ok:
            db = get_db()
            from ..seed import create_super_admin
            if db.one("SELECT id FROM users WHERE phone = ?", (form.clean["phone"],)):
                form.error("phone", "هذا الرقم مسجل مسبقًا.")
            else:
                with db.transaction():
                    uid = create_super_admin(db, form.clean["full_name"], form.clean["phone"], form.clean["password"])
                    if form.clean.get("email"):
                        db.update("users", uid, {"email": form.clean["email"]})
                current_app.config["_SETUP_DONE"] = True
                user = db.get("users", uid)
                audit.log("user_create", "user", uid, {"إجراء": "الإعداد الأول — مدير النظام"}, user=user)
                login_session(user)
                flash("تم تجهيز المنصة وإنشاء حساب مدير النظام. ابدأ بإضافة المراكز والمستخدمين.", "success")
                return redirect(url_for("admin.dashboard"))
    return render_template("setup.html", form=form, token_required=token_required)
