from flask import g, render_template, request

from ...db import get_db
from ...rbac import center_filter, donor_filter
from ...security import permission_required
from ...services import stats
from . import bp, scoped_governorates


@bp.route("/")
@permission_required("dashboard.view")
def dashboard():
    data = stats.dashboard(g.user.scope)
    s = g.user.scope
    if s.is_global:
        level = "الإدارة العامة – جميع الولايات"
    elif s.governorate_ids:
        level = "لوحة الولاية: " + "، ".join(x["name_ar"] for x in scoped_governorates())
    elif s.locality_ids:
        db = get_db()
        level = "لوحة المحلية: " + "، ".join(r["name_ar"] for r in db.query(
            f"SELECT name_ar FROM localities WHERE id IN ({','.join('?' for _ in s.locality_ids)})", sorted(s.locality_ids)))
    else:
        db = get_db()
        level = "لوحة المركز: " + "، ".join(r["name"] for r in db.query(
            f"SELECT name FROM blood_centers WHERE id IN ({','.join('?' for _ in s.center_ids)})", sorted(s.center_ids)))
    onboarding = None
    if s.is_global and g.user.can("centers.manage"):
        db = get_db()
        onboarding = [
            ("راجع الولايات والمحليات والمدن وفعّل ما يلزم", db.scalar("SELECT COUNT(*) AS n FROM localities", (), 0) > 0,
             "admin.geography", {"level": "governorates"}),
            ("أضف المراكز وبنوك الدم (يدويًا أو باستيراد ملف Excel)", data["kpi"]["centers"] > 0, "admin.centers", {}),
            ("أنشئ حسابات مديري الولايات والمراكز والموظفين",
             db.scalar("SELECT COUNT(*) AS n FROM users WHERE is_staff = 1", (), 0) > 1, "admin.user_new", {}),
            ("اضبط جداول استقبال المتبرعين لكل مركز", db.scalar("SELECT COUNT(*) AS n FROM center_schedules", (), 0) > 0,
             "admin.centers", {}),
            ("راجع إعدادات النظام ورقم الدعم", db.scalar(
                "SELECT COUNT(*) AS n FROM system_settings WHERE updated_by IS NOT NULL", (), 0) > 0, "admin.settings", {}),
        ]
        if all(x[1] for x in onboarding):
            onboarding = None
    return render_template("admin/dashboard.html", data=data, level=level, onboarding=onboarding)


@bp.route("/search")
@permission_required("dashboard.view")
def search():
    """بحث سريع موحّد ضمن نطاق المستخدم."""
    db = get_db()
    q = (request.args.get("q") or "").strip()[:60]
    results = {"donors": [], "centers": [], "requests": [], "appointments": [], "localities": [], "governorates": []}
    if len(q) >= 2:
        like = db.like()
        p = f"%{q}%"
        from ...validators import normalize_phone
        phone = normalize_phone(q)
        cf, cp = center_filter(g.user.scope)
        if g.user.can("donors.view"):
            df, dp = donor_filter(db, g.user.scope)
            results["donors"] = db.query(
                f"""SELECT d.id, d.donor_code, d.blood_type, u.full_name, u.phone FROM donors d JOIN users u ON u.id = d.user_id
                    WHERE {df} AND (u.full_name {like} ? OR d.donor_code {like} ? OR u.phone = ?) ORDER BY u.full_name LIMIT 10""",
                [*dp, p, p, phone or "-"])
        results["centers"] = db.query(
            f"SELECT c.id, c.name, c.status FROM blood_centers c WHERE {cf} AND c.name {like} ? ORDER BY c.name LIMIT 10",
            [*cp, p])
        if g.user.can("requests.view"):
            results["requests"] = db.query(
                f"""SELECT r.id, r.request_code, r.blood_type, r.status, r.requesting_entity FROM blood_requests r
                    JOIN blood_centers c ON c.id = r.center_id
                    WHERE {cf} AND (r.request_code {like} ? OR r.requesting_entity {like} ?) ORDER BY r.created_at DESC LIMIT 10""",
                [*cp, p, p])
        if g.user.can("appointments.view"):
            results["appointments"] = db.query(
                f"""SELECT a.id, a.appointment_date, a.appointment_time, a.status, u.full_name, c.name AS center_name
                    FROM appointments a JOIN blood_centers c ON c.id = a.center_id JOIN donors d ON d.id = a.donor_id
                    JOIN users u ON u.id = d.user_id
                    WHERE {cf} AND (u.full_name {like} ? OR d.donor_code {like} ? OR u.phone = ?)
                    ORDER BY a.appointment_date DESC LIMIT 10""", [*cp, p, p, phone or "-"])
        govs = scoped_governorates()
        gids = [x["id"] for x in govs]
        results["governorates"] = [x for x in govs if q in x["name_ar"]][:10]
        if gids:
            results["localities"] = db.query(
                f"""SELECT l.id, l.name_ar, g.name_ar AS governorate FROM localities l JOIN governorates g ON g.id = l.governorate_id
                    WHERE l.governorate_id IN ({','.join('?' for _ in gids)}) AND l.name_ar {like} ? LIMIT 10""", [*gids, p])
    total = sum(len(v) for v in results.values())
    return render_template("admin/search.html", q=q, results=results, total=total)
