"""إدارة الهيكل الجغرافي: الولايات ← المحليات ← المدن (بدون أي قيم ثابتة في الكود)."""
from flask import abort, flash, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, utcnow
from ...security import permission_required
from ...validators import Form
from . import bp

LEVELS = {
    "governorates": {"title": "الولايات", "single": "ولاية", "parent": None, "entity": "governorate"},
    "localities": {"title": "المحليات", "single": "محلية", "parent": ("governorates", "governorate_id"), "entity": "locality"},
    "cities": {"title": "المدن", "single": "مدينة", "parent": ("localities", "locality_id"), "entity": "city"},
}


def _rows(level, parent_id):
    db = get_db()
    if level == "governorates":
        return db.query(
            """SELECT g.*, (SELECT COUNT(*) FROM localities l WHERE l.governorate_id = g.id) AS children,
               (SELECT COUNT(*) FROM blood_centers c WHERE c.governorate_id = g.id) AS centers
               FROM governorates g ORDER BY g.is_active DESC, g.name_ar""")
    if level == "localities":
        return db.query(
            """SELECT l.*, (SELECT COUNT(*) FROM cities c WHERE c.locality_id = l.id) AS children,
               (SELECT COUNT(*) FROM blood_centers c WHERE c.locality_id = l.id) AS centers
               FROM localities l WHERE l.governorate_id = ? ORDER BY l.name_ar""", (parent_id,))
    return db.query(
        """SELECT ci.*, 0 AS children, (SELECT COUNT(*) FROM blood_centers c WHERE c.city_id = ci.id) AS centers
           FROM cities ci WHERE ci.locality_id = ? ORDER BY ci.name_ar""", (parent_id,))


def _validate(level, form, db, parent_id, row_id=None):
    form.text("name_ar", "الاسم بالعربية", min_len=2, max_len=80)
    form.text("name_en", "الاسم بالإنجليزية", required=False, max_len=80)
    if level == "governorates":
        code = form.text("code", "الرمز", required=False, max_len=10)
        if code:
            form.clean["code"] = code.upper()
    form.boolean("is_active")
    if not form.ok:
        return
    if level == "governorates":
        dup = db.one("SELECT id FROM governorates WHERE name_ar = ? AND id != ?", (form.clean["name_ar"], row_id or 0))
        if form.clean.get("code") and db.one("SELECT id FROM governorates WHERE code = ? AND id != ?",
                                             (form.clean["code"], row_id or 0)):
            form.error("code", "الرمز مستخدم لولاية أخرى.")
    else:
        pcol = LEVELS[level]["parent"][1]
        dup = db.one(f"SELECT id FROM {level} WHERE name_ar = ? AND {pcol} = ? AND id != ?",
                     (form.clean["name_ar"], parent_id, row_id or 0))
    if dup:
        form.error("name_ar", "هذا الاسم موجود مسبقًا.")


@bp.route("/geography/<level>", methods=["GET", "POST"])
@bp.route("/geography/<level>/<int:parent_id>", methods=["GET", "POST"])
@permission_required("geography.manage")
def geography(level, parent_id=None):
    if level not in LEVELS:
        abort(404)
    db = get_db()
    meta = LEVELS[level]
    parent = chain = None
    if meta["parent"]:
        parent = db.get(meta["parent"][0], parent_id or 0)
        if not parent:
            abort(404)
        chain = []
        if level == "cities":
            chain.append(db.get("governorates", parent["governorate_id"]))
        chain.append(parent)
    form = Form(request.form)
    if request.method == "POST":
        _validate(level, form, db, parent_id)
        if form.ok:
            data = {"name_ar": form.clean["name_ar"], "name_en": form.clean.get("name_en"),
                    "is_active": form.clean["is_active"], "created_at": utcnow()}
            if level == "governorates":
                data["code"] = form.clean.get("code")
            else:
                data[meta["parent"][1]] = parent_id
            rid = db.insert(level, data)
            audit.log("geo_create", meta["entity"], rid, {"الاسم": data["name_ar"]})
            flash(f"تمت إضافة {meta['single']}: {data['name_ar']}.", "success")
            return redirect(request.path)
    else:
        form = Form({"is_active": "1"})
    return render_template("admin/geography.html", level=level, meta=meta, rows=_rows(level, parent_id), parent=parent,
                           chain=chain, form=form)


@bp.route("/geography/<level>/edit/<int:row_id>", methods=["GET", "POST"])
@permission_required("geography.manage")
def geography_edit(level, row_id):
    if level not in LEVELS:
        abort(404)
    db = get_db()
    meta = LEVELS[level]
    row = db.get(level, row_id)
    if not row:
        abort(404)
    parent_id = row.get(meta["parent"][1]) if meta["parent"] else None
    if request.method == "POST":
        form = Form(request.form)
        _validate(level, form, db, parent_id, row_id)
        if form.ok:
            data = {"name_ar": form.clean["name_ar"], "name_en": form.clean.get("name_en"), "is_active": form.clean["is_active"]}
            if level == "governorates":
                data["code"] = form.clean.get("code")
            changes = audit.diff(row, data, list(data))
            db.update(level, row_id, data)
            audit.log("geo_update", meta["entity"], row_id, changes)
            flash("تم حفظ التعديلات.", "success")
            return redirect(url_for("admin.geography", level=level, parent_id=parent_id))
    else:
        form = Form({**row, "is_active": "1" if row["is_active"] else ""})
    return render_template("admin/geography_edit.html", level=level, meta=meta, row=row, form=form, parent_id=parent_id)
