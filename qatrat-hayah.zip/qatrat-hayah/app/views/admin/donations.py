"""سجل التبرعات: تسجيل تبرع مباشر (بدون موعد)، واعتماد/رفض الوحدات بعد الفحص."""
from flask import abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate
from ...rbac import center_filter
from ...security import permission_required
from ...services import donations as don_svc
from ...timeutil import local_now, local_to_utc_str
from ...validators import Form, normalize_phone
from . import bp, require_center, scoped_centers


@bp.route("/donations")
@permission_required("donations.record", "donations.approve", "reports.view")
def donations():
    db = get_db()
    cf, cp = center_filter(g.user.scope)
    where, params = [cf], list(cp)
    for key, col in (("center_id", "x.center_id"),):
        v = request.args.get(key, type=int)
        if v:
            where.append(f"{col} = ?"); params.append(v)
    if request.args.get("status") in ("pending", "approved", "rejected"):
        where.append("x.status = ?"); params.append(request.args["status"])
    if request.args.get("blood_type"):
        where.append("x.blood_type = ?"); params.append(request.args["blood_type"])
    q = (request.args.get("q") or "").strip()[:60]
    if q:
        where.append(f"(x.unit_number {db.like()} ? OR d.donor_code {db.like()} ? OR u.full_name {db.like()} ?)")
        params += [f"%{q}%"] * 3
    for key, op in (("date_from", ">="), ("date_to", "<=")):
        v = request.args.get(key)
        if v:
            f = Form({"d": v}); f.date("d", "التاريخ")
            if f.ok:
                where.append(f"x.donated_at {op} ?"); params.append(f.clean["d"] + (" 23:59:59" if op == "<=" else ""))
    page = paginate(db, f"""SELECT x.*, c.name AS center_name, d.donor_code, u.full_name FROM donations x
        JOIN blood_centers c ON c.id = x.center_id JOIN donors d ON d.id = x.donor_id JOIN users u ON u.id = d.user_id
        WHERE {' AND '.join(where)} ORDER BY x.status = 'pending' DESC, x.donated_at DESC""", params,
                    request.args.get("page", 1, type=int), 30)
    return render_template("admin/donations.html", page=page, centers=scoped_centers())


def _get(donation_id):
    d = get_db().one(
        """SELECT x.*, c.name AS center_name, d.donor_code, d.id AS donor_id, u.full_name, rb.full_name AS recorded_by_name,
           ab.full_name AS approved_by_name FROM donations x JOIN blood_centers c ON c.id = x.center_id
           JOIN donors d ON d.id = x.donor_id JOIN users u ON u.id = d.user_id JOIN users rb ON rb.id = x.recorded_by
           LEFT JOIN users ab ON ab.id = x.approved_by WHERE x.id = ?""", (donation_id,))
    if not d:
        abort(404)
    require_center(d["center_id"])
    return d


@bp.route("/donations/<int:donation_id>")
@permission_required("donations.record", "donations.approve", "reports.view")
def donation_detail(donation_id):
    return render_template("admin/donation_detail.html", x=_get(donation_id))


@bp.route("/donations/<int:donation_id>/approve", methods=["POST"])
@permission_required("donations.approve")
def donation_approve(donation_id):
    x = _get(donation_id)
    try:
        don_svc.approve(get_db().get("donations", donation_id), g.user.id)
        audit.log("donation_approve", "donation", donation_id, {"رقم الوحدة": x["unit_number"], "الفصيلة": x["blood_type"]})
        audit.log("inventory_adjust", "inventory", x["center_id"], {"حركة": "إضافة من تبرع", "الفصيلة": x["blood_type"], "الكمية": 1})
        flash("تم اعتماد الوحدة وإضافتها للمخزون وتحديث سجل المتبرع.", "success")
    except don_svc.DonationError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.donation_detail", donation_id=donation_id))


@bp.route("/donations/<int:donation_id>/reject", methods=["POST"])
@permission_required("donations.approve")
def donation_reject(donation_id):
    x = _get(donation_id)
    f = Form(request.form)
    f.text("reason", "سبب عدم الاعتماد", min_len=3, max_len=255)
    if not f.ok:
        flash("يرجى كتابة سبب عدم الاعتماد.", "error")
        return redirect(url_for("admin.donation_detail", donation_id=donation_id))
    try:
        don_svc.reject(get_db().get("donations", donation_id), g.user.id, f.clean["reason"])
        audit.log("donation_reject", "donation", donation_id, {"رقم الوحدة": x["unit_number"]})
        flash("تم تسجيل عدم اعتماد الوحدة. تواصل مع المتبرع بشكل سري إذا لزم الأمر.", "success")
    except don_svc.DonationError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.donation_detail", donation_id=donation_id))


@bp.route("/donations/new", methods=["GET", "POST"])
@permission_required("donations.record")
def donation_new():
    """تسجيل تبرع لمتبرع حضر بدون موعد (بعد قبول المختص)."""
    db = get_db()
    centers = scoped_centers(active_only=True)
    form = Form(request.form or request.args)
    donor = None
    lookup = (request.values.get("lookup") or "").strip()[:40]
    if lookup:
        phone = normalize_phone(lookup)
        donor = db.one(f"""SELECT d.*, u.full_name FROM donors d JOIN users u ON u.id = d.user_id
                           WHERE (d.donor_code = ? OR u.phone = ?)""", (lookup.upper(), phone or "-"))
        if not donor:
            form.error("lookup", "لم يتم العثور على متبرع بهذا الرقم أو الرمز. يمكنك تسجيله أولًا.")
        elif donor["status"] != "active":
            form.error("lookup", "حساب هذا المتبرع غير نشط.")
            donor = None
    if request.method == "POST" and donor and request.form.get("confirm_step"):
        center = form.fk("center_id", "المركز", db, "blood_centers", where="status = 'active'")
        if center:
            require_center(center["id"])
        form.blood_type()
        form.integer("volume_ml", "الحجم (مل)", min_value=100, max_value=600)
        form.text("assessed_by_name", "اسم المختص", min_len=3, max_len=120)
        form.text("unit_number", "رقم الوحدة", required=False, max_len=40)
        form.text("notes", "ملاحظات", required=False, max_len=500)
        if not request.form.get("accepted"):
            form.error("accepted", "يجب تأكيد أن المختص قرر قبول التبرع.")
        if form.ok:
            try:
                did = don_svc.record_donation(donor, center["id"], form.clean["blood_type"], form.clean["volume_ml"],
                                              local_to_utc_str(local_now().replace(tzinfo=None)), form.clean["assessed_by_name"],
                                              g.user.id, notes=form.clean.get("notes"), unit_number=form.clean.get("unit_number"))
                audit.log("donation_record", "donation", did, {"بدون موعد": True, "الفصيلة": form.clean["blood_type"]})
                flash("تم تسجيل التبرع، وهو بانتظار الفحص والاعتماد.", "success")
                return redirect(url_for("admin.donation_detail", donation_id=did))
            except don_svc.DonationError as e:
                form.error("unit_number", str(e))
    return render_template("admin/donation_form.html", form=form, donor=donor, centers=centers, lookup=lookup)
