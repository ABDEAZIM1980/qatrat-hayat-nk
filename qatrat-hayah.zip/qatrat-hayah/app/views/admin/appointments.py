"""إدارة المواعيد في المركز: التأكيد، تسجيل الحضور، التقييم الطبي، تسجيل التبرع."""
from datetime import timedelta

from flask import abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate
from ...rbac import center_filter
from ...security import permission_required
from ...services import appointments as appt_svc
from ...services import donations as don_svc
from ...timeutil import local_now, local_today, local_to_utc_str
from ...validators import Form, normalize_phone
from . import bp, require_center, scoped_centers


def _get(appt_id):
    db = get_db()
    a = db.one(
        """SELECT a.*, c.name AS center_name, d.donor_code, d.blood_type AS donor_blood_type, d.blood_type_verified,
           d.id AS donor_id, d.user_id AS donor_user_id, u.full_name, u.phone, d.last_donation_at, d.donations_count
           FROM appointments a JOIN blood_centers c ON c.id = a.center_id JOIN donors d ON d.id = a.donor_id
           JOIN users u ON u.id = d.user_id WHERE a.id = ?""", (appt_id,))
    if not a:
        abort(404)
    require_center(a["center_id"])
    return a


@bp.route("/appointments")
@permission_required("appointments.view")
def appointments():
    db = get_db()
    cf, cp = center_filter(g.user.scope)
    where, params = [cf], list(cp)
    day = request.args.get("date")
    rng = request.args.get("range", "today" if not day else "")
    today = local_today()
    if day:
        f = Form({"d": day}); f.date("d", "التاريخ")
        if f.ok:
            where.append("a.appointment_date = ?"); params.append(f.clean["d"])
    elif rng == "today":
        where.append("a.appointment_date = ?"); params.append(today.isoformat())
    elif rng == "upcoming":
        where.append("a.appointment_date >= ?"); params.append(today.isoformat())
    elif rng == "week":
        where.append("a.appointment_date BETWEEN ? AND ?"); params += [today.isoformat(), (today + timedelta(days=7)).isoformat()]
    elif rng == "past":
        where.append("a.appointment_date < ?"); params.append(today.isoformat())
    center = request.args.get("center_id", type=int)
    if center:
        where.append("a.center_id = ?"); params.append(center)
    status = request.args.get("status")
    if status in appt_svc.STAFF_TRANSITIONS or status in ("completed", "deferred", "cancelled", "no_show"):
        where.append("a.status = ?"); params.append(status)
    q = (request.args.get("q") or "").strip()[:60]
    if q:
        where.append(f"(u.full_name {db.like()} ? OR d.donor_code {db.like()} ? OR u.phone = ?)")
        params += [f"%{q}%", f"%{q}%", normalize_phone(q) or "-"]
    order = "a.appointment_date DESC, a.appointment_time DESC" if rng == "past" else "a.appointment_date, a.appointment_time"
    page = paginate(db, f"""SELECT a.*, c.name AS center_name, d.donor_code, d.blood_type, u.full_name
        FROM appointments a JOIN blood_centers c ON c.id = a.center_id JOIN donors d ON d.id = a.donor_id
        JOIN users u ON u.id = d.user_id WHERE {' AND '.join(where)} ORDER BY {order}""", params,
                    request.args.get("page", 1, type=int), 30)
    return render_template("admin/appointments.html", page=page, centers=scoped_centers(), rng=rng, day=day or "")


@bp.route("/appointments/<int:appt_id>")
@permission_required("appointments.view")
def appointment_detail(appt_id):
    a = _get(appt_id)
    db = get_db()
    assessment = don_svc.latest_assessment(appt_id)
    donation = db.one("SELECT * FROM donations WHERE appointment_id = ?", (appt_id,))
    return render_template("admin/appointment_detail.html", a=a, assessment=assessment, donation=donation,
                           transitions=sorted(appt_svc.STAFF_TRANSITIONS.get(a["status"], [])))


@bp.route("/appointments/<int:appt_id>/status", methods=["POST"])
@permission_required("appointments.manage")
def appointment_status(appt_id):
    a = _get(appt_id)
    new = request.form.get("status", "")
    notes = (request.form.get("notes") or "").strip()[:300] or None
    try:
        appt_svc.staff_set_status(a, new, notes)
        audit.log("appointment_status", "appointment", appt_id, {"الحالة": {"من": a["status"], "إلى": new}})
        flash("تم تحديث حالة الموعد.", "success")
    except appt_svc.BookingError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.appointment_detail", appt_id=appt_id))


@bp.route("/appointments/<int:appt_id>/assessment", methods=["POST"])
@permission_required("donations.record")
def appointment_assessment(appt_id):
    a = _get(appt_id)
    f = Form(request.form)
    f.choice("decision", "قرار المختص", ["accepted", "deferred", "rejected"])
    f.text("assessed_by_name", "اسم المختص الذي أجرى التقييم", min_len=3, max_len=120)
    f.text("reason", "السبب", required=f.clean.get("decision") in ("deferred", "rejected"), max_len=255)
    f.date("defer_until", "التأجيل حتى", required=False, min_date=local_today())
    if not f.ok:
        flash("تعذر الحفظ: " + "، ".join(f.errors.values()), "error")
        return redirect(url_for("admin.appointment_detail", appt_id=appt_id))
    try:
        don_svc.record_assessment(a, f.clean["decision"], f.clean["assessed_by_name"], f.clean.get("reason"),
                                  f.clean.get("defer_until"), g.user.id)
        audit.log("assessment_record", "appointment", appt_id, {"القرار": f.clean["decision"], "المختص": f.clean["assessed_by_name"]})
        flash("تم تسجيل قرار المختص.", "success")
    except don_svc.DonationError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.appointment_detail", appt_id=appt_id))


@bp.route("/appointments/<int:appt_id>/donation", methods=["POST"])
@permission_required("donations.record")
def appointment_donation(appt_id):
    a = _get(appt_id)
    db = get_db()
    f = Form(request.form)
    f.blood_type()
    f.integer("volume_ml", "الحجم (مل)", min_value=100, max_value=600)
    unit = f.text("unit_number", "رقم الوحدة", required=False, max_len=40)
    notes = f.text("notes", "ملاحظات", required=False, max_len=500)
    if not f.ok:
        flash("تعذر الحفظ: " + "، ".join(f.errors.values()), "error")
        return redirect(url_for("admin.appointment_detail", appt_id=appt_id))
    assess = don_svc.latest_assessment(appt_id)
    try:
        did = don_svc.record_donation(db.get("donors", a["donor_id"]), a["center_id"], f.clean["blood_type"],
                                      f.clean["volume_ml"], local_to_utc_str(local_now().replace(tzinfo=None)),
                                      assess["assessed_by_name"] if assess else "", g.user.id, appointment=db.get("appointments", appt_id),
                                      notes=notes, unit_number=unit)
        audit.log("donation_record", "donation", did, {"الموعد": appt_id, "الفصيلة": f.clean["blood_type"]})
        flash("تم تسجيل عملية التبرع، وهي بانتظار الفحص والاعتماد.", "success")
        return redirect(url_for("admin.donation_detail", donation_id=did))
    except don_svc.DonationError as e:
        flash(str(e), "error")
        return redirect(url_for("admin.appointment_detail", appt_id=appt_id))
