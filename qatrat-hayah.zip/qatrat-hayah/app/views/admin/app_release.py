"""نشر تطبيق أندرويد: رفع ملف APK وضبط ربط التطبيق بالموقع (assetlinks)."""
import json

from flask import flash, g, redirect, render_template, request, url_for

from ... import audit
from ...security import permission_required
from ...services import app_release
from ...services.common import get_setting, set_setting
from . import bp


@bp.route("/app-release", methods=["GET", "POST"])
@permission_required("settings.manage")
def app_release_page():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "upload":
            f = request.files.get("apk")
            version = (request.form.get("version") or "").strip()[:20] or "1.0"
            notes = (request.form.get("notes") or "").strip()[:300]
            if not f or not f.filename.lower().endswith(".apk"):
                flash("اختر ملفًا بامتداد .apk", "error")
            else:
                try:
                    meta = app_release.save(f.read(), version, notes, g.user.name)
                    audit.log("settings_update", "settings", None, {"نشر تطبيق أندرويد": version, "الحجم (MB)": meta["size_mb"]})
                    flash("تم نشر التطبيق. أصبح متاحًا للتنزيل من صفحة «تنزيل التطبيق».", "success")
                except app_release.ReleaseError as e:
                    flash(str(e), "error")
        elif action == "remove":
            app_release.remove()
            audit.log("settings_update", "settings", None, {"إيقاف تنزيل تطبيق أندرويد": True})
            flash("تم إيقاف تنزيل ملف التطبيق.", "success")
        elif action == "assetlinks":
            raw = (request.form.get("assetlinks") or "").strip()
            try:
                if raw:
                    data = json.loads(raw)
                    if not isinstance(data, list):
                        raise ValueError
                    raw = json.dumps(data, separators=(",", ":"))
                if len(raw) > 1000:
                    raise ValueError
                set_setting("android_assetlinks", raw, g.user.id)
                audit.log("settings_update", "settings", None, {"assetlinks": "تحديث"})
                flash("تم حفظ ربط التطبيق بالموقع.", "success")
            except ValueError:
                flash("المحتوى ليس JSON صحيحًا. الصق محتوى ملف assetlinks.json كما هو من PWABuilder.", "error")
        return redirect(url_for("admin.app_release_page"))
    return render_template("admin/app_release.html", release=app_release.current(),
                           assetlinks=get_setting("android_assetlinks") or "")
