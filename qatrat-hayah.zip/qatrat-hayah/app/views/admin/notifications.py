"""الإشعارات الإدارية: إرسال إشعار لفئة من المتبرعين أو الموظفين ضمن النطاق."""
from flask import flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db
from ...notifications import notify
from ...rbac import center_filter, donor_filter
from ...security import permission_required
from ...validators import Form
from . import bp, scoped_governorates


@bp.route("/notifications", methods=["GET", "POST"])
@permission_required("notifications.send")
def broadcast():
    db = get_db()
    form = Form(request.form)
    if request.method == "POST":
        target = form.choice("target", "الفئة المستهدفة", ["donors", "staff"])
        form.text("title", "العنوان", min_len=3, max_len=150)
        form.text("body", "نص الإشعار", min_len=5, max_len=1000)
        bt = form.blood_type(required=False)
        gov = request.form.get("governorate_id", type=int)
        if form.ok:
            if target == "donors":
                df, dp = donor_filter(db, g.user.scope)
                where, params = [df, "d.status = 'active'"], list(dp)
                if bt:
                    where.append("d.blood_type = ?"); params.append(bt)
                if gov:
                    where.append("d.governorate_id = ?"); params.append(gov)
                ids = [r["user_id"] for r in db.query(f"SELECT d.user_id FROM donors d WHERE {' AND '.join(where)}", params)]
            else:
                cf, cp = center_filter(g.user.scope)
                ids = [r["user_id"] for r in db.query(
                    f"""SELECT DISTINCT ur.user_id FROM user_roles ur JOIN blood_centers c ON c.id = ur.center_id
                        WHERE {cf}{' AND c.governorate_id = ?' if gov else ''}""", [*cp, *([gov] if gov else [])])]
            n = notify(ids, "admin", form.clean["title"], form.clean["body"], respect_prefs=False)
            audit.log("notification_broadcast", "notification", None, {"الفئة": target, "العدد": n, "العنوان": form.clean["title"]})
            flash(f"تم إرسال الإشعار إلى {n} مستخدمًا." if n else "لا يوجد مستخدمون مطابقون لهذه المعايير.", "success" if n else "info")
            return redirect(url_for("admin.broadcast"))
    history = db.query("""SELECT * FROM audit_logs WHERE action = 'notification_broadcast' ORDER BY created_at DESC LIMIT 20""") \
        if g.user.can("audit.view") else []
    import json
    for h in history:
        try:
            h["d"] = json.loads(h["details"]) if isinstance(h["details"], str) else (h["details"] or {})
        except ValueError:
            h["d"] = {}
    return render_template("admin/notifications.html", form=form, governorates=scoped_governorates(), history=history)
