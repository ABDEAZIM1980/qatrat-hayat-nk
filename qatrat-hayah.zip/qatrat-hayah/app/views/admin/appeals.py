"""النداءات العاجلة: إنشاء ← اعتماد من المخوّل ← نشر وإشعار المتبرعين ← متابعة وإغلاق."""
from datetime import timedelta

from flask import abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate
from ...rbac import center_filter
from ...security import permission_required
from ...services import requests_appeals as ra
from ...timeutil import local_today
from ...validators import Form
from . import bp, require_center, scoped_centers


def _get(appeal_id):
    a = get_db().one(
        """SELECT e.*, c.name AS center_name, u.full_name AS created_by_name, ap.full_name AS approved_by_name
           FROM emergency_appeals e JOIN blood_centers c ON c.id = e.center_id JOIN users u ON u.id = e.created_by
           LEFT JOIN users ap ON ap.id = e.approved_by WHERE e.id = ?""", (appeal_id,))
    if not a:
        abort(404)
    require_center(a["center_id"])
    return a


@bp.route("/appeals")
@permission_required("appeals.view")
def appeals():
    db = get_db()
    cf, cp = center_filter(g.user.scope)
    where, params = [cf], list(cp)
    st = request.args.get("status")
    if st in ("pending_approval", "open", "completed", "closed", "rejected"):
        where.append("e.status = ?"); params.append(st)
    if request.args.get("blood_type"):
        where.append("e.blood_type = ?"); params.append(request.args["blood_type"])
    page = paginate(db, f"""SELECT e.*, c.name AS center_name FROM emergency_appeals e JOIN blood_centers c ON c.id = e.center_id
        WHERE {' AND '.join(where)} ORDER BY CASE e.status WHEN 'pending_approval' THEN 0 WHEN 'open' THEN 1 ELSE 2 END,
        e.created_at DESC""", params, request.args.get("page", 1, type=int))
    return render_template("admin/appeals.html", page=page)


@bp.route("/appeals/new", methods=["GET", "POST"])
@permission_required("appeals.create")
def appeal_new():
    db = get_db()
    form = Form(request.form or request.args)
    if request.method == "POST":
        center = form.fk("center_id", "المركز", db, "blood_centers", where="status = 'active'")
        if center:
            require_center(center["id"])
        form.text("title", "عنوان النداء", min_len=5, max_len=150)
        form.blood_type()
        form.integer("units_needed", "عدد الوحدات", min_value=1, max_value=500)
        form.urgency()
        form.text("message", "نص النداء", required=False, max_len=1000)
        form.date("expires_at", "ينتهي في", required=False, min_date=local_today(), max_date=local_today() + timedelta(days=30))
        if form.raw("blood_request_id"):
            req = form.fk("blood_request_id", "طلب الدم المرتبط", db, "blood_requests", required=False)
            if req:
                require_center(req["center_id"])
        else:
            form.clean["blood_request_id"] = None
        if form.ok:
            aid = ra.create_appeal(form.clean, g.user.id)
            audit.log("appeal_create", "appeal", aid, {"العنوان": form.clean["title"], "الفصيلة": form.clean["blood_type"]})
            if request.form.get("publish_now") and g.user.can("appeals.approve"):
                n = ra.publish_appeal(db.get("emergency_appeals", aid), g.user.id)
                audit.log("appeal_publish", "appeal", aid, {"عدد المتبرعين المُشعَرين": n})
                flash(f"تم اعتماد النداء ونشره، وإشعار {n} متبرعًا.", "success")
            else:
                flash("تم إنشاء النداء، وهو بانتظار الاعتماد قبل النشر.", "success")
            return redirect(url_for("admin.appeal_detail", appeal_id=aid))
    elif not form.data.get("title"):
        form = Form({**form.data, "title": "احتياج عاجل للدم"})
    return render_template("admin/appeal_form.html", form=form, centers=scoped_centers(active_only=True))


@bp.route("/appeals/<int:appeal_id>")
@permission_required("appeals.view")
def appeal_detail(appeal_id):
    return render_template("admin/appeal_detail.html", a=_get(appeal_id))


@bp.route("/appeals/<int:appeal_id>/action", methods=["POST"])
@permission_required("appeals.view")
def appeal_action(appeal_id):
    a = _get(appeal_id)
    action = request.form.get("action")
    try:
        if action == "publish":
            if not g.user.can("appeals.approve"):
                abort(403)
            n = ra.publish_appeal(a, g.user.id)
            audit.log("appeal_publish", "appeal", appeal_id, {"عدد المتبرعين المُشعَرين": n})
            flash(f"تم اعتماد النداء ونشره، وإشعار {n} متبرعًا من نفس الفصيلة في الولاية.", "success")
        elif action == "reject":
            if not g.user.can("appeals.approve"):
                abort(403)
            reason = (request.form.get("reason") or "").strip()[:255]
            if len(reason) < 3:
                raise ra.WorkflowError("يرجى كتابة سبب عدم الاعتماد.")
            ra.reject_appeal(a, g.user.id, reason)
            audit.log("appeal_reject", "appeal", appeal_id, {"السبب": reason})
            flash("تم رفض النداء.", "success")
        elif action == "progress":
            if not g.user.can("appeals.create", "appeals.approve"):
                abort(403)
            f = Form(request.form)
            f.integer("units_collected", "الوحدات التي تم جمعها", min_value=0, max_value=1000)
            f.choice("new_status", "الحالة", ["open", "completed", "closed"])
            if not f.ok:
                raise ra.WorkflowError("، ".join(f.errors.values()))
            ra.update_appeal_progress(a, f.clean["units_collected"], f.clean["new_status"])
            audit.log("appeal_status", "appeal", appeal_id, {"تم جمعه": f.clean["units_collected"], "الحالة": f.clean["new_status"]})
            flash("تم تحديث النداء.", "success")
        else:
            abort(400)
    except ra.WorkflowError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.appeal_detail", appeal_id=appeal_id))


