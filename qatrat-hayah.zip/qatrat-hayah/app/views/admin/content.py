"""إدارة المحتوى التوعوي."""
import re

from flask import abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate, utcnow
from ...security import permission_required
from ...services.common import CONTENT_CATEGORIES
from ...validators import Form
from . import bp


@bp.route("/content")
@permission_required("content.manage")
def content():
    db = get_db()
    page = paginate(db, "SELECT * FROM educational_content ORDER BY updated_at DESC", [], request.args.get("page", 1, type=int))
    return render_template("admin/content.html", page=page)


def _validate(form, db, row_id=None):
    form.text("title", "العنوان", min_len=5, max_len=200)
    form.choice("category", "التصنيف", list(CONTENT_CATEGORIES))
    form.text("summary", "الملخص", required=False, max_len=400)
    form.text("body", "المحتوى", min_len=20, max_len=20000)
    slug = form.text("slug", "الرابط المختصر", required=False, max_len=120)
    if slug:
        if not re.fullmatch(r"[a-z0-9\-]+", slug):
            form.error("slug", "الرابط المختصر يقبل حروفًا إنجليزية صغيرة وأرقامًا وشرطة فقط.")
        elif db.one("SELECT id FROM educational_content WHERE slug = ? AND id != ?", (slug, row_id or 0)):
            form.error("slug", "الرابط مستخدم مسبقًا.")
    form.boolean("is_published")


@bp.route("/content/new", methods=["GET", "POST"])
@bp.route("/content/<int:content_id>/edit", methods=["GET", "POST"])
@permission_required("content.manage")
def content_form(content_id=None):
    db = get_db()
    row = db.get("educational_content", content_id) if content_id else None
    if content_id and not row:
        abort(404)
    if request.method == "POST":
        form = Form(request.form)
        _validate(form, db, content_id)
        if form.ok:
            now = utcnow()
            data = {k: form.clean.get(k) for k in ("title", "category", "summary", "body", "is_published")}
            if data["is_published"] and not (row and row["published_at"]):
                data["published_at"] = now
            if row:
                if form.clean.get("slug"):
                    data["slug"] = form.clean["slug"]
                db.update("educational_content", content_id, {**data, "updated_at": now})
                audit.log("content_update", "content", content_id, {"العنوان": data["title"]})
            else:
                data["slug"] = form.clean.get("slug") or f"article-{int(db.scalar('SELECT COALESCE(MAX(id),0) AS m FROM educational_content', (), 0)) + 1}"
                content_id = db.insert("educational_content", {**data, "author_id": g.user.id, "created_at": now, "updated_at": now})
                audit.log("content_create", "content", content_id, {"العنوان": data["title"]})
            flash("تم حفظ المحتوى.", "success")
            return redirect(url_for("admin.content"))
    else:
        form = Form({**(row or {"category": "general"}), "is_published": "1" if (row and row["is_published"]) else ""})
    return render_template("admin/content_form.html", form=form, row=row)
