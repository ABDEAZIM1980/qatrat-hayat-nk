"""إدارة المتبرعين (ضمن النطاق) وتسجيل المتبرعين الحاضرين في المركز."""
import secrets

from flask import abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate, utcnow
from ...rbac import accessible_center_ids, donor_filter
from ...security import hash_password, permission_required
from ...validators import Form, normalize_phone
from ..auth import create_donor_record, validate_donor_fields
from . import bp, scoped_centers, scoped_governorates


def _get_donor(donor_id):
    db = get_db()
    df, dp = donor_filter(db, g.user.scope)
    d = db.one(
        f"""SELECT d.*, u.full_name, u.phone, u.email, u.status AS account_status, u.last_login_at, p.gender, p.birth_year,
            p.notify_in_app, p.notify_sms, p.notify_emergency, p.notify_reminders,
            g.name_ar AS governorate, l.name_ar AS locality, c.name AS preferred_center
            FROM donors d JOIN users u ON u.id = d.user_id LEFT JOIN donor_profiles p ON p.donor_id = d.id
            JOIN governorates g ON g.id = d.governorate_id JOIN localities l ON l.id = d.locality_id
            LEFT JOIN blood_centers c ON c.id = d.preferred_center_id WHERE d.id = ? AND {df}""", [donor_id, *dp])
    if not d:
        abort(404)
    return d


@bp.route("/donors")
@permission_required("donors.view")
def donors():
    db = get_db()
    df, dp = donor_filter(db, g.user.scope)
    where, params = [df], list(dp)
    q = (request.args.get("q") or "").strip()[:60]
    if q:
        where.append(f"(u.full_name {db.like()} ? OR d.donor_code {db.like()} ? OR u.phone = ?)")
        params += [f"%{q}%", f"%{q}%", normalize_phone(q) or "-"]
    bt = request.args.get("blood_type")
    if bt == "unknown":
        where.append("d.blood_type IS NULL")
    elif bt:
        where.append("d.blood_type = ?"); params.append(bt)
    for key, col in (("governorate_id", "d.governorate_id"), ("locality_id", "d.locality_id"),
                     ("center_id", "d.preferred_center_id")):
        v = request.args.get(key, type=int)
        if v:
            where.append(f"{col} = ?"); params.append(v)
    if request.args.get("status") in ("active", "inactive", "suspended"):
        where.append("d.status = ?"); params.append(request.args["status"])
    if request.args.get("verified") == "1":
        where.append("d.blood_type_verified = 1")
    page = paginate(db, f"""SELECT d.*, u.full_name, u.phone, l.name_ar AS locality FROM donors d
        JOIN users u ON u.id = d.user_id JOIN localities l ON l.id = d.locality_id
        WHERE {' AND '.join(where)} ORDER BY d.registered_at DESC""", params, request.args.get("page", 1, type=int))
    gov = request.args.get("governorate_id", type=int)
    localities = db.query("SELECT id, name_ar FROM localities WHERE governorate_id = ? ORDER BY name_ar", (gov,)) if gov else []
    return render_template("admin/donors.html", page=page, governorates=scoped_governorates(), localities=localities,
                           centers=scoped_centers())


@bp.route("/donors/<int:donor_id>")
@permission_required("donors.view")
def donor_detail(donor_id):
    db = get_db()
    d = _get_donor(donor_id)
    ids = accessible_center_ids(db, g.user.scope)
    cfilter = "" if ids is None else f" AND x.center_id IN ({','.join(str(int(i)) for i in ids) or 0})"
    appts = db.query(f"""SELECT x.*, c.name AS center_name FROM appointments x JOIN blood_centers c ON c.id = x.center_id
                         WHERE x.donor_id = ?{cfilter} ORDER BY x.appointment_date DESC LIMIT 20""", (donor_id,))
    donations = db.query(f"""SELECT x.*, c.name AS center_name FROM donations x JOIN blood_centers c ON c.id = x.center_id
                             WHERE x.donor_id = ?{cfilter} ORDER BY x.donated_at DESC LIMIT 50""", (donor_id,))
    assessments = db.query(f"""SELECT m.*, a.center_id FROM medical_assessments m JOIN appointments a ON a.id = m.appointment_id
                               WHERE m.donor_id = ?{cfilter.replace('x.center_id', 'a.center_id')} ORDER BY m.created_at DESC LIMIT 20""",
                           (donor_id,))
    show_phone = g.user.can("donors.manage", "appointments.manage")
    return render_template("admin/donor_detail.html", d=d, appts=appts, donations=donations, assessments=assessments,
                           show_phone=show_phone)


@bp.route("/donors/<int:donor_id>/edit", methods=["GET", "POST"])
@permission_required("donors.manage")
def donor_edit(donor_id):
    db = get_db()
    d = _get_donor(donor_id)
    if request.method == "POST":
        form = Form(request.form)
        form.text("full_name", "الاسم الكامل", min_len=5, max_len=120)
        validate_donor_fields(form, db)
        form.choice("status", "حالة المتبرع", ["active", "inactive", "suspended"])
        if form.ok:
            new = {"blood_type": form.clean.get("blood_type"), "governorate_id": form.clean["governorate_id"],
                   "locality_id": form.clean["locality_id"], "preferred_center_id": form.clean.get("preferred_center_id"),
                   "status": form.clean["status"]}
            if d["blood_type_verified"] and new["blood_type"] != d["blood_type"]:
                form.error("blood_type", "الفصيلة مثبتة مخبريًا ولا يمكن تغييرها من هنا.")
        if form.ok:
            changes = audit.diff(d, {**new, "full_name": form.clean["full_name"]}, [*new, "full_name"])
            with db.transaction():
                db.update("donors", donor_id, {**new, "updated_at": utcnow()})
                db.update("users", d["user_id"], {"full_name": form.clean["full_name"], "updated_at": utcnow()})
                db.execute("UPDATE donor_profiles SET gender = ?, birth_year = ?, updated_at = ? WHERE donor_id = ?",
                           (form.clean.get("gender"), form.clean.get("birth_year"), utcnow(), donor_id))
            audit.log("donor_update", "donor", donor_id, changes)
            flash("تم حفظ بيانات المتبرع.", "success")
            return redirect(url_for("admin.donor_detail", donor_id=donor_id))
    else:
        form = Form({**d, "blood_type": d["blood_type"] or "unknown"})
    return render_template("admin/donor_form.html", form=form, d=d, governorates=scoped_governorates())


@bp.route("/donors/new", methods=["GET", "POST"])
@permission_required("donors.manage", "donations.record")
def donor_new():
    """تسجيل متبرع حاضر في المركز (لمن لا يملك هاتفًا ذكيًا)."""
    db = get_db()
    form = Form(request.form)
    if request.method == "POST":
        form.text("full_name", "الاسم الكامل", min_len=5, max_len=120)
        form.phone()
        validate_donor_fields(form, db)
        if form.ok and not g.user.scope.is_global:
            from ...rbac import can_access_governorate
            s = g.user.scope
            gov_ok = can_access_governorate(s, form.clean["governorate_id"]) or form.clean["locality_id"] in s.locality_ids
            center_ok = form.clean.get("preferred_center_id") and form.clean["preferred_center_id"] in (accessible_center_ids(db, s) or [])
            if not (gov_ok or center_ok):
                form.error("preferred_center_id", "اختر مركزًا ضمن نطاق عملك كمركز مفضل للمتبرع.")
        if form.ok and db.one("SELECT id FROM users WHERE phone = ?", (form.clean["phone"],)):
            form.error("phone", "هذا الرقم مسجل مسبقًا. ابحث عن المتبرع في القائمة.")
        if form.ok:
            temp = "Qh" + secrets.token_urlsafe(5) + "7"
            now = utcnow()
            with db.transaction():
                uid = db.insert("users", {"full_name": form.clean["full_name"], "phone": form.clean["phone"],
                                          "password_hash": hash_password(temp), "status": "active", "is_staff": 0,
                                          "created_at": now, "updated_at": now})
                db.insert("user_roles", {"user_id": uid, "role_id": db.scalar("SELECT id FROM roles WHERE code='donor'"),
                                         "assigned_by": g.user.id, "created_at": now})
                did = create_donor_record(db, uid, form)
            audit.log("user_create", "donor", did, {"الاسم": form.clean["full_name"], "بواسطة": "موظف المركز"})
            return render_template("admin/user_created.html", name=form.clean["full_name"], phone=form.clean["phone"],
                                   temp=temp, donor_id=did)
    return render_template("admin/donor_form.html", form=form, d=None, governorates=scoped_governorates())
