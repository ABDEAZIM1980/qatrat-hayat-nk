"""التقارير: تصفية، معاينة، وتصدير CSV / Excel / PDF."""
import json

from flask import Response, g, render_template, request

from ... import audit
from ...db import get_db, utcnow
from ...schema import BLOOD_TYPES
from ...security import permission_required
from ...services import reports as rep
from ...timeutil import local_now
from ...validators import Form
from . import bp, scoped_centers, scoped_governorates


def _filters():
    a = request.args
    f = Form(a)
    f.date("date_from", "من تاريخ", required=False)
    f.date("date_to", "إلى تاريخ", required=False)
    out = {k: f.clean.get(k) for k in ("date_from", "date_to")}
    for k in ("governorate_id", "locality_id", "center_id"):
        v = a.get(k, type=int)
        if v:
            out[k] = v
    if a.get("blood_type") in BLOOD_TYPES:
        out["blood_type"] = a["blood_type"]
    if a.get("status"):
        out["status"] = a["status"][:30]
    if a.get("urgency") in ("normal", "medium", "urgent", "critical"):
        out["urgency"] = a["urgency"]
    return out, f.errors


def _meta(report, flt):
    db = get_db()
    parts = [f"تاريخ الإصدار: {local_now().strftime('%Y-%m-%d %H:%M')}"]
    if flt.get("date_from") or flt.get("date_to"):
        parts.append(f"الفترة: {flt.get('date_from') or '—'} إلى {flt.get('date_to') or '—'}")
    if flt.get("governorate_id"):
        parts.append("الولاية: " + (db.scalar("SELECT name_ar FROM governorates WHERE id = ?", (flt["governorate_id"],)) or ""))
    if flt.get("center_id"):
        parts.append("المركز: " + (db.scalar("SELECT name FROM blood_centers WHERE id = ?", (flt["center_id"],)) or ""))
    if flt.get("blood_type"):
        parts.append("الفصيلة: " + flt["blood_type"])
    return " | ".join(parts)


STATUS_CHOICES = {
    "donors": [("active", "نشط"), ("inactive", "غير نشط"), ("suspended", "موقوف")],
    "donations": [("pending", "بانتظار الاعتماد"), ("approved", "معتمد"), ("rejected", "غير معتمد")],
    "appointments": [("booked", "محجوز"), ("confirmed", "مؤكد"), ("completed", "تم التبرع"), ("cancelled", "ملغى"),
                     ("no_show", "لم يحضر"), ("deferred", "لم يتم التبرع (قرار طبي)")],
    "inventory": [("available", "متوفر"), ("low", "منخفض"), ("critical", "حرج")],
    "requests": [("pending", "بانتظار الاعتماد"), ("approved", "معتمد"), ("partially_fulfilled", "صُرف جزئيًا"),
                 ("fulfilled", "مكتمل"), ("rejected", "مرفوض"), ("cancelled", "ملغى")],
    "appeals": [("pending_approval", "بانتظار الاعتماد"), ("open", "مفتوح"), ("completed", "مكتمل"), ("closed", "مغلق")],
}


@bp.route("/reports")
@permission_required("reports.view")
def reports():
    report = request.args.get("report")
    ctx = {"reports": rep.REPORTS, "report": report, "governorates": scoped_governorates(), "centers": scoped_centers(),
           "status_choices": STATUS_CHOICES.get(report, [])}
    if report not in rep.REPORTS:
        return render_template("admin/reports.html", **ctx)
    flt, errors = _filters()
    if errors:
        return render_template("admin/reports.html", errors=errors, **ctx)
    fmt = request.args.get("format")
    cols, rows = rep.run(report, flt, g.user.scope)
    title = rep.REPORTS[report]
    meta = _meta(report, flt)
    if fmt in ("csv", "xlsx", "pdf"):
        db = get_db()
        db.insert("reports", {"report_type": report, "params": json.dumps(flt, ensure_ascii=False), "file_format": fmt,
                              "row_count": len(rows), "generated_by": g.user.id, "created_at": utcnow()})
        audit.log("report_export", "report", None, {"التقرير": title, "الصيغة": fmt, "عدد الصفوف": len(rows)})
        stamp = local_now().strftime("%Y%m%d-%H%M")
        fname = f"qatrat-{report}-{stamp}"
        if fmt == "csv":
            return Response(rep.to_csv(cols, rows), mimetype="text/csv; charset=utf-8",
                            headers={"Content-Disposition": f"attachment; filename={fname}.csv"})
        if fmt == "xlsx":
            return Response(rep.to_xlsx(title, cols, rows, meta),
                            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            headers={"Content-Disposition": f"attachment; filename={fname}.xlsx"})
        html = render_template("admin/report_print.html", title=title, meta=meta, cols=cols, rows=rows, font_css=rep.embedded_font_css())
        pdf = rep.html_to_pdf(html)
        if pdf:
            return Response(pdf, mimetype="application/pdf", headers={"Content-Disposition": f"attachment; filename={fname}.pdf"})
        # بديل عند عدم توفر محرك PDF على الخادم: صفحة طباعة (حفظ كـ PDF من المتصفح)
        return render_template("admin/report_print.html", title=title, meta=meta, cols=cols, rows=rows, auto_print=True)
    return render_template("admin/reports.html", cols=cols, rows=rows[:100], total=len(rows), meta=meta, flt=flt, **ctx)
