"""إدارة مخزون الدم حسب الفصيلة والمركز."""
from flask import flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate
from ...rbac import center_filter
from ...schema import BLOOD_TYPES
from ...security import permission_required
from ...services import inventory as inv
from ...services.common import TX_TYPES
from ...validators import Form
from . import bp, require_center, scoped_governorates

MANUAL_TX = ["issue_out", "reserve", "release", "expire", "discard", "transfer_in"]


@bp.route("/inventory")
@permission_required("inventory.view")
def inventory():
    db = get_db()
    cf, cp = center_filter(g.user.scope)
    where, params = [cf, "c.status = 'active'"], list(cp)
    gov = request.args.get("governorate_id", type=int)
    if gov:
        where.append("c.governorate_id = ?"); params.append(gov)
    status_f = request.args.get("status")
    centers = db.query(f"""SELECT c.id, c.name, l.name_ar AS locality FROM blood_centers c JOIN localities l ON l.id = c.locality_id
                          WHERE {' AND '.join(where)} ORDER BY c.name""", params)
    for c in centers:
        inv.ensure_center_inventory(c["id"])
    ids = [c["id"] for c in centers]
    grid = {}
    if ids:
        for r in db.query(f"SELECT * FROM blood_inventory WHERE center_id IN ({','.join('?' for _ in ids)})", ids):
            r["status"] = inv.stock_status(r)
            grid.setdefault(r["center_id"], {})[r["blood_type"]] = r
    if status_f in ("critical", "low", "available"):
        centers = [c for c in centers if any(x["status"] == status_f for x in grid.get(c["id"], {}).values())]
    totals = {bt: sum(grid.get(c["id"], {}).get(bt, {}).get("available_units", 0) for c in centers) for bt in BLOOD_TYPES}
    return render_template("admin/inventory.html", centers=centers, grid=grid, totals=totals,
                           governorates=scoped_governorates())


@bp.route("/inventory/<int:center_id>", methods=["GET", "POST"])
@permission_required("inventory.view")
def inventory_center(center_id):
    require_center(center_id)
    db = get_db()
    center = db.get("blood_centers", center_id)
    inv.ensure_center_inventory(center_id)
    form = Form(request.form)
    if request.method == "POST":
        if not g.user.can("inventory.manage"):
            from flask import abort
            abort(403)
        action = request.form.get("action")
        try:
            if action == "tx":
                form.blood_type()
                form.choice("tx_type", "نوع الحركة", MANUAL_TX + ["transfer_out"])
                form.integer("quantity", "الكمية", min_value=1, max_value=500)
                form.text("reason", "السبب / المرجع", min_len=3, max_len=255)
                target = None
                if form.clean.get("tx_type") == "transfer_out":
                    target = form.fk("target_center_id", "المركز المستلم", db, "blood_centers", where="status = 'active'")
                if form.ok:
                    if form.clean["tx_type"] == "transfer_out":
                        inv.transfer(center_id, target["id"], form.clean["blood_type"], form.clean["quantity"], g.user.id,
                                     form.clean["reason"])
                    else:
                        inv.apply(center_id, form.clean["blood_type"], form.clean["tx_type"], form.clean["quantity"], g.user.id,
                                  form.clean["reason"])
                    audit.log("inventory_adjust", "inventory", center_id, {
                        "الحركة": TX_TYPES[form.clean["tx_type"]], "الفصيلة": form.clean["blood_type"],
                        "الكمية": form.clean["quantity"], "السبب": form.clean["reason"]})
                    flash("تم تسجيل حركة المخزون.", "success")
                    return redirect(url_for("admin.inventory_center", center_id=center_id))
            elif action == "count":
                form.blood_type()
                form.integer("counted", "العدد الفعلي", min_value=0, max_value=5000)
                form.text("reason", "ملاحظة الجرد", min_len=3, max_len=200)
                if form.ok:
                    before = inv.get_row(center_id, form.clean["blood_type"])["available_units"]
                    inv.stocktake(center_id, form.clean["blood_type"], form.clean["counted"], g.user.id, form.clean["reason"])
                    audit.log("inventory_adjust", "inventory", center_id, {
                        "الحركة": "تسوية جرد", "الفصيلة": form.clean["blood_type"], "من": before, "إلى": form.clean["counted"]})
                    flash("تم حفظ نتيجة الجرد.", "success")
                    return redirect(url_for("admin.inventory_center", center_id=center_id))
            elif action == "levels":
                form.blood_type()
                form.integer("critical_level", "الحد الحرج", min_value=0, max_value=1000)
                form.integer("low_level", "الحد المنخفض", min_value=0, max_value=1000)
                if form.ok:
                    inv.set_thresholds(center_id, form.clean["blood_type"], form.clean["critical_level"],
                                       form.clean["low_level"], g.user.id)
                    audit.log("inventory_adjust", "inventory", center_id, {
                        "الحركة": "تعديل حدود التنبيه", "الفصيلة": form.clean["blood_type"],
                        "الحرج": form.clean["critical_level"], "المنخفض": form.clean["low_level"]})
                    flash("تم تحديث حدود التنبيه.", "success")
                    return redirect(url_for("admin.inventory_center", center_id=center_id))
        except inv.InventoryError as e:
            form.error("quantity", str(e))
        if form.errors:
            flash("تعذر الحفظ: " + "، ".join(form.errors.values()), "error")
    rows = db.query("SELECT * FROM blood_inventory WHERE center_id = ? ORDER BY id", (center_id,))
    for r in rows:
        r["status"] = inv.stock_status(r)
    page = paginate(db, """SELECT t.*, u.full_name AS by_name FROM blood_inventory_transactions t
                           LEFT JOIN users u ON u.id = t.created_by WHERE t.center_id = ? ORDER BY t.id DESC""",
                    [center_id], request.args.get("page", 1, type=int), 25)
    others = [c for c in db.query("SELECT id, name FROM blood_centers WHERE status = 'active' AND id != ? ORDER BY name", (center_id,))]
    return render_template("admin/inventory_center.html", center=center, rows=rows, page=page, others=others,
                           manual_tx=MANUAL_TX, form=form)
