"""عرض سجل العمليات (Audit Log) مع التصفية."""
import json

from flask import g, render_template, request

from ...audit import ACTIONS, ENTITY_NAMES
from ...db import get_db, paginate
from ...rbac import accessible_center_ids
from ...security import permission_required
from ...validators import Form
from . import bp


@bp.route("/audit")
@permission_required("audit.view")
def audit_log():
    db = get_db()
    where, params = ["1=1"], []
    if not g.user.scope.is_global:
        # غير الإدارة العامة: عمليات المستخدمين العاملين ضمن نطاقهم فقط
        ids = accessible_center_ids(db, g.user.scope) or [0]
        govs = sorted(g.user.scope.governorate_ids) or [0]
        where.append(f"""a.user_id IN (SELECT ur.user_id FROM user_roles ur WHERE ur.center_id IN ({','.join('?' for _ in ids)})
                         OR ur.governorate_id IN ({','.join('?' for _ in govs)}))""")
        params += [*ids, *govs]
    if request.args.get("action") in ACTIONS:
        where.append("a.action = ?"); params.append(request.args["action"])
    if request.args.get("entity") in ENTITY_NAMES:
        where.append("a.entity_type = ?"); params.append(request.args["entity"])
    q = (request.args.get("q") or "").strip()[:60]
    if q:
        where.append(f"a.user_name {db.like()} ?"); params.append(f"%{q}%")
    for key, op in (("date_from", ">="), ("date_to", "<=")):
        v = request.args.get(key)
        if v:
            f = Form({"d": v}); f.date("d", "التاريخ")
            if f.ok:
                where.append(f"a.created_at {op} ?"); params.append(f.clean["d"] + (" 23:59:59" if op == "<=" else " 00:00:00"))
    page = paginate(db, f"SELECT a.* FROM audit_logs a WHERE {' AND '.join(where)} ORDER BY a.id DESC", params,
                    request.args.get("page", 1, type=int), 40)
    for r in page["rows"]:
        try:
            r["details_obj"] = json.loads(r["details"]) if isinstance(r["details"], str) and r["details"] else (r["details"] or {})
        except ValueError:
            r["details_obj"] = {}
    return render_template("admin/audit.html", page=page, actions=ACTIONS, entities=ENTITY_NAMES)
