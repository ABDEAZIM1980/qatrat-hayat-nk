"""إدارة مراكز وبنوك الدم وجداول مواعيدها."""
from flask import abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate, utcnow
from ...rbac import center_filter
from ...security import permission_required
from ...services import inventory
from ...services.common import CENTER_TYPES, WEEKDAYS
from ...validators import Form
from . import bp, require_center, scoped_governorates

FIELDS = ["name", "center_type", "governorate_id", "locality_id", "city_id", "address", "phone", "working_hours",
          "latitude", "longitude", "services", "accepts_appointments"]


@bp.route("/centers")
@permission_required("centers.view")
def centers():
    db = get_db()
    cf, cp = center_filter(g.user.scope)
    where, params = [cf], list(cp)
    q = (request.args.get("q") or "").strip()[:60]
    gov = request.args.get("governorate_id", type=int)
    loc = request.args.get("locality_id", type=int)
    status = request.args.get("status")
    ctype = request.args.get("type")
    if q:
        where.append(f"(c.name {db.like()} ? OR c.address {db.like()} ?)"); params += [f"%{q}%"] * 2
    if gov:
        where.append("c.governorate_id = ?"); params.append(gov)
    if loc:
        where.append("c.locality_id = ?"); params.append(loc)
    if status in ("active", "inactive"):
        where.append("c.status = ?"); params.append(status)
    if ctype in CENTER_TYPES:
        where.append("c.center_type = ?"); params.append(ctype)
    page = paginate(db, f"""SELECT c.*, g.name_ar AS governorate, l.name_ar AS locality,
        (SELECT COALESCE(SUM(i.available_units),0) FROM blood_inventory i WHERE i.center_id = c.id) AS stock
        FROM blood_centers c JOIN governorates g ON g.id = c.governorate_id JOIN localities l ON l.id = c.locality_id
        WHERE {' AND '.join(where)} ORDER BY g.name_ar, l.name_ar, c.name""", params, request.args.get("page", 1, type=int))
    localities = db.query("SELECT id, name_ar FROM localities WHERE governorate_id = ? ORDER BY name_ar", (gov,)) if gov else []
    return render_template("admin/centers.html", page=page, governorates=scoped_governorates(), localities=localities)


def _validate(form, db):
    form.text("name", "اسم المركز", min_len=3, max_len=150)
    form.choice("center_type", "نوع المركز", list(CENTER_TYPES))
    gov = form.fk("governorate_id", "الولاية", db, "governorates")
    loc = form.fk("locality_id", "المحلية", db, "localities", where=f"governorate_id = {int(gov['id'])}") if gov else None
    if loc and not g.user.scope.is_global:
        s = g.user.scope
        if not (loc["governorate_id"] in s.governorate_ids or loc["id"] in s.locality_ids):
            form.error("locality_id", "لا تملك صلاحية إضافة مراكز في هذه المحلية.")
    if loc and form.raw("city_id"):
        form.fk("city_id", "المدينة", db, "cities", required=False, where=f"locality_id = {int(loc['id'])}")
    else:
        form.clean["city_id"] = None
    form.text("address", "العنوان", required=False, max_len=255)
    if form.raw("phone"):
        form.phone("phone", "هاتف المركز")
    else:
        form.clean["phone"] = None
    form.text("working_hours", "ساعات العمل", required=False, max_len=120)
    form.decimal("latitude", "خط العرض", min_value=-90, max_value=90)
    form.decimal("longitude", "خط الطول", min_value=-180, max_value=180)
    if (form.clean.get("latitude") is None) != (form.clean.get("longitude") is None):
        form.error("longitude", "أدخل خط العرض وخط الطول معًا، أو اتركهما فارغين.")
    form.text("services", "الخدمات", required=False, max_len=1000)
    form.boolean("accepts_appointments")
    if form.ok:
        dup = db.one("SELECT id FROM blood_centers WHERE locality_id = ? AND name = ? AND id != ?",
                     (form.clean["locality_id"], form.clean["name"], form.data.get("_id") or 0))
        if dup:
            form.error("name", "يوجد مركز بنفس الاسم في هذه المحلية.")


def _can_manage_center(center_id=None):
    if not g.user.can("centers.manage"):
        abort(403)
    if center_id is not None:
        require_center(center_id)


@bp.route("/centers/new", methods=["GET", "POST"])
@permission_required("centers.manage")
def center_new():
    db = get_db()
    if g.user.scope.center_ids and not (g.user.scope.is_global or g.user.scope.governorate_ids or g.user.scope.locality_ids):
        abort(403)
    form = Form(request.form)
    if request.method == "POST":
        _validate(form, db)
        if form.ok:
            now = utcnow()
            data = {k: form.clean.get(k) for k in FIELDS}
            with db.transaction():
                cid = db.insert("blood_centers", {**data, "status": "active", "created_at": now, "updated_at": now})
                if data["center_type"] in ("blood_bank", "hospital_bank"):
                    db.insert("blood_banks", {"center_id": cid, "is_active": 1, "has_component_separation": 0, "created_at": now})
                for wd in (5, 6, 0, 1, 2, 3):  # جدول افتراضي السبت–الخميس
                    db.insert("center_schedules", {"center_id": cid, "weekday": wd, "start_time": "08:00", "end_time": "14:00",
                                                   "slot_minutes": 30, "capacity_per_slot": 2})
                inventory.ensure_center_inventory(cid)
            audit.log("center_create", "center", cid, {"الاسم": data["name"]})
            flash("تمت إضافة المركز مع جدول مواعيد افتراضي يمكنك تعديله.", "success")
            return redirect(url_for("admin.center_detail", center_id=cid))
    else:
        form = Form({"accepts_appointments": "1", "center_type": "donation_center"})
    return render_template("admin/center_form.html", form=form, governorates=scoped_governorates(), c=None)


@bp.route("/centers/<int:center_id>")
@permission_required("centers.view")
def center_detail(center_id):
    require_center(center_id)
    db = get_db()
    c = db.one("""SELECT c.*, g.name_ar AS governorate, l.name_ar AS locality, ci.name_ar AS city FROM blood_centers c
                  JOIN governorates g ON g.id = c.governorate_id JOIN localities l ON l.id = c.locality_id
                  LEFT JOIN cities ci ON ci.id = c.city_id WHERE c.id = ?""", (center_id,))
    inv = db.query("SELECT * FROM blood_inventory WHERE center_id = ? ORDER BY id", (center_id,))
    for r in inv:
        r["status"] = inventory.stock_status(r)
    schedule = {r["weekday"]: r for r in db.query("SELECT * FROM center_schedules WHERE center_id = ?", (center_id,))}
    bank = db.one("SELECT * FROM blood_banks WHERE center_id = ?", (center_id,))
    staff = db.query("""SELECT u.id, u.full_name, u.phone, u.status, r.code AS role FROM user_roles ur
                        JOIN users u ON u.id = ur.user_id JOIN roles r ON r.id = ur.role_id WHERE ur.center_id = ?""", (center_id,))
    return render_template("admin/center_detail.html", c=c, inv=inv, schedule=schedule, bank=bank, staff=staff)


@bp.route("/centers/<int:center_id>/edit", methods=["GET", "POST"])
@permission_required("centers.manage")
def center_edit(center_id):
    _can_manage_center(center_id)
    db = get_db()
    c = db.get("blood_centers", center_id)
    if request.method == "POST":
        form = Form({**request.form.to_dict(), "_id": center_id})
        _validate(form, db)
        if form.ok:
            data = {k: form.clean.get(k) for k in FIELDS}
            changes = audit.diff(c, data, FIELDS)
            db.update("blood_centers", center_id, {**data, "updated_at": utcnow()})
            audit.log("center_update", "center", center_id, changes)
            flash("تم حفظ بيانات المركز.", "success")
            return redirect(url_for("admin.center_detail", center_id=center_id))
    else:
        form = Form({**{k: ("" if c[k] is None else c[k]) for k in FIELDS},
                     "accepts_appointments": "1" if c["accepts_appointments"] else "",
                     "phone": c["phone"] and ("0" + c["phone"][4:] if c["phone"].startswith("+249") else c["phone"])})
    return render_template("admin/center_form.html", form=form, governorates=scoped_governorates(), c=c)


@bp.route("/centers/<int:center_id>/status", methods=["POST"])
@permission_required("centers.manage")
def center_status(center_id):
    _can_manage_center(center_id)
    db = get_db()
    c = db.get("blood_centers", center_id)
    new = "inactive" if c["status"] == "active" else "active"
    db.update("blood_centers", center_id, {"status": new, "updated_at": utcnow()})
    audit.log("center_status", "center", center_id, {"الحالة": {"من": c["status"], "إلى": new}})
    flash("تم تعطيل المركز. لن يظهر للجمهور ولن يقبل حجوزات جديدة." if new == "inactive" else "تم تفعيل المركز.", "success")
    return redirect(url_for("admin.center_detail", center_id=center_id))


@bp.route("/centers/<int:center_id>/schedule", methods=["POST"])
@permission_required("centers.manage", "appointments.manage")
def center_schedule(center_id):
    require_center(center_id)
    if not g.user.can("centers.manage") and "center_manager" not in g.user.scope.roles:
        abort(403)
    db = get_db()
    errors = []
    rows = []
    for wd in range(7):
        if not request.form.get(f"on_{wd}"):
            continue
        f = Form({"s": request.form.get(f"start_{wd}"), "e": request.form.get(f"end_{wd}"),
                  "m": request.form.get(f"slot_{wd}"), "c": request.form.get(f"cap_{wd}")})
        f.time("s", "بداية الدوام"); f.time("e", "نهاية الدوام")
        f.integer("m", "مدة الموعد", min_value=10, max_value=240); f.integer("c", "السعة", min_value=1, max_value=100)
        if f.ok and f.clean["s"] >= f.clean["e"]:
            f.error("e", "نهاية الدوام يجب أن تكون بعد بدايته")
        if not f.ok:
            errors.append(f"{WEEKDAYS[wd]}: " + "، ".join(f.errors.values()))
        rows.append((wd, f.clean))
    if errors:
        flash("لم يتم الحفظ: " + " | ".join(errors), "error")
        return redirect(url_for("admin.center_detail", center_id=center_id) + "#schedule")
    with db.transaction():
        db.execute("DELETE FROM center_schedules WHERE center_id = ?", (center_id,))
        for wd, v in rows:
            db.insert("center_schedules", {"center_id": center_id, "weekday": wd, "start_time": v["s"], "end_time": v["e"],
                                           "slot_minutes": v["m"], "capacity_per_slot": v["c"]})
    audit.log("center_update", "center", center_id, {"جدول المواعيد": [f"{wd}:{v['s']}-{v['e']}" for wd, v in rows]})
    flash("تم حفظ جدول المواعيد.", "success")
    return redirect(url_for("admin.center_detail", center_id=center_id))
