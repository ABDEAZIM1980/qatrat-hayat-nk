"""التقرير الشهري لبنوك الدم: الإعداد، الإرسال، المراجعة والاعتماد، والتقرير المجمّع (شهر / ربع / سنة)."""
import base64

from flask import Response, abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, utcnow
from ...notifications import notify, notify_center_staff
from ...rbac import center_filter
from ...security import permission_required
from ...services import monthly_reports as mr
from ...services.common import get_setting
from ...services.reports import embedded_font_css, html_to_pdf
from ...timeutil import local_now, parse_ts
from . import bp, require_center, scoped_centers, scoped_governorates

EDITABLE = ("draft", "returned")
ANY_PERM = ("monthly_reports.edit", "monthly_reports.submit", "monthly_reports.review")


def _default_period():
    """التقرير يُعدّ بعد انتهاء الشهر: الافتراضي هو الشهر الماضي."""
    now = local_now()
    return (now.year, now.month - 1) if now.month > 1 else (now.year - 1, 12)


def _int_arg(name, lo, hi, default):
    v = request.args.get(name, type=int)
    return v if v is not None and lo <= v <= hi else default


def _get(report_id):
    r = get_db().one(
        """SELECT m.*, c.name AS center_name, c.center_type, c.governorate_id, c.locality_id,
                  gv.name_ar AS governorate, l.name_ar AS locality,
                  su.full_name AS submitted_by_name, ru.full_name AS reviewed_by_name
           FROM monthly_reports m JOIN blood_centers c ON c.id = m.center_id
           JOIN governorates gv ON gv.id = c.governorate_id JOIN localities l ON l.id = c.locality_id
           LEFT JOIN users su ON su.id = m.submitted_by LEFT JOIN users ru ON ru.id = m.reviewed_by
           WHERE m.id = ?""", (report_id,))
    if not r:
        abort(404)
    require_center(r["center_id"])
    return r


def _can_edit(r):
    return g.user.can("monthly_reports.edit") and r["status"] in EDITABLE


def _period_label(r):
    return f"شهر {mr.MONTHS_AR[r['month'] - 1]} {r['year']}م"


# ---------------- القائمة ومتابعة الإرسال ----------------
@bp.route("/monthly-reports")
@permission_required(*ANY_PERM)
def monthly_reports():
    db = get_db()
    dy, dm = _default_period()
    year = _int_arg("year", 2020, 2100, dy)
    month = _int_arg("month", 1, 12, dm)
    gov = request.args.get("governorate_id", type=int)
    centers = [c for c in scoped_centers(active_only=True) if not gov or c["governorate_id"] == gov]
    existing = {r["center_id"]: r for r in db.query(
        "SELECT id, center_id, status, submitted_at, updated_at FROM monthly_reports WHERE year = ? AND month = ?", (year, month))}
    rows = []
    counts = {"missing": 0, "draft": 0, "submitted": 0, "returned": 0, "accepted": 0}
    for c in centers:
        rep = existing.get(c["id"])
        st = rep["status"] if rep else "missing"
        counts[st] += 1
        rows.append({"center": c, "report": rep, "status": st})
    cf, cp = center_filter(g.user.scope)
    recent = db.query(
        f"""SELECT m.id, m.year, m.month, m.status, m.updated_at, c.name AS center_name
            FROM monthly_reports m JOIN blood_centers c ON c.id = m.center_id WHERE {cf}
            ORDER BY m.year DESC, m.month DESC, c.name LIMIT 24""", cp)
    now = local_now()
    return render_template("admin/monthly_reports.html", rows=rows, counts=counts, year=year, month=month,
                           months=mr.MONTHS_AR, years=list(range(now.year, 2023, -1)), recent=recent,
                           governorates=scoped_governorates(), gov=gov,
                           is_future=(year, month) > (now.year, now.month))


@bp.route("/monthly-reports/new", methods=["POST"])
@permission_required("monthly_reports.edit")
def monthly_report_new():
    db = get_db()
    center_id = request.form.get("center_id", type=int)
    year = request.form.get("year", type=int)
    month = request.form.get("month", type=int)
    require_center(center_id)
    now = local_now()
    if not year or not month or not (2020 <= year <= 2100 and 1 <= month <= 12) or (year, month) > (now.year, now.month):
        flash("اختر شهرًا صحيحًا (لا يمكن إعداد تقرير لشهر لم يبدأ بعد).", "error")
        return redirect(url_for("admin.monthly_reports"))
    old = db.one("SELECT id FROM monthly_reports WHERE center_id = ? AND year = ? AND month = ?", (center_id, year, month))
    if old:
        return redirect(url_for("admin.monthly_report", report_id=old["id"]))
    data = mr.empty_data()
    prev = db.one("SELECT data FROM monthly_reports WHERE center_id = ? ORDER BY year DESC, month DESC LIMIT 1", (center_id,))
    if prev:
        # نقترح أقسام ومستشفيات الشهر السابق (بدون أرقامها)
        pdata = mr.load(prev)
        if pdata["transfusion"]:
            data["transfusion"] = [{"dept": x["dept"], **{c: None for c, _ in mr.COMPONENTS}} for x in pdata["transfusion"]]
        data["units"] = pdata["units"]
    ts = utcnow()
    rid = db.insert("monthly_reports", {"center_id": center_id, "year": year, "month": month, "status": "draft",
                                        "data": mr.dumps(data), "created_by": g.user.id, "updated_by": g.user.id,
                                        "created_at": ts, "updated_at": ts})
    audit.log("monthly_create", "monthly_report", rid, {"الشهر": f"{month}/{year}"})
    return redirect(url_for("admin.monthly_report", report_id=rid))


# ---------------- الاستمارة ----------------
@bp.route("/monthly-reports/<int:report_id>", methods=["GET", "POST"])
@permission_required(*ANY_PERM)
def monthly_report(report_id):
    db = get_db()
    r = _get(report_id)
    data = mr.load(r)
    errors = []
    posted = None
    if request.method == "POST":
        if not _can_edit(r):
            abort(403)
        action = request.form.get("action", "save")
        posted = request.form
        data, errors = mr.parse_form(request.form)
        ref_no = " ".join((request.form.get("ref_no") or "").split())[:40] or None
        notes = (request.form.get("notes") or "").strip()[:1000] or None
        if action == "submit" and not errors:
            if not g.user.can("monthly_reports.submit"):
                abort(403)
            msg = mr.missing_for_submit(data)
            if msg:
                errors.append(msg)
        if not errors:
            upd = {"data": mr.dumps(data), "ref_no": ref_no, "notes": notes, "updated_by": g.user.id, "updated_at": utcnow()}
            filled = []
            if action == "autofill":
                filled = mr.apply_platform_figures(data, mr.platform_figures(r["center_id"], r["year"], r["month"]))
                upd["data"] = mr.dumps(data)
            if action == "submit":
                upd.update({"status": "submitted", "submitted_by": g.user.id, "submitted_at": utcnow(), "review_note": None})
            db.update("monthly_reports", report_id, upd)
            if action == "submit":
                audit.log("monthly_submit", "monthly_report", report_id, {"المركز": r["center_name"], "الشهر": _period_label(r)})
                _notify_reviewers(r)
                flash("تم إرسال التقرير للمراجعة. سيصلك إشعار عند اعتماده أو إعادته.", "success")
            else:
                audit.log("monthly_update", "monthly_report", report_id, {"الشهر": _period_label(r)})
                if action == "autofill":
                    flash(("تمت تعبئة: " + "، ".join(filled) + ". راجع الأرقام قبل الإرسال.") if filled
                          else "لا توجد خانات فارغة يمكن تعبئتها من بيانات المنصة لهذا الشهر.", "info")
                else:
                    flash("تم حفظ التقرير كمسودة.", "success")
            return redirect(url_for("admin.monthly_report", report_id=report_id) + ("#service" if action == "autofill" else ""))
    depts, camps = mr.form_rows(data)
    figs = mr.platform_figures(r["center_id"], r["year"], r["month"]) if _can_edit(r) else None
    return render_template("admin/monthly_report.html", r=r, data=data, t=mr.totals(data), depts=depts, camps=camps,
                           errors=errors, posted=posted, editable=_can_edit(r), mr=mr, figs=figs,
                           period=_period_label(r), can_review=g.user.can("monthly_reports.review"))


@bp.route("/monthly-reports/<int:report_id>/review", methods=["POST"])
@permission_required("monthly_reports.review")
def monthly_report_review(report_id):
    db = get_db()
    r = _get(report_id)
    action = request.form.get("action")
    note = (request.form.get("note") or "").strip()[:500] or None
    link = url_for("admin.monthly_report", report_id=report_id)
    if action == "accept" and r["status"] == "submitted":
        db.update("monthly_reports", report_id, {"status": "accepted", "reviewed_by": g.user.id, "reviewed_at": utcnow(),
                                                 "review_note": note, "updated_at": utcnow()})
        audit.log("monthly_accept", "monthly_report", report_id, {"المركز": r["center_name"], "الشهر": _period_label(r)})
        notify_center_staff(r["center_id"], "monthly_report", "اعتُمد التقرير الشهري",
                            f"اعتُمد تقرير {_period_label(r)} لـ{r['center_name']}.", link)
        flash("تم اعتماد التقرير.", "success")
    elif action == "return" and r["status"] in ("submitted", "accepted"):
        if not note:
            flash("اكتب سبب الإعادة حتى يعرف بنك الدم ما المطلوب تعديله.", "error")
            return redirect(link + "#review")
        db.update("monthly_reports", report_id, {"status": "returned", "reviewed_by": g.user.id, "reviewed_at": utcnow(),
                                                 "review_note": note, "updated_at": utcnow()})
        audit.log("monthly_return", "monthly_report", report_id, {"المركز": r["center_name"], "السبب": note})
        notify_center_staff(r["center_id"], "monthly_report", "أُعيد التقرير الشهري للتعديل",
                            f"أُعيد تقرير {_period_label(r)} لـ{r['center_name']}: {note}", link)
        flash("أُعيد التقرير إلى بنك الدم للتعديل.", "success")
    else:
        flash("لا يمكن تنفيذ هذا الإجراء على التقرير في حالته الحالية.", "error")
    return redirect(link)


def _notify_reviewers(r):
    db = get_db()
    rows = db.query(
        """SELECT DISTINCT ur.user_id FROM user_roles ur JOIN roles ro ON ro.id = ur.role_id JOIN users u ON u.id = ur.user_id
           WHERE u.status = 'active' AND (
             (ro.code IN ('state_admin', 'state_manager') AND ur.governorate_id = ?) OR (ro.code = 'locality_manager' AND ur.locality_id = ?)
             OR ro.code IN ('general_admin', 'super_admin'))""", (r["governorate_id"], r["locality_id"]))
    notify([x["user_id"] for x in rows if x["user_id"] != g.user.id], "monthly_report", "تقرير شهري جديد للمراجعة",
           f"أرسل {r['center_name']} تقرير {_period_label(r)}.", url_for("admin.monthly_report", report_id=r["id"]),
           respect_prefs=False)


# ---------------- الطباعة والتصدير ----------------
def _letterhead():
    keys = ("report_ministry", "report_department", "report_addressee", "report_signatory", "report_cc")
    lh = {k: get_setting(k) or "" for k in keys}
    row = get_db().one("SELECT data, meta FROM stored_files WHERE name = 'report_logo'")
    lh["logo"] = None
    if row:
        mime = "image/svg+xml" if b"<svg" in bytes(row["data"])[:400] else (
            "image/png" if bytes(row["data"])[:4] == b"\x89PNG" else "image/jpeg")
        lh["logo"] = f"data:{mime};base64,{base64.b64encode(bytes(row['data'])).decode()}"
    return lh


def _render_doc(ctx, fmt, fname):
    if fmt == "xlsx":
        body = mr.to_xlsx(ctx["subject"], ctx["header_line"], ctx["data"])
        return Response(body, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": f"attachment; filename={fname}.xlsx"})
    if fmt == "pdf":
        html = render_template("admin/monthly_report_print.html", font_css=embedded_font_css(), **ctx)
        pdf = html_to_pdf(html, landscape=True)
        if pdf:
            return Response(pdf, mimetype="application/pdf", headers={"Content-Disposition": f"attachment; filename={fname}.pdf"})
    # صفحة طباعة: «حفظ كـ PDF» من المتصفح (تعمل على أي استضافة)
    return render_template("admin/monthly_report_print.html", auto_print=fmt == "pdf", **ctx)


@bp.route("/monthly-reports/<int:report_id>/print")
@permission_required(*ANY_PERM)
def monthly_report_print(report_id):
    r = _get(report_id)
    data = mr.load(r)
    lh = _letterhead()
    dt = parse_ts(r["submitted_at"]) or local_now()
    ctx = {"data": data, "t": mr.totals(data), "mr": mr, "lh": lh, "governorate": r["governorate"],
           "ref_no": r["ref_no"], "date": dt.strftime("%d-%m-%Y"),
           "addressee": f"مدير {lh['report_department']}" if lh["report_department"] else "",
           "subject": f"التقرير الشهري لبنك الدم — {r['center_name']} — {_period_label(r)}",
           "header_line": f"{r['center_name']} — محلية {r['locality']} — {_period_label(r)}",
           "signatory": f"مدير {r['center_name']}", "cc": "", "notes": r["notes"],
           "draft": r["status"] not in ("submitted", "accepted"),
           "back_url": url_for("admin.monthly_report", report_id=report_id)}
    fmt = request.args.get("format")
    if fmt in ("xlsx", "pdf"):
        audit.log("report_export", "monthly_report", report_id, {"الصيغة": fmt})
    return _render_doc(ctx, fmt, f"qatrat-monthly-{r['year']}-{r['month']:02d}-c{r['center_id']}")


@bp.route("/monthly-reports/summary")
@permission_required("monthly_reports.review")
def monthly_summary():
    db = get_db()
    dy, dm = _default_period()
    year = _int_arg("year", 2020, 2100, dy)
    period = request.args.get("period") or f"m{dm}"
    months, plabel = mr.period_months(year, period)
    gov = request.args.get("governorate_id", type=int)
    center_id = request.args.get("center_id", type=int)
    only_accepted = request.args.get("accepted") == "1"
    cf, cp = center_filter(g.user.scope)
    where = [cf, f"m.month IN ({','.join('?' for _ in months)})", "m.year = ?",
             "m.status IN ('accepted')" if only_accepted else "m.status IN ('submitted','accepted')"]
    params = cp + months + [year]
    if gov:
        where.append("c.governorate_id = ?"); params.append(gov)
    if center_id:
        require_center(center_id)
        where.append("c.id = ?"); params.append(center_id)
    rows = db.query(
        f"""SELECT m.*, c.name AS center_name, c.governorate_id, gv.name_ar AS governorate
            FROM monthly_reports m JOIN blood_centers c ON c.id = m.center_id
            JOIN governorates gv ON gv.id = c.governorate_id WHERE {' AND '.join(where)}
            ORDER BY m.year, m.month, c.name""", params)
    data = mr.aggregate(rows)
    centers = [c for c in scoped_centers(active_only=True) if (not gov or c["governorate_id"] == gov)
               and (not center_id or c["id"] == center_id)]
    have = {(x["center_id"], x["month"]) for x in rows}
    missing = [{"center": c["name"], "month": mr.MONTHS_AR[m - 1]} for c in centers for m in months
               if (c["id"], m) not in have and (year, m) <= (local_now().year, local_now().month)]
    govs = {x["governorate"] for x in rows}
    governorate = (db.scalar("SELECT name_ar FROM governorates WHERE id = ?", (gov,)) if gov
                   else (next(iter(govs)) if len(govs) == 1 else None))
    lh = _letterhead()
    scope_name = (db.scalar("SELECT name FROM blood_centers WHERE id = ?", (center_id,)) if center_id else "بنوك الدم")
    ctx = {"data": data, "t": mr.totals(data), "mr": mr, "lh": lh, "governorate": governorate, "ref_no": None,
           "date": local_now().strftime("%d-%m-%Y"), "addressee": lh["report_addressee"],
           "subject": f"تقرير {'لبنك الدم' if center_id else scope_name} — {plabel}",
           "header_line": f"{scope_name} — {plabel} — عدد التقارير المجمّعة: {len(rows)}",
           "signatory": lh["report_signatory"], "cc": lh["report_cc"], "notes": None, "draft": False,
           "summary": True, "back_url": url_for("admin.monthly_summary", **{k: v for k, v in request.args.items() if k != "format"})}
    fmt = request.args.get("format")
    if fmt in ("print", "pdf", "xlsx"):
        audit.log("report_export", "monthly_report", None, {"التقرير": "التقرير المجمّع", "الفترة": plabel, "الصيغة": fmt})
        return _render_doc(ctx, fmt if fmt != "print" else None, f"qatrat-summary-{year}-{period}")
    return render_template("admin/monthly_summary.html", rows=rows, missing=missing, year=year, period=period, plabel=plabel,
                           periods=mr.period_choices(), years=list(range(local_now().year, 2023, -1)),
                           governorates=scoped_governorates(), centers=scoped_centers(active_only=True), gov=gov,
                           center_id=center_id, only_accepted=only_accepted, **ctx)


# ---------------- شعار الترويسة ----------------
@bp.route("/settings/report-logo", methods=["POST"])
@permission_required("settings.manage")
def report_logo():
    db = get_db()
    if request.form.get("action") == "remove":
        db.execute("DELETE FROM stored_files WHERE name = 'report_logo'")
        audit.log("settings_update", "settings", None, {"شعار التقارير": "حذف"})
        flash("تم حذف الشعار.", "success")
        return redirect(url_for("admin.settings") + "#letterhead")
    f = request.files.get("logo")
    raw = f.read(600 * 1024 + 1) if f else b""
    ok_type = raw[:4] == b"\x89PNG" or raw[:3] == b"\xff\xd8\xff"
    if not raw or len(raw) > 600 * 1024 or not ok_type:
        flash("ارفع صورة PNG أو JPG لا يزيد حجمها عن 600 كيلوبايت.", "error")
        return redirect(url_for("admin.settings") + "#letterhead")
    with db.transaction():
        db.execute("DELETE FROM stored_files WHERE name = 'report_logo'")
        db.execute("INSERT INTO stored_files (name, data, meta, updated_at) VALUES (?, ?, ?, ?)",
                   ("report_logo", raw, "{}", utcnow()))
    audit.log("settings_update", "settings", None, {"شعار التقارير": "تحديث"})
    flash("تم حفظ شعار التقارير.", "success")
    return redirect(url_for("admin.settings") + "#letterhead")
