"""إدارة المستخدمين وإسناد الأدوار ضمن النطاق الإداري."""
import secrets

from flask import abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate, utcnow
from ...rbac import ROLE_NAMES, ROLE_RANK, ROLE_SCOPE, accessible_center_ids, assignable_roles
from ...security import hash_password, permission_required
from ...validators import Form
from . import bp, scoped_centers, scoped_governorates


def _visible_user_filter():
    """المستخدمون الإداريون المرئيون ضمن نطاق المستخدم الحالي."""
    s = g.user.scope
    if s.is_global:
        return "1=1", []
    db = get_db()
    parts, params = [], []
    govs = sorted(s.governorate_ids)
    if govs:
        ph = ",".join("?" for _ in govs)
        parts.append(f"ur.governorate_id IN ({ph}) OR ur.locality_id IN (SELECT id FROM localities WHERE governorate_id IN ({ph}))")
        params += govs * 2
    if s.locality_ids:
        locs = sorted(s.locality_ids)
        parts.append(f"ur.locality_id IN ({','.join('?' for _ in locs)})"); params += locs
    centers = accessible_center_ids(db, s) or []
    if centers:
        parts.append(f"ur.center_id IN ({','.join('?' for _ in centers)})"); params += centers
    if not parts:
        return "1=0", []
    return f"u.id IN (SELECT ur.user_id FROM user_roles ur WHERE {' OR '.join(parts)})", params


def _user_max_rank(user_id):
    rows = get_db().query("SELECT r.code FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ?", (user_id,))
    return max([ROLE_RANK.get(r["code"], 0) for r in rows] or [0])


def _get_manageable_user(user_id):
    db = get_db()
    vf, vp = _visible_user_filter()
    u = db.one(f"SELECT u.* FROM users u WHERE u.id = ? AND u.is_staff = 1 AND {vf}", [user_id, *vp])
    if not u:
        abort(404)
    if "super_admin" not in g.user.scope.roles and _user_max_rank(user_id) >= g.user.scope.max_rank:
        abort(403)
    return u


@bp.route("/users")
@permission_required("users.view")
def users():
    db = get_db()
    vf, vp = _visible_user_filter()
    where, params = ["u.is_staff = 1", vf], list(vp)
    q = (request.args.get("q") or "").strip()[:60]
    role = request.args.get("role")
    status = request.args.get("status")
    if q:
        from ...validators import normalize_phone
        where.append(f"(u.full_name {db.like()} ? OR u.phone = ?)"); params += [f"%{q}%", normalize_phone(q) or "-"]
    if role in ROLE_NAMES:
        where.append("u.id IN (SELECT ur.user_id FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE r.code = ?)")
        params.append(role)
    if status in ("active", "suspended", "disabled"):
        where.append("u.status = ?"); params.append(status)
    page = paginate(db, f"SELECT u.* FROM users u WHERE {' AND '.join(where)} ORDER BY u.full_name", params,
                    request.args.get("page", 1, type=int))
    for u in page["rows"]:
        u["roles"] = _roles_of(u["id"])
    return render_template("admin/users.html", page=page, roles=ROLE_NAMES)


def _roles_of(user_id):
    return get_db().query(
        """SELECT ur.id, r.code, g.name_ar AS governorate, l.name_ar AS locality, c.name AS center
           FROM user_roles ur JOIN roles r ON r.id = ur.role_id LEFT JOIN governorates g ON g.id = ur.governorate_id
           LEFT JOIN localities l ON l.id = ur.locality_id LEFT JOIN blood_centers c ON c.id = ur.center_id
           WHERE ur.user_id = ? ORDER BY r.rank DESC""", (user_id,))


def _validate_assignment(form, db):
    """التحقق من أن الدور والنطاق ضمن صلاحيات المستخدم الحالي."""
    allowed = [r for r in assignable_roles(g.user.scope, g.user.perms) if r != "donor"]
    role = form.choice("role", "الدور", allowed)
    if not role:
        return None
    level = ROLE_SCOPE[role]
    s = g.user.scope
    scope = {"governorate_id": None, "locality_id": None, "center_id": None}
    if level == "governorate":
        gov = form.fk("scope_governorate_id", "الولاية", db, "governorates")
        if gov and not (s.is_global or gov["id"] in s.governorate_ids):
            form.error("scope_governorate_id", "الولاية خارج نطاق صلاحياتك.")
        scope["governorate_id"] = gov and gov["id"]
    elif level == "locality":
        loc = form.fk("scope_locality_id", "المحلية", db, "localities")
        if loc and not (s.is_global or loc["governorate_id"] in s.governorate_ids or loc["id"] in s.locality_ids):
            form.error("scope_locality_id", "المحلية خارج نطاق صلاحياتك.")
        scope["locality_id"] = loc and loc["id"]
    elif level == "center":
        c = form.fk("scope_center_id", "المركز", db, "blood_centers")
        ids = accessible_center_ids(db, s)
        if c and ids is not None and c["id"] not in ids:
            form.error("scope_center_id", "المركز خارج نطاق صلاحياتك.")
        scope["center_id"] = c and c["id"]
    return role, scope


def _assign_ctx():
    db = get_db()
    govs = scoped_governorates()
    gids = [x["id"] for x in govs]
    locs = db.query(f"""SELECT l.id, l.name_ar, g.name_ar AS governorate FROM localities l JOIN governorates g ON g.id = l.governorate_id
                        WHERE l.governorate_id IN ({','.join('?' for _ in gids) or 'NULL'}) ORDER BY g.name_ar, l.name_ar""", gids) if gids else []
    if not g.user.scope.is_global and not g.user.scope.governorate_ids:
        locs = [x for x in locs if x["id"] in g.user.scope.locality_ids]
    return {"assignable": [(r, ROLE_NAMES[r], ROLE_SCOPE[r]) for r in assignable_roles(g.user.scope, g.user.perms) if r != "donor"],
            "governorates": govs, "localities": locs, "centers": scoped_centers()}


@bp.route("/users/new", methods=["GET", "POST"])
@permission_required("users.manage")
def user_new():
    db = get_db()
    form = Form(request.form)
    temp = None
    if request.method == "POST":
        form.text("full_name", "الاسم الكامل", min_len=5, max_len=120)
        form.phone()
        form.email()
        res = _validate_assignment(form, db)
        if form.ok and db.one("SELECT id FROM users WHERE phone = ?", (form.clean["phone"],)):
            form.error("phone", "هذا الرقم مسجل لمستخدم آخر.")
        if form.ok and form.clean.get("email") and db.one("SELECT id FROM users WHERE email = ?", (form.clean["email"],)):
            form.error("email", "البريد مستخدم مسبقًا.")
        if form.ok and res:
            role, scope = res
            temp = "Qh" + secrets.token_urlsafe(6) + "9"
            now = utcnow()
            with db.transaction():
                uid = db.insert("users", {"full_name": form.clean["full_name"], "phone": form.clean["phone"],
                                          "email": form.clean.get("email"), "password_hash": hash_password(temp),
                                          "status": "active", "is_staff": 1, "created_at": now, "updated_at": now})
                db.insert("user_roles", {"user_id": uid, "role_id": db.scalar("SELECT id FROM roles WHERE code = ?", (role,)),
                                         **scope, "assigned_by": g.user.id, "created_at": now})
            audit.log("user_create", "user", uid, {"الاسم": form.clean["full_name"], "الدور": ROLE_NAMES[role]})
            audit.log("role_assign", "user", uid, {"الدور": ROLE_NAMES[role], **{k: v for k, v in scope.items() if v}})
            return render_template("admin/user_created.html", name=form.clean["full_name"], phone=form.clean["phone"],
                                   temp=temp, user_id=uid)
    return render_template("admin/user_form.html", form=form, u=None, **_assign_ctx())


@bp.route("/users/<int:user_id>", methods=["GET", "POST"])
@permission_required("users.view")
def user_detail(user_id):
    db = get_db()
    vf, vp = _visible_user_filter()
    u = db.one(f"SELECT u.* FROM users u WHERE u.id = ? AND u.is_staff = 1 AND {vf}", [user_id, *vp])
    if not u:
        abort(404)
    can_manage = g.user.can("users.manage") and ("super_admin" in g.user.scope.roles or _user_max_rank(user_id) < g.user.scope.max_rank)
    form = Form({"full_name": u["full_name"], "email": u["email"] or "", "status": u["status"]})
    if request.method == "POST":
        if not can_manage:
            abort(403)
        form = Form(request.form)
        form.text("full_name", "الاسم الكامل", min_len=5, max_len=120)
        form.email()
        form.choice("status", "الحالة", ["active", "suspended", "disabled"])
        if form.ok and form.clean.get("email") and db.one("SELECT id FROM users WHERE email = ? AND id != ?", (form.clean["email"], user_id)):
            form.error("email", "البريد مستخدم مسبقًا.")
        if form.ok and user_id == g.user.id and form.clean["status"] != "active":
            form.error("status", "لا يمكنك إيقاف حسابك بنفسك.")
        if form.ok:
            data = {"full_name": form.clean["full_name"], "email": form.clean.get("email"), "status": form.clean["status"]}
            changes = audit.diff(u, data, list(data))
            upd = {**data, "updated_at": utcnow()}
            with db.transaction():
                db.update("users", user_id, upd)
                if data["status"] != u["status"]:
                    db.execute("UPDATE users SET auth_version = auth_version + 1 WHERE id = ?", (user_id,))
            audit.log("user_update", "user", user_id, changes)
            flash("تم حفظ بيانات المستخدم.", "success")
            return redirect(url_for("admin.user_detail", user_id=user_id))
    return render_template("admin/user_detail.html", u=u, roles=_roles_of(user_id), form=form, can_manage=can_manage,
                           assign_form=Form({}), **_assign_ctx())


@bp.route("/users/<int:user_id>/roles", methods=["POST"])
@permission_required("roles.assign")
def user_assign_role(user_id):
    db = get_db()
    _get_manageable_user(user_id)
    form = Form(request.form)
    res = _validate_assignment(form, db)
    if not form.ok or not res:
        flash("تعذر إسناد الدور: " + "، ".join(form.errors.values()), "error")
        return redirect(url_for("admin.user_detail", user_id=user_id))
    role, scope = res
    rid = db.scalar("SELECT id FROM roles WHERE code = ?", (role,))
    exists = db.one("SELECT id FROM user_roles WHERE user_id = ? AND role_id = ? AND COALESCE(governorate_id,0) = ? "
                    "AND COALESCE(locality_id,0) = ? AND COALESCE(center_id,0) = ?",
                    (user_id, rid, scope["governorate_id"] or 0, scope["locality_id"] or 0, scope["center_id"] or 0))
    if exists:
        flash("هذا الدور مسند مسبقًا بنفس النطاق.", "info")
    else:
        with db.transaction():
            db.insert("user_roles", {"user_id": user_id, "role_id": rid, **scope, "assigned_by": g.user.id, "created_at": utcnow()})
            db.execute("UPDATE users SET auth_version = auth_version + 1, updated_at = ? WHERE id = ?", (utcnow(), user_id))
        audit.log("role_assign", "user", user_id, {"الدور": ROLE_NAMES[role], **{k: v for k, v in scope.items() if v}})
        flash("تم إسناد الدور. سيُطلب من المستخدم تسجيل الدخول من جديد.", "success")
    return redirect(url_for("admin.user_detail", user_id=user_id))


@bp.route("/users/<int:user_id>/roles/<int:ur_id>/revoke", methods=["POST"])
@permission_required("roles.assign")
def user_revoke_role(user_id, ur_id):
    db = get_db()
    _get_manageable_user(user_id)
    ur = db.one("SELECT ur.*, r.code FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.id = ? AND ur.user_id = ?",
                (ur_id, user_id))
    if not ur:
        abort(404)
    if user_id == g.user.id:
        flash("لا يمكنك سحب أدوارك بنفسك.", "error")
        return redirect(url_for("admin.user_detail", user_id=user_id))
    with db.transaction():
        db.execute("DELETE FROM user_roles WHERE id = ?", (ur_id,))
        db.execute("UPDATE users SET auth_version = auth_version + 1, updated_at = ? WHERE id = ?", (utcnow(), user_id))
    audit.log("role_revoke", "user", user_id, {"الدور": ROLE_NAMES.get(ur["code"], ur["code"])})
    flash("تم سحب الدور.", "success")
    return redirect(url_for("admin.user_detail", user_id=user_id))


@bp.route("/users/<int:user_id>/reset-password", methods=["POST"])
@permission_required("users.manage")
def user_reset_password(user_id):
    db = get_db()
    u = _get_manageable_user(user_id)
    temp = "Qh" + secrets.token_urlsafe(6) + "9"
    db.execute("UPDATE users SET password_hash = ?, auth_version = auth_version + 1, failed_logins = 0, locked_until = NULL, "
               "updated_at = ? WHERE id = ?", (hash_password(temp), utcnow(), user_id))
    audit.log("password_change", "user", user_id, {"إجراء": "إعادة تعيين بواسطة الإدارة"})
    return render_template("admin/user_created.html", name=u["full_name"], phone=u["phone"], temp=temp, user_id=user_id,
                           reset=True)
