"""لوحات الإدارة: الإدارة العامة، الولاية، المحلية، المركز — محتوى كل صفحة محصور بنطاق المستخدم."""
from flask import Blueprint, abort, g

from ...db import get_db
from ...rbac import can_access_center, center_filter

bp = Blueprint("admin", __name__, url_prefix="/admin")


def scoped_centers(active_only=False, booking=False):
    db = get_db()
    cf, cp = center_filter(g.user.scope)
    where = [cf]
    if active_only:
        where.append("c.status = 'active'")
    if booking:
        where.append("c.accepts_appointments = 1")
    return db.query(
        f"""SELECT c.id, c.name, c.status, c.governorate_id, c.locality_id, g.name_ar AS governorate, l.name_ar AS locality
            FROM blood_centers c JOIN governorates g ON g.id = c.governorate_id JOIN localities l ON l.id = c.locality_id
            WHERE {' AND '.join(where)} ORDER BY g.name_ar, c.name""", cp)


def scoped_governorates():
    db = get_db()
    s = g.user.scope
    if s.is_global:
        return db.query("SELECT id, name_ar, is_active FROM governorates ORDER BY is_active DESC, name_ar")
    cf, cp = center_filter(s)
    ids = set(s.governorate_ids) | {r["governorate_id"] for r in db.query(
        f"SELECT DISTINCT c.governorate_id FROM blood_centers c WHERE {cf}", cp)}
    if s.locality_ids:
        ids |= {r["governorate_id"] for r in db.query(
            f"SELECT governorate_id FROM localities WHERE id IN ({','.join('?' for _ in s.locality_ids)})", sorted(s.locality_ids))}
    if not ids:
        return []
    return db.query(f"SELECT id, name_ar, is_active FROM governorates WHERE id IN ({','.join('?' for _ in ids)}) ORDER BY name_ar",
                    sorted(ids))


def require_center(center_id):
    if not center_id or not can_access_center(get_db(), g.user.scope, center_id):
        abort(403)


def scoped_one(sql_table_alias_query, params, center_col):
    """يجلب سجلًا ويتحقق أن مركزه ضمن نطاق المستخدم."""
    row = get_db().one(sql_table_alias_query, params)
    if not row:
        abort(404)
    require_center(row[center_col])
    return row


from . import dashboard, geography, centers, users, donors, appointments, donations, inventory, requests, appeals, \
    content, notifications, reports, audit_log, settings, imports  # noqa: E402,F401
