"""طلبات الدم: الإنشاء، الاعتماد/الرفض، الصرف من المخزون، الإلغاء."""
from datetime import timedelta

from flask import abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, paginate
from ...rbac import center_filter
from ...security import permission_required
from ...services import requests_appeals as ra
from ...timeutil import local_today
from ...validators import URGENCY, Form
from . import bp, require_center, scoped_centers


def _get(req_id):
    r = get_db().one(
        """SELECT r.*, c.name AS center_name, u.full_name AS requested_by_name, a.full_name AS approved_by_name
           FROM blood_requests r JOIN blood_centers c ON c.id = r.center_id JOIN users u ON u.id = r.requested_by
           LEFT JOIN users a ON a.id = r.approved_by WHERE r.id = ?""", (req_id,))
    if not r:
        abort(404)
    require_center(r["center_id"])
    return r


@bp.route("/requests")
@permission_required("requests.view")
def requests_list():
    db = get_db()
    cf, cp = center_filter(g.user.scope)
    where, params = [cf], list(cp)
    st = request.args.get("status", "open")
    if st == "open":
        where.append("r.status IN ('pending','approved','partially_fulfilled')")
    elif st in ("pending", "approved", "partially_fulfilled", "fulfilled", "rejected", "cancelled"):
        where.append("r.status = ?"); params.append(st)
    for k in ("blood_type", "urgency"):
        if request.args.get(k):
            where.append(f"r.{k} = ?"); params.append(request.args[k])
    c = request.args.get("center_id", type=int)
    if c:
        where.append("r.center_id = ?"); params.append(c)
    q = (request.args.get("q") or "").strip()[:60]
    if q:
        where.append(f"(r.request_code {db.like()} ? OR r.requesting_entity {db.like()} ?)"); params += [f"%{q}%"] * 2
    page = paginate(db, f"""SELECT r.*, c.name AS center_name FROM blood_requests r JOIN blood_centers c ON c.id = r.center_id
        WHERE {' AND '.join(where)} ORDER BY CASE r.urgency WHEN 'critical' THEN 0 WHEN 'urgent' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
        r.created_at DESC""", params, request.args.get("page", 1, type=int))
    return render_template("admin/requests.html", page=page, centers=scoped_centers(), st=st)


@bp.route("/requests/new", methods=["GET", "POST"])
@permission_required("requests.create")
def request_new():
    db = get_db()
    form = Form(request.form)
    if request.method == "POST":
        center = form.fk("center_id", "المركز / بنك الدم", db, "blood_centers", where="status = 'active'")
        if center:
            require_center(center["id"])
        form.blood_type()
        form.integer("units_required", "عدد الوحدات المطلوبة", min_value=1, max_value=100)
        form.urgency()
        form.text("requesting_entity", "الجهة الطالبة", min_len=3, max_len=150)
        form.text("patient_reference", "مرجع المريض (رقم ملف بدون اسم)", required=False, max_len=60)
        form.date("needed_by", "مطلوب قبل", required=False, min_date=local_today(), max_date=local_today() + timedelta(days=90))
        form.text("notes", "ملاحظات", required=False, max_len=1000)
        if form.ok:
            rid = ra.create_request(form.clean, g.user.id)
            audit.log("request_create", "blood_request", rid, {
                "الفصيلة": form.clean["blood_type"], "الوحدات": form.clean["units_required"],
                "الاستعجال": URGENCY[form.clean["urgency"]]})
            flash("تم إنشاء طلب الدم، وهو بانتظار الاعتماد.", "success")
            return redirect(url_for("admin.request_detail", req_id=rid))
    return render_template("admin/request_form.html", form=form, centers=scoped_centers(active_only=True))


@bp.route("/requests/<int:req_id>")
@permission_required("requests.view")
def request_detail(req_id):
    r = _get(req_id)
    db = get_db()
    stock = {row["blood_type"]: row for row in db.query("SELECT * FROM blood_inventory WHERE center_id = ?", (r["center_id"],))}
    issues = db.query("""SELECT t.*, c.name AS center_name, u.full_name AS by_name FROM blood_inventory_transactions t
                         JOIN blood_centers c ON c.id = t.center_id LEFT JOIN users u ON u.id = t.created_by
                         WHERE t.reference_type = 'blood_request' AND t.reference_id = ? ORDER BY t.id""", (req_id,))
    appeals = db.query("SELECT id, title, status FROM emergency_appeals WHERE blood_request_id = ?", (req_id,))
    return render_template("admin/request_detail.html", r=r, stock=stock, issues=issues, appeals=appeals,
                           centers=scoped_centers(active_only=True))


@bp.route("/requests/<int:req_id>/action", methods=["POST"])
@permission_required("requests.view")
def request_action(req_id):
    r = _get(req_id)
    action = request.form.get("action")
    reason = (request.form.get("reason") or "").strip()[:255]
    try:
        if action == "approve":
            if not g.user.can("requests.approve"):
                abort(403)
            ra.approve_request(r, g.user.id)
            audit.log("request_approve", "blood_request", req_id, {"رقم الطلب": r["request_code"]})
            flash("تم اعتماد الطلب.", "success")
        elif action == "reject":
            if not g.user.can("requests.approve"):
                abort(403)
            if len(reason) < 3:
                raise ra.WorkflowError("يرجى كتابة سبب الرفض.")
            ra.reject_request(r, g.user.id, reason)
            audit.log("request_reject", "blood_request", req_id, {"السبب": reason})
            flash("تم رفض الطلب.", "success")
        elif action == "cancel":
            if not (g.user.can("requests.approve") or r["requested_by"] == g.user.id):
                abort(403)
            ra.cancel_request(r, reason or "ألغاه المستخدم")
            audit.log("request_update", "blood_request", req_id, {"الحالة": "ملغى", "السبب": reason})
            flash("تم إلغاء الطلب.", "success")
        elif action == "fulfill":
            if not g.user.can("requests.approve", "inventory.manage"):
                abort(403)
            f = Form(request.form)
            center = f.fk("issue_center_id", "مركز الصرف", get_db(), "blood_centers", where="status = 'active'")
            f.blood_type("issue_blood_type", "الفصيلة المصروفة")
            f.integer("units", "عدد الوحدات", min_value=1, max_value=100)
            if not f.ok:
                raise ra.WorkflowError("، ".join(f.errors.values()))
            require_center(center["id"])
            if not request.form.get("lab_confirm"):
                raise ra.WorkflowError("يجب تأكيد أن الفصيلة المصروفة معتمدة من المختبر.")
            done = ra.fulfill_request(r, center["id"], f.clean["issue_blood_type"], f.clean["units"], g.user.id)
            audit.log("request_fulfill", "blood_request", req_id, {
                "مركز الصرف": center["name"], "الفصيلة": f.clean["issue_blood_type"], "الوحدات": f.clean["units"]})
            audit.log("inventory_adjust", "inventory", center["id"], {
                "الحركة": "صرف", "الفصيلة": f.clean["issue_blood_type"], "الكمية": f.clean["units"], "الطلب": r["request_code"]})
            flash(f"تم صرف {f.clean['units']} وحدة. إجمالي المصروف: {done} من {r['units_required']}.", "success")
        else:
            abort(400)
    except ra.WorkflowError as e:
        flash(str(e), "error")
    return redirect(url_for("admin.request_detail", req_id=req_id))
