"""إعدادات النظام والنسخ الاحتياطي."""
from flask import abort, flash, g, redirect, render_template, request, send_file, url_for

from ... import audit

from ...security import permission_required
from ...services import backup
from ...services.common import DEFAULT_SETTINGS, get_setting, set_setting
from ...validators import Form
from . import bp

INT_SETTINGS = {"booking_window_days": (7, 180), "reminder_hours_before": (1, 72), "default_critical_level": (0, 100),
                "default_low_level": (0, 200)}


# الإعدادات التي تُحفظ من هذه الصفحة فقط (ملف assetlinks مثلًا يُدار من صفحة «تطبيق الهاتف»)
EDITABLE_SETTINGS = [*INT_SETTINGS, "support_phone", "public_registration", "copyright_owner"]


@bp.route("/settings", methods=["GET", "POST"])
@permission_required("settings.manage", "backups.manage")
def settings():
    values = {k: get_setting(k) for k in DEFAULT_SETTINGS}
    form = Form(values)
    if request.method == "POST":
        if not g.user.can("settings.manage"):
            abort(403)
        form = Form(request.form)
        for k, (lo, hi) in INT_SETTINGS.items():
            form.integer(k, DEFAULT_SETTINGS[k][1], min_value=lo, max_value=hi)
        form.phone("support_phone", "رقم الدعم")
        form.boolean("public_registration")
        form.text("copyright_owner", "صاحب حقوق الطبع", required=False, max_len=120)
        if form.ok and form.clean["default_low_level"] < form.clean["default_critical_level"]:
            form.error("default_low_level", "الحد المنخفض يجب أن يكون أكبر من أو يساوي الحد الحرج.")
        if form.ok:
            changes = {}
            for k in EDITABLE_SETTINGS:
                v = form.clean.get(k)
                if k == "copyright_owner":
                    v = (v or "").strip()
                v = "0" + v[4:] if k == "support_phone" and v else str(v)
                if v != values[k]:
                    changes[k] = {"من": values[k], "إلى": v}
                    set_setting(k, v, g.user.id)
            audit.log("settings_update", "settings", None, changes)
            flash("تم حفظ الإعدادات.", "success")
            return redirect(url_for("admin.settings"))
    backups = backup.list_backups() if g.user.can("backups.manage") else []
    return render_template("admin/settings.html", form=form, labels=DEFAULT_SETTINGS, backups=backups)


@bp.route("/settings/backup", methods=["POST"])
@permission_required("backups.manage")
def backup_create():
    path = backup.create_backup()
    audit.log("backup_create", "backup", None, {"الملف": path.name})
    # تُنزَّل النسخة فورًا أيضًا: في الاستضافة المجانية قد يُمسح قرص الخادم عند إعادة التشغيل
    return send_file(path, as_attachment=True, download_name=path.name)


@bp.route("/settings/backup/<name>")
@permission_required("backups.manage")
def backup_download(name):
    names = {b["name"] for b in backup.list_backups()}
    if name not in names:
        abort(404)
    audit.log("backup_create", "backup", None, {"تنزيل": name})
    return send_file(backup.backup_dir() / name, as_attachment=True)


