"""استيراد البيانات الحقيقية دفعة واحدة من Excel أو CSV: المحليات والمدن، والمراكز وبنوك الدم.

القاعدة: يُفحص الملف كاملًا أولًا؛ إذا وُجد أي خطأ لا يُستورد شيء وتظهر الأخطاء برقم الصف.
الصفوف الموجودة مسبقًا تُتجاوز ولا تُكرر.
"""
import csv
import io

from flask import Response, abort, flash, g, redirect, render_template, request, url_for

from ... import audit
from ...db import get_db, utcnow
from ...security import permission_required
from ...services import inventory
from ...services.common import CENTER_TYPES
from ...validators import Form
from . import bp

TEMPLATES = {
    "localities": {
        "title": "المحليات والمدن",
        "perm": "geography.manage",
        "columns": ["الولاية", "المحلية", "المدينة", "الاسم الإنجليزي للمحلية"],
        "example": ["شمال كردفان", "شيكان", "الأبيض", "Sheikan"],
    },
    "centers": {
        "title": "المراكز وبنوك الدم",
        "perm": "centers.manage",
        "columns": ["اسم المركز", "النوع", "الولاية", "المحلية", "المدينة", "العنوان", "الهاتف", "ساعات العمل",
                    "خط العرض", "خط الطول", "الخدمات", "يستقبل الحجوزات"],
        "example": ["مركز التبرع بالدم – مثال", "مركز تبرع", "شمال كردفان", "شيكان", "الأبيض", "شارع ...", "0912345678",
                    "السبت – الخميس: 8:00 ص – 2:00 م", "13.18", "30.21", "استقبال المتبرعين", "نعم"],
    },
}
TYPE_BY_AR = {v: k for k, v in CENTER_TYPES.items()}
YES = {"نعم", "yes", "1", "true", "y", "ن"}


def _read_rows(file):
    name = (file.filename or "").lower()
    data = file.read()
    if name.endswith(".xlsx"):
        from openpyxl import load_workbook
        wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
        ws = wb.worksheets[0]
        rows = [["" if c is None else str(c).strip() for c in r] for r in ws.iter_rows(values_only=True)]
    elif name.endswith(".csv"):
        text = data.decode("utf-8-sig", errors="replace")
        rows = [[c.strip() for c in r] for r in csv.reader(io.StringIO(text))]
    else:
        raise ValueError("صيغة الملف غير مدعومة. استخدم ملف Excel (.xlsx) أو CSV.")
    rows = [r for r in rows if any(c for c in r)]
    if not rows:
        raise ValueError("الملف فارغ.")
    return rows[0], rows[1:]


def _index(header, columns):
    idx = {}
    for col in columns:
        if col in header:
            idx[col] = header.index(col)
    return idx


def _cell(row, idx, col):
    i = idx.get(col)
    return row[i].strip() if i is not None and i < len(row) and row[i] else ""


def _scope_ok_locality(loc_gov_id, loc_id):
    s = g.user.scope
    return s.is_global or loc_gov_id in s.governorate_ids or loc_id in s.locality_ids


def _process_localities(header, rows, commit):
    db = get_db()
    idx = _index(header, TEMPLATES["localities"]["columns"])
    if "الولاية" not in idx or "المحلية" not in idx:
        raise ValueError("يجب أن يحتوي الملف على عمودي «الولاية» و«المحلية».")
    errors, created = [], {"localities": 0, "cities": 0, "skipped": 0}
    govs = {r["name_ar"]: r for r in db.query("SELECT * FROM governorates")}
    for n, row in enumerate(rows, start=2):
        gname, lname, cname = _cell(row, idx, "الولاية"), _cell(row, idx, "المحلية"), _cell(row, idx, "المدينة")
        if not gname or not lname:
            errors.append((n, "الولاية والمحلية مطلوبتان."))
            continue
        gov = govs.get(gname)
        if not gov:
            errors.append((n, f"الولاية «{gname}» غير موجودة. أضفها أولًا من «الولايات والمحليات»."))
            continue
        if len(lname) > 80 or len(cname) > 80:
            errors.append((n, "الاسم أطول من 80 حرفًا."))
            continue
        if not commit:
            continue
        now = utcnow()
        loc = db.one("SELECT * FROM localities WHERE governorate_id = ? AND name_ar = ?", (gov["id"], lname))
        if not loc:
            lid = db.insert("localities", {"governorate_id": gov["id"], "name_ar": lname,
                                           "name_en": _cell(row, idx, "الاسم الإنجليزي للمحلية") or None, "is_active": 1,
                                           "created_at": now})
            created["localities"] += 1
        else:
            lid = loc["id"]
        if cname:
            if db.one("SELECT id FROM cities WHERE locality_id = ? AND name_ar = ?", (lid, cname)):
                created["skipped"] += 1
            else:
                db.insert("cities", {"locality_id": lid, "name_ar": cname, "is_active": 1, "created_at": now})
                created["cities"] += 1
        elif loc:
            created["skipped"] += 1
    return errors, created


def _process_centers(header, rows, commit):
    db = get_db()
    idx = _index(header, TEMPLATES["centers"]["columns"])
    for col in ("اسم المركز", "الولاية", "المحلية"):
        if col not in idx:
            raise ValueError(f"العمود «{col}» غير موجود في الملف.")
    errors, created = [], {"centers": 0, "skipped": 0}
    govs = {r["name_ar"]: r for r in db.query("SELECT * FROM governorates")}
    seen = set()
    for n, row in enumerate(rows, start=2):
        name = _cell(row, idx, "اسم المركز")
        gov = govs.get(_cell(row, idx, "الولاية"))
        if not name or not gov:
            errors.append((n, "اسم المركز والولاية (بالاسم المسجل في المنصة) مطلوبان."))
            continue
        loc = db.one("SELECT * FROM localities WHERE governorate_id = ? AND name_ar = ?", (gov["id"], _cell(row, idx, "المحلية")))
        if not loc:
            errors.append((n, f"المحلية «{_cell(row, idx, 'المحلية')}» غير موجودة في {gov['name_ar']}. استورد المحليات أولًا."))
            continue
        if not _scope_ok_locality(loc["governorate_id"], loc["id"]):
            errors.append((n, "المحلية خارج نطاق صلاحياتك."))
            continue
        ctype = TYPE_BY_AR.get(_cell(row, idx, "النوع") or "مركز تبرع")
        if not ctype:
            errors.append((n, "النوع يجب أن يكون: " + "، ".join(CENTER_TYPES.values())))
            continue
        city = None
        if _cell(row, idx, "المدينة"):
            city = db.one("SELECT * FROM cities WHERE locality_id = ? AND name_ar = ?", (loc["id"], _cell(row, idx, "المدينة")))
            if not city and commit:
                cid = db.insert("cities", {"locality_id": loc["id"], "name_ar": _cell(row, idx, "المدينة"), "is_active": 1,
                                           "created_at": utcnow()})
                city = {"id": cid}
        f = Form({"phone": _cell(row, idx, "الهاتف"), "lat": _cell(row, idx, "خط العرض"), "lon": _cell(row, idx, "خط الطول"),
                  "name": name, "address": _cell(row, idx, "العنوان"), "hours": _cell(row, idx, "ساعات العمل"),
                  "services": _cell(row, idx, "الخدمات")})
        f.text("name", "اسم المركز", min_len=3, max_len=150)
        f.phone(required=False)
        f.decimal("lat", "خط العرض", min_value=-90, max_value=90)
        f.decimal("lon", "خط الطول", min_value=-180, max_value=180)
        f.text("address", "العنوان", required=False, max_len=255)
        f.text("hours", "ساعات العمل", required=False, max_len=120)
        f.text("services", "الخدمات", required=False, max_len=1000)
        if (f.clean.get("lat") is None) != (f.clean.get("lon") is None):
            f.error("lon", "أدخل خط العرض وخط الطول معًا.")
        if not f.ok:
            errors.append((n, " ".join(f.errors.values())))
            continue
        key = (loc["id"], name)
        if key in seen or db.one("SELECT id FROM blood_centers WHERE locality_id = ? AND name = ?", key):
            created["skipped"] += 1
            seen.add(key)
            continue
        seen.add(key)
        if not commit:
            continue
        now = utcnow()
        cid = db.insert("blood_centers", {
            "name": name, "center_type": ctype, "governorate_id": gov["id"], "locality_id": loc["id"],
            "city_id": city["id"] if city else None, "address": f.clean.get("address"), "phone": f.clean.get("phone"),
            "working_hours": f.clean.get("hours"), "latitude": f.clean.get("lat"), "longitude": f.clean.get("lon"),
            "services": f.clean.get("services"),
            "accepts_appointments": 1 if (_cell(row, idx, "يستقبل الحجوزات") or "نعم").lower() in YES else 0,
            "status": "active", "created_at": now, "updated_at": now})
        if ctype in ("blood_bank", "hospital_bank"):
            db.insert("blood_banks", {"center_id": cid, "is_active": 1, "has_component_separation": 0, "created_at": now})
        for wd in (5, 6, 0, 1, 2, 3):
            db.insert("center_schedules", {"center_id": cid, "weekday": wd, "start_time": "08:00", "end_time": "14:00",
                                           "slot_minutes": 30, "capacity_per_slot": 2})
        inventory.ensure_center_inventory(cid)
        created["centers"] += 1
    return errors, created


@bp.route("/import/<kind>", methods=["GET", "POST"])
@permission_required("geography.manage", "centers.manage")
def data_import(kind):
    meta = TEMPLATES.get(kind)
    if not meta:
        abort(404)
    if not g.user.can(meta["perm"]):
        abort(403)
    result = None
    if request.method == "POST":
        file = request.files.get("file")
        if not file or not file.filename:
            flash("اختر ملفًا للاستيراد.", "error")
            return redirect(request.path)
        try:
            header, rows = _read_rows(file)
            if len(rows) > 2000:
                raise ValueError("الحد الأقصى 2000 صف في الملف الواحد.")
            proc = _process_localities if kind == "localities" else _process_centers
            errors, _ = proc(header, rows, commit=False)
            if errors:
                result = {"errors": errors[:200], "total_errors": len(errors), "rows": len(rows)}
            else:
                db = get_db()
                with db.transaction():
                    _, created = proc(header, rows, commit=True)
                audit.log("geo_create" if kind == "localities" else "center_create", "center" if kind == "centers" else "locality",
                          None, {"استيراد": meta["title"], "الصفوف": len(rows), **created})
                result = {"created": created, "rows": len(rows)}
                flash("تم الاستيراد بنجاح.", "success")
        except ValueError as e:
            flash(str(e), "error")
        except Exception:
            flash("تعذر قراءة الملف. تأكد أنه ملف Excel أو CSV سليم ومطابق للنموذج.", "error")
    return render_template("admin/import.html", kind=kind, meta=meta, result=result)


@bp.route("/import/<kind>/template.xlsx")
@permission_required("geography.manage", "centers.manage")
def import_template(kind):
    meta = TEMPLATES.get(kind)
    if not meta:
        abort(404)
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "البيانات"
    ws.sheet_view.rightToLeft = True
    ws.append(meta["columns"])
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="0D47A1")
    ws.append(meta["example"])
    for i in range(1, len(meta["columns"]) + 1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = 24
    if kind == "centers":
        info = wb.create_sheet("تعليمات")
        info.sheet_view.rightToLeft = True
        info.append(["القيم المسموحة لعمود «النوع»:"])
        for v in CENTER_TYPES.values():
            info.append([v])
        info.append(["«يستقبل الحجوزات»: نعم أو لا"])
        info.append(["الولاية والمحلية يجب أن تكونا مسجلتين في المنصة بنفس الكتابة."])
    buf = io.BytesIO()
    wb.save(buf)
    return Response(buf.getvalue(), mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": f"attachment; filename=qatrat-{kind}-template.xlsx"})
