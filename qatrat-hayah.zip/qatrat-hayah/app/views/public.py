"""الصفحات العامة: الرئيسية، المراكز، النداءات العاجلة، التوعية، عن المنصة."""
import math

from flask import Blueprint, abort, jsonify, render_template, request

from ..db import get_db, paginate
from ..schema import BLOOD_TYPES
from ..services import stats
from ..services.appointments import open_days
from ..services.inventory import stock_status

bp = Blueprint("public", __name__)


def active_governorates():
    return get_db().query("SELECT id, name_ar FROM governorates WHERE is_active = 1 ORDER BY name_ar")


def open_appeals(limit=None, governorate_id=None):
    db = get_db()
    sql = """SELECT e.*, c.name AS center_name, g.name_ar AS governorate FROM emergency_appeals e
             JOIN blood_centers c ON c.id = e.center_id JOIN governorates g ON g.id = c.governorate_id
             WHERE e.status = 'open'"""
    params = []
    if governorate_id:
        sql += " AND c.governorate_id = ?"
        params.append(governorate_id)
    sql += """ ORDER BY CASE e.urgency WHEN 'critical' THEN 0 WHEN 'urgent' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
               e.published_at DESC"""
    if limit:
        sql += f" LIMIT {int(limit)}"
    return db.query(sql, params)


@bp.route("/")
def home():
    db = get_db()
    centers = db.query(
        """SELECT c.*, l.name_ar AS locality FROM blood_centers c JOIN localities l ON l.id = c.locality_id
           WHERE c.status = 'active' ORDER BY c.center_type = 'blood_bank' DESC, c.name LIMIT 4""")
    articles = db.query("SELECT * FROM educational_content WHERE is_published = 1 ORDER BY published_at DESC LIMIT 3")
    return render_template("public/home.html", appeals=open_appeals(limit=3), summary=stats.public_summary(),
                           centers=centers, articles=articles)


def _haversine(lat1, lon1, lat2, lon2):
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def _float_arg(name, lo, hi):
    try:
        v = float(request.args.get(name, ""))
        return v if lo <= v <= hi else None
    except ValueError:
        return None


@bp.route("/centers")
def centers():
    db = get_db()
    where, params = ["c.status = 'active'", "g.is_active = 1"], []
    gov = request.args.get("governorate_id", type=int)
    loc = request.args.get("locality_id", type=int)
    ctype = request.args.get("type", "")
    q = (request.args.get("q") or "").strip()[:60]
    if gov:
        where.append("c.governorate_id = ?"); params.append(gov)
    if loc:
        where.append("c.locality_id = ?"); params.append(loc)
    if ctype in ("donation_center", "blood_bank", "hospital_bank", "mobile_unit"):
        where.append("c.center_type = ?"); params.append(ctype)
    if q:
        where.append(f"(c.name {db.like()} ? OR c.address {db.like()} ? OR ci.name_ar {db.like()} ?)")
        params += [f"%{q}%"] * 3
    rows = db.query(
        f"""SELECT c.*, g.name_ar AS governorate, l.name_ar AS locality, ci.name_ar AS city
            FROM blood_centers c JOIN governorates g ON g.id = c.governorate_id JOIN localities l ON l.id = c.locality_id
            LEFT JOIN cities ci ON ci.id = c.city_id WHERE {' AND '.join(where)} ORDER BY g.name_ar, l.name_ar, c.name""",
        params)
    lat, lon = _float_arg("lat", -90, 90), _float_arg("lon", -180, 180)
    if lat is not None and lon is not None:
        for r in rows:
            r["distance"] = (_haversine(lat, lon, float(r["latitude"]), float(r["longitude"]))
                             if r["latitude"] is not None and r["longitude"] is not None else None)
        rows.sort(key=lambda r: (r["distance"] is None, r["distance"] or 0))
    localities = db.query("SELECT id, name_ar FROM localities WHERE governorate_id = ? AND is_active = 1 ORDER BY name_ar",
                          (gov,)) if gov else []
    return render_template("public/centers.html", centers=rows, governorates=active_governorates(),
                           localities=localities, near=lat is not None)


@bp.route("/centers/<int:center_id>")
def center_detail(center_id):
    db = get_db()
    c = db.one(
        """SELECT c.*, g.name_ar AS governorate, l.name_ar AS locality, ci.name_ar AS city FROM blood_centers c
           JOIN governorates g ON g.id = c.governorate_id JOIN localities l ON l.id = c.locality_id
           LEFT JOIN cities ci ON ci.id = c.city_id WHERE c.id = ? AND c.status = 'active'""", (center_id,))
    if not c:
        abort(404)
    inv = {r["blood_type"]: stock_status(r) for r in db.query("SELECT * FROM blood_inventory WHERE center_id = ?", (center_id,))}
    schedule = db.query("SELECT * FROM center_schedules WHERE center_id = ? ORDER BY weekday", (center_id,))
    return render_template("public/center_detail.html", c=c, inv=inv, schedule=schedule,
                           appeals=[a for a in open_appeals() if a["center_id"] == center_id], days=open_days(center_id, 7))


@bp.route("/appeals")
def appeals():
    gov = request.args.get("governorate_id", type=int)
    return render_template("public/appeals.html", appeals=open_appeals(governorate_id=gov),
                           governorates=active_governorates())


@bp.route("/appeals/<int:appeal_id>")
def appeal_detail(appeal_id):
    a = next((x for x in open_appeals() if x["id"] == appeal_id), None)
    if not a:
        db = get_db()
        closed = db.one("SELECT id, title, status FROM emergency_appeals WHERE id = ? AND status IN ('completed','closed')",
                        (appeal_id,))
        if not closed:
            abort(404)
        return render_template("public/appeal_detail.html", a=None, closed=closed)
    return render_template("public/appeal_detail.html", a=a, closed=None)


@bp.route("/how-to-donate")
def how_to_donate():
    return render_template("public/how_to_donate.html")


@bp.route("/awareness")
def awareness():
    db = get_db()
    cat = request.args.get("category")
    where, params = ["is_published = 1"], []
    if cat:
        where.append("category = ?"); params.append(cat)
    page = paginate(db, f"SELECT * FROM educational_content WHERE {' AND '.join(where)} ORDER BY published_at DESC",
                    params, request.args.get("page", 1, type=int), 12)
    return render_template("public/awareness.html", page=page, cat=cat)


@bp.route("/awareness/<slug>")
def article(slug):
    a = get_db().one("SELECT * FROM educational_content WHERE slug = ? AND is_published = 1", (slug,))
    if not a:
        abort(404)
    return render_template("public/article.html", a=a)


@bp.route("/about")
def about():
    return render_template("public/about.html", summary=stats.public_summary())


@bp.route("/privacy")
def privacy():
    return render_template("public/privacy.html")


# ---------- بيانات القوائم المترابطة (ولاية ← محلية ← مدينة/مركز) ----------
@bp.route("/geo/localities.json")
def localities_json():
    gov = request.args.get("governorate_id", type=int)
    rows = get_db().query("SELECT id, name_ar AS name FROM localities WHERE governorate_id = ? AND is_active = 1 ORDER BY name_ar",
                          (gov or 0,))
    return jsonify(rows)


@bp.route("/geo/cities.json")
def cities_json():
    loc = request.args.get("locality_id", type=int)
    rows = get_db().query("SELECT id, name_ar AS name FROM cities WHERE locality_id = ? AND is_active = 1 ORDER BY name_ar",
                          (loc or 0,))
    return jsonify(rows)


@bp.route("/geo/centers.json")
def centers_json():
    db = get_db()
    loc = request.args.get("locality_id", type=int)
    gov = request.args.get("governorate_id", type=int)
    booking = request.args.get("booking") == "1"
    where, params = ["status = 'active'"], []
    if loc:
        where.append("locality_id = ?"); params.append(loc)
    elif gov:
        where.append("governorate_id = ?"); params.append(gov)
    else:
        return jsonify([])
    if booking:
        where.append("accepts_appointments = 1")
    return jsonify(db.query(f"SELECT id, name FROM blood_centers WHERE {' AND '.join(where)} ORDER BY name", params))


@bp.route("/health")
def health():
    get_db().scalar("SELECT 1 AS ok")
    return jsonify(status="ok")


@bp.app_context_processor
def _bt():
    return {"ALL_BLOOD_TYPES": BLOOD_TYPES}


@bp.app_context_processor
def _geo_helpers():
    def geo_lists(gov_id=None, loc_id=None, booking=False, all_govs=False):
        """قوائم المحليات والمدن والمراكز للنماذج (تعمل بدون JavaScript)."""
        db = get_db()
        try:
            gov_id = int(gov_id) if gov_id not in (None, "") else None
            loc_id = int(loc_id) if loc_id not in (None, "") else None
        except (TypeError, ValueError):
            gov_id = loc_id = None
        govs = active_governorates() if not all_govs else db.query("SELECT id, name_ar FROM governorates ORDER BY name_ar")
        if gov_id is None and len(govs) == 1:
            gov_id = govs[0]["id"]
        locs = db.query("SELECT id, name_ar FROM localities WHERE governorate_id = ? AND is_active = 1 ORDER BY name_ar",
                        (gov_id or 0,))
        cities = db.query("SELECT id, name_ar FROM cities WHERE locality_id = ? AND is_active = 1 ORDER BY name_ar", (loc_id or 0,))
        cw, cp = ["status = 'active'", "governorate_id = ?"], [gov_id or 0]
        if loc_id:
            cw.append("locality_id = ?"); cp.append(loc_id)
        if booking:
            cw.append("accepts_appointments = 1")
        centers = db.query(f"SELECT id, name FROM blood_centers WHERE {' AND '.join(cw)} ORDER BY name", cp)
        return {"govs": govs, "gov_id": gov_id, "locs": locs, "cities": cities, "centers": centers}
    return {"geo_lists": geo_lists}


# ---------------- تطبيق الهاتف القابل للتثبيت (PWA) ----------------
@bp.route("/sw.js")
def service_worker():
    from flask import current_app, send_from_directory
    resp = send_from_directory(current_app.static_folder + "/js", "sw.js", mimetype="application/javascript")
    resp.headers["Service-Worker-Allowed"] = "/"
    resp.headers["Cache-Control"] = "no-cache"
    return resp


@bp.route("/manifest.webmanifest")
def manifest():
    from flask import current_app, send_from_directory
    return send_from_directory(current_app.static_folder, "manifest.webmanifest", mimetype="application/manifest+json")


@bp.route("/offline")
def offline():
    return render_template("public/offline.html")


@bp.route("/robots.txt")
def robots():
    from flask import Response
    return Response("User-agent: *\nDisallow: /admin/\nDisallow: /donor/\nDisallow: /api/\nAllow: /\n", mimetype="text/plain")


# ---------------- الاستضافة المجانية: إبقاء الخدمة نشطة وتشغيل المهام الدورية ----------------
@bp.route("/ping")
def ping():
    """استجابة خفيفة بدون قاعدة بيانات؛ تستخدمها خدمة cron خارجية لإبقاء الموقع مستيقظًا."""
    return jsonify(ok=True)


@bp.route("/tasks/run", methods=["GET", "POST"])
def run_tasks():
    """تشغيل المهام الدورية عبر رابط محمي برمز QH_TASKS_TOKEN (بديل cron في الاستضافة المجانية)."""
    import hmac
    from flask import current_app
    token = current_app.config.get("TASKS_TOKEN") or ""
    sent = request.headers.get("X-Task-Token") or request.args.get("token") or ""
    if not token or not hmac.compare_digest(sent, token):
        abort(404)
    from ..notifications import process_outbox
    from ..services.appointments import send_reminders
    from ..services.requests_appeals import expire_appeals
    import time
    db = get_db()
    db.execute("DELETE FROM rate_limits WHERE window_start < ?", (int(time.time()) - 86400,))
    return jsonify(reminders=send_reminders(), outbox=process_outbox(), expired_appeals=expire_appeals())


# ---------------- تنزيل التطبيق ----------------
@bp.route("/app")
def app_download_page():
    from ..services import app_release
    from flask import current_app
    return render_template("public/app.html", release=app_release.current(),
                           site=current_app.config.get("SITE_URL") or request.host_url.rstrip("/"))


@bp.route("/app/qatrat-hayah.apk")
def app_apk():
    from flask import send_file
    from ..services import app_release
    if not app_release.current():
        abort(404)
    resp = send_file(app_release.apk_path(), mimetype="application/vnd.android.package-archive",
                     as_attachment=True, download_name="qatrat-hayah.apk", max_age=300)
    return resp


@bp.route("/.well-known/assetlinks.json")
def assetlinks():
    """ربط تطبيق أندرويد بالموقع (يُخفي شريط العنوان داخل التطبيق)."""
    import json as _json
    from flask import Response
    from ..services.common import get_setting
    raw = (get_setting("android_assetlinks") or "").strip()
    try:
        data = _json.loads(raw) if raw else []
    except ValueError:
        data = []
    return Response(_json.dumps(data), mimetype="application/json")
