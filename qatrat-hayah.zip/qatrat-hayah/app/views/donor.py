"""واجهة المتبرع: لوحة المتبرع، الملف، المواعيد، سجل التبرعات، الإشعارات، الإعدادات."""
from datetime import timedelta

from flask import Blueprint, abort, flash, g, jsonify, redirect, render_template, request, url_for

from .. import audit
from ..db import get_db, paginate, utcnow
from ..security import donor_required, hash_password, login_required, verify_password
from ..services import appointments as appt_svc
from ..services.common import get_int_setting
from ..timeutil import local_today
from ..validators import Form
from .auth import create_donor_record, validate_donor_fields
from .public import active_governorates, open_appeals

bp = Blueprint("donor", __name__, url_prefix="/donor")


def _donor():
    return g.user.donor


def _donor_full():
    return get_db().one(
        """SELECT d.*, p.gender, p.birth_year, p.notify_in_app, p.notify_sms, p.notify_emergency, p.notify_reminders,
           g.name_ar AS governorate, l.name_ar AS locality, c.name AS preferred_center
           FROM donors d LEFT JOIN donor_profiles p ON p.donor_id = d.id
           JOIN governorates g ON g.id = d.governorate_id JOIN localities l ON l.id = d.locality_id
           LEFT JOIN blood_centers c ON c.id = d.preferred_center_id WHERE d.id = ?""", (_donor()["id"],))


def _my_appt(appt_id):
    a = get_db().one(
        """SELECT a.*, c.name AS center_name, c.address AS center_address, c.phone AS center_phone
           FROM appointments a JOIN blood_centers c ON c.id = a.center_id WHERE a.id = ? AND a.donor_id = ?""",
        (appt_id, _donor()["id"]))
    if not a:
        abort(404)
    return a


@bp.route("/")
@donor_required
def dashboard():
    db = get_db()
    d = _donor_full()
    upcoming = db.one(
        """SELECT a.*, c.name AS center_name FROM appointments a JOIN blood_centers c ON c.id = a.center_id
           WHERE a.donor_id = ? AND a.status IN ('booked','confirmed','checked_in') AND a.appointment_date >= ?
           ORDER BY a.appointment_date, a.appointment_time LIMIT 1""", (d["id"], local_today().isoformat()))
    notes = db.query("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 5", (g.user.id,))
    appeals = [a for a in open_appeals(governorate_id=d["governorate_id"]) if not d["blood_type"] or a["blood_type"] == d["blood_type"]][:3]
    return render_template("donor/dashboard.html", d=d, upcoming=upcoming, notes=notes, appeals=appeals)


@bp.route("/complete-profile", methods=["GET", "POST"])
@login_required
def complete_profile():
    db = get_db()
    if g.user.donor:
        return redirect(url_for("donor.dashboard"))
    form = Form(request.form)
    if request.method == "POST":
        validate_donor_fields(form, db)
        if form.ok:
            with db.transaction():
                did = create_donor_record(db, g.user.id, form)
                if not db.one("SELECT ur.id FROM user_roles ur JOIN roles r ON r.id = ur.role_id WHERE ur.user_id = ? AND r.code = 'donor'",
                              (g.user.id,)):
                    db.insert("user_roles", {"user_id": g.user.id, "role_id": db.scalar("SELECT id FROM roles WHERE code='donor'"),
                                             "created_at": utcnow()})
            audit.log("donor_update", "donor", did, {"إجراء": "إنشاء ملف متبرع"})
            flash("تم إنشاء ملف المتبرع.", "success")
            return redirect(url_for("donor.dashboard"))
    return render_template("donor/profile_form.html", form=form, governorates=active_governorates(), d=None, creating=True)


@bp.route("/profile", methods=["GET", "POST"])
@donor_required
def profile():
    db = get_db()
    d = _donor_full()
    if request.method == "POST":
        form = Form(request.form)
        form.text("full_name", "الاسم الكامل", min_len=5, max_len=120)
        form.email()
        validate_donor_fields(form, db)
        if form.ok and form.clean.get("email") and db.one("SELECT id FROM users WHERE email = ? AND id != ?",
                                                           (form.clean["email"], g.user.id)):
            form.error("email", "هذا البريد مستخدم مسبقًا.")
        if form.ok:
            # لا يمكن للمتبرع تغيير الفصيلة بعد إثباتها مخبريًا
            bt = d["blood_type"] if d["blood_type_verified"] else form.clean.get("blood_type")
            new = {"blood_type": bt, "governorate_id": form.clean["governorate_id"], "locality_id": form.clean["locality_id"],
                   "preferred_center_id": form.clean.get("preferred_center_id")}
            changes = audit.diff(d, new, list(new))
            with db.transaction():
                db.update("users", g.user.id, {"full_name": form.clean["full_name"], "email": form.clean.get("email"),
                                               "updated_at": utcnow()})
                db.update("donors", d["id"], {**new, "updated_at": utcnow()})
                db.execute("UPDATE donor_profiles SET gender = ?, birth_year = ?, updated_at = ? WHERE donor_id = ?",
                           (form.clean.get("gender"), form.clean.get("birth_year"), utcnow(), d["id"]))
            audit.log("donor_update", "donor", d["id"], changes)
            flash("تم حفظ التعديلات.", "success")
            return redirect(url_for("donor.profile"))
    else:
        form = Form({**d, "full_name": g.user.name, "email": g.user.row["email"] or "",
                     "blood_type": d["blood_type"] or "unknown"})
    return render_template("donor/profile_form.html", form=form, governorates=active_governorates(), d=d, creating=False)


# ---------------- المواعيد ----------------
@bp.route("/appointments")
@donor_required
def appointments():
    db = get_db()
    rows = db.query(
        """SELECT a.*, c.name AS center_name FROM appointments a JOIN blood_centers c ON c.id = a.center_id
           WHERE a.donor_id = ? ORDER BY a.appointment_date DESC, a.appointment_time DESC LIMIT 100""", (_donor()["id"],))
    today = local_today().isoformat()
    upcoming = [r for r in rows if r["status"] in ("booked", "confirmed", "checked_in") and str(r["appointment_date"]) >= today]
    past = [r for r in rows if r not in upcoming]
    return render_template("donor/appointments.html", upcoming=list(reversed(upcoming)), past=past)


def _booking_form(appt=None):
    """نموذج الحجز/التعديل: المركز ← التاريخ ← الوقت ← التأكيد."""
    db = get_db()
    d = _donor()
    center_id = request.values.get("center_id", type=int) or (appt["center_id"] if appt else d["preferred_center_id"])
    center = db.one("SELECT c.*, l.name_ar AS locality FROM blood_centers c JOIN localities l ON l.id = c.locality_id "
                    "WHERE c.id = ? AND c.status = 'active' AND c.accepts_appointments = 1", (center_id or 0,))
    today = local_today()
    window = get_int_setting("booking_window_days", 60)
    day = request.values.get("date") or ""
    slots = []
    errors = {}
    if center and day:
        f = Form({"date": day})
        f.date("date", "التاريخ", min_date=today, max_date=today + timedelta(days=window))
        if f.ok:
            slots = appt_svc.available_slots(center["id"], day, appt["id"] if appt else None)
            if not slots:
                errors["date"] = "لا توجد أوقات متاحة في هذا اليوم. جرّب يومًا آخر."
        else:
            errors.update(f.errors)
            day = ""
    centers = db.query(
        """SELECT c.id, c.name, l.name_ar AS locality FROM blood_centers c JOIN localities l ON l.id = c.locality_id
           WHERE c.status = 'active' AND c.accepts_appointments = 1 AND c.governorate_id = ? ORDER BY c.name""",
        (d["governorate_id"],))
    return {"center": center, "centers": centers, "day": day, "slots": slots, "errors": errors,
            "open_days": appt_svc.open_days(center["id"], 14) if center else [],
            "min_date": today.isoformat(), "max_date": (today + timedelta(days=window)).isoformat()}


@bp.route("/appointments/new", methods=["GET", "POST"])
@donor_required
def book():
    ctx = _booking_form()
    if request.method == "POST" and request.form.get("time"):
        f = Form(request.form)
        f.time("time", "الوقت")
        notes = f.text("notes", "ملاحظات", required=False, max_len=300)
        if not request.form.get("ack"):
            f.error("ack", "يرجى تأكيد الاطلاع على التنبيه قبل الحجز.")
        if f.ok and ctx["center"] and ctx["day"]:
            try:
                aid = appt_svc.book(_donor(), ctx["center"]["id"], ctx["day"], f.clean["time"], notes)
                audit.log("appointment_create", "appointment", aid, {"center_id": ctx["center"]["id"], "date": ctx["day"]})
                flash("تم حجز موعدك بنجاح، وتم إشعار المركز.", "success")
                return redirect(url_for("donor.appointment_detail", appt_id=aid))
            except appt_svc.BookingError as e:
                ctx["errors"]["time"] = str(e)
        else:
            ctx["errors"].update(f.errors)
    return render_template("donor/book.html", mode="new", appt=None, **ctx)


@bp.route("/appointments/<int:appt_id>")
@donor_required
def appointment_detail(appt_id):
    return render_template("donor/appointment_detail.html", a=_my_appt(appt_id))


@bp.route("/appointments/<int:appt_id>/edit", methods=["GET", "POST"])
@donor_required
def reschedule(appt_id):
    a = _my_appt(appt_id)
    if a["status"] not in appt_svc.ACTIVE:
        flash("لا يمكن تعديل هذا الموعد.", "error")
        return redirect(url_for("donor.appointment_detail", appt_id=appt_id))
    ctx = _booking_form(a)
    if request.method == "POST" and request.form.get("time"):
        f = Form(request.form)
        f.time("time", "الوقت")
        if f.ok and ctx["center"] and ctx["day"]:
            try:
                appt_svc.reschedule(a, ctx["center"]["id"], ctx["day"], f.clean["time"])
                audit.log("appointment_update", "appointment", a["id"],
                          {"من": f"{a['appointment_date']} {str(a['appointment_time'])[:5]}", "إلى": f"{ctx['day']} {f.clean['time']}"})
                flash("تم تعديل موعدك.", "success")
                return redirect(url_for("donor.appointment_detail", appt_id=a["id"]))
            except appt_svc.BookingError as e:
                ctx["errors"]["time"] = str(e)
        else:
            ctx["errors"].update(f.errors)
    return render_template("donor/book.html", mode="edit", appt=a, **ctx)


@bp.route("/appointments/<int:appt_id>/cancel", methods=["POST"])
@donor_required
def cancel(appt_id):
    a = _my_appt(appt_id)
    reason = (request.form.get("reason") or "").strip()[:200] or "ألغاه المتبرع"
    try:
        appt_svc.cancel(a, reason, by_donor=True)
        audit.log("appointment_cancel", "appointment", a["id"], {"السبب": reason})
        flash("تم إلغاء الموعد.", "success")
    except appt_svc.BookingError as e:
        flash(str(e), "error")
    return redirect(url_for("donor.appointment_detail", appt_id=a["id"]))


@bp.route("/slots.json")
@donor_required
def slots_json():
    center_id = request.args.get("center_id", type=int)
    day = request.args.get("date", "")
    f = Form({"date": day})
    f.date("date", "التاريخ")
    if not center_id or not f.ok:
        return jsonify([])
    return jsonify(appt_svc.available_slots(center_id, day, request.args.get("exclude", type=int)))


# ---------------- سجل التبرعات ----------------
@bp.route("/donations")
@donor_required
def donations():
    rows = get_db().query(
        """SELECT x.id, x.donated_at, x.blood_type, x.volume_ml, x.status, c.name AS center_name
           FROM donations x JOIN blood_centers c ON c.id = x.center_id WHERE x.donor_id = ? ORDER BY x.donated_at DESC""",
        (_donor()["id"],))
    return render_template("donor/donations.html", rows=rows, d=_donor_full())


# ---------------- الإشعارات ----------------
@bp.route("/notifications")
@login_required
def notifications():
    db = get_db()
    page = paginate(db, "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC", [g.user.id],
                    request.args.get("page", 1, type=int), 20)
    return render_template("donor/notifications.html", page=page)


@bp.route("/notifications/read", methods=["POST"])
@login_required
def notifications_read():
    db = get_db()
    nid = request.form.get("id", type=int)
    if nid:
        n = db.one("SELECT * FROM notifications WHERE id = ? AND user_id = ?", (nid, g.user.id))
        if not n:
            abort(404)
        db.execute("UPDATE notifications SET is_read = 1, read_at = ? WHERE id = ?", (utcnow(), nid))
        link = n["link"]
        if link and link.startswith("/") and not link.startswith("//"):
            return redirect(link)
    else:
        db.execute("UPDATE notifications SET is_read = 1, read_at = ? WHERE user_id = ? AND is_read = 0", (utcnow(), g.user.id))
        flash("تم تعليم كل الإشعارات كمقروءة.", "success")
    return redirect(url_for("donor.notifications"))


# ---------------- الإعدادات ----------------
@bp.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    db = get_db()
    d = g.user.donor
    prefs = db.one("SELECT * FROM donor_profiles WHERE donor_id = ?", (d["id"],)) if d else None
    pw_form = Form({})
    if request.method == "POST":
        action = request.form.get("action")
        if action == "prefs" and prefs:
            f = Form(request.form)
            data = {k: f.boolean(k) for k in ("notify_in_app", "notify_sms", "notify_emergency", "notify_reminders")}
            db.execute("UPDATE donor_profiles SET notify_in_app = ?, notify_sms = ?, notify_emergency = ?, notify_reminders = ?, "
                       "updated_at = ? WHERE id = ?", (*data.values(), utcnow(), prefs["id"]))
            audit.log("donor_update", "donor", d["id"], {"تفضيلات الإشعارات": data})
            flash("تم حفظ تفضيلات الإشعارات.", "success")
            return redirect(url_for("donor.settings"))
        if action == "password":
            pw_form = Form(request.form)
            if not verify_password(g.user.row["password_hash"], request.form.get("current_password") or ""):
                pw_form.error("current_password", "كلمة المرور الحالية غير صحيحة.")
            pw_form.password("new_password", confirm="new_password_confirm")
            if pw_form.ok:
                db.execute("UPDATE users SET password_hash = ?, auth_version = auth_version + 1, updated_at = ? WHERE id = ?",
                           (hash_password(pw_form.clean["new_password"]), utcnow(), g.user.id))
                audit.log("password_change", "user", g.user.id)
                from ..security import login_session
                login_session(db.get("users", g.user.id))
                flash("تم تغيير كلمة المرور. تم إنهاء الجلسات الأخرى.", "success")
                return redirect(url_for("donor.settings"))
    return render_template("donor/settings.html", prefs=prefs, pw_form=pw_form)


# ---------------- بطاقة المتبرع وشهادة الشكر ----------------
@bp.route("/card")
@donor_required
def card():
    return render_template("donor/card.html", d=_donor_full())


@bp.route("/certificate")
@donor_required
def certificate():
    from flask import Response
    from ..services.reports import embedded_font_css, html_to_pdf
    d = _donor_full()
    if not d["donations_count"]:
        flash("تصدر شهادة الشكر بعد اعتماد أول تبرع لك.", "info")
        return redirect(url_for("donor.donations"))
    if request.args.get("format") == "pdf":
        import base64
        from flask import current_app
        with open(current_app.static_folder + "/img/logo.svg", "rb") as fh:
            logo_uri = "data:image/svg+xml;base64," + base64.b64encode(fh.read()).decode()
        pdf = html_to_pdf(render_template("donor/certificate.html", d=d, font_css=embedded_font_css(), pdf=True,
                                          logo_uri=logo_uri), landscape=True)
        if pdf:
            return Response(pdf, mimetype="application/pdf",
                            headers={"Content-Disposition": f"attachment; filename=qatrat-certificate-{d['donor_code']}.pdf"})
    return render_template("donor/certificate.html", d=d, font_css=None, pdf=False)
