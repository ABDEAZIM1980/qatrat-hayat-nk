"""الواجهة البرمجية REST API v1 — لتطبيق الهاتف المستقبلي والتكامل مع الأنظمة الأخرى.

المصادقة: Authorization: Bearer <token> (JWT) تُحصل عليه من /api/v1/auth/login.
"""
from flask import Blueprint, abort, current_app, g, jsonify, request

from .. import audit
from ..db import get_db, paginate, utcnow
from ..rbac import center_filter
from ..security import (api_auth_required, client_ip, dummy_verify, hash_password, is_locked, issue_token,
                        rate_limited, register_login_failure, verify_password)
from ..services import appointments as appt_svc
from ..services import requests_appeals as ra
from ..services import stats
from ..services.common import label
from ..services.inventory import stock_status
from ..validators import URGENCY, Form, display_phone
from .auth import create_donor_record, validate_donor_fields
from .public import open_appeals

bp = Blueprint("api", __name__, url_prefix="/api/v1")


def body():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        data = {}
    return {k: (str(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else v) for k, v in data.items()}


def bad(form):
    return jsonify(error="validation_error", message="البيانات المدخلة غير صحيحة", fields=form.errors), 422


def _user_json(u):
    d = u.donor
    return {"id": u.id, "name": u.name, "phone": display_phone(u.phone), "roles": u.scope.roles, "is_staff": u.is_staff,
            "donor": {"code": d["donor_code"], "blood_type": d["blood_type"], "blood_type_verified": bool(d["blood_type_verified"]),
                      "donations_count": d["donations_count"], "last_donation_at": d["last_donation_at"]} if d else None}


# ---------------- المصادقة ----------------
@bp.route("/auth/login", methods=["POST"])
def login():
    cfg = current_app.config
    if rate_limited(f"api-login:{client_ip()}", cfg["LOGIN_MAX_ATTEMPTS"] * 4, cfg["LOGIN_WINDOW_SECONDS"]):
        return jsonify(error="rate_limited", message="محاولات كثيرة. حاول لاحقًا."), 429
    data = body()
    f = Form(data)
    f.phone()
    db = get_db()
    user = db.one("SELECT * FROM users WHERE phone = ?", (f.clean.get("phone"),)) if f.clean.get("phone") else None
    pw = data.get("password") or ""
    if not user:
        dummy_verify(pw)
        return jsonify(error="invalid_credentials", message="رقم الهاتف أو كلمة المرور غير صحيحة."), 401
    if is_locked(user):
        return jsonify(error="locked", message="تم إيقاف الدخول مؤقتًا بسبب محاولات متكررة."), 423
    if not verify_password(user["password_hash"], pw):
        register_login_failure(db, user)
        audit.log("login_failed", "user", user["id"], {"قناة": "API"}, user=user)
        return jsonify(error="invalid_credentials", message="رقم الهاتف أو كلمة المرور غير صحيحة."), 401
    if user["status"] != "active":
        return jsonify(error="inactive", message="الحساب غير مفعّل."), 403
    db.update("users", user["id"], {"failed_logins": 0, "locked_until": None, "last_login_at": utcnow()})
    audit.log("login", "user", user["id"], {"قناة": "API"}, user=user)
    return jsonify(token=issue_token(user), token_type="Bearer", expires_in=cfg["JWT_TTL_MINUTES"] * 60)


@bp.route("/auth/register", methods=["POST"])
def register():
    if rate_limited(f"api-register:{client_ip()}", 10, 3600):
        return jsonify(error="rate_limited", message="محاولات كثيرة. حاول لاحقًا."), 429
    db = get_db()
    data = body()
    f = Form(data)
    f.text("full_name", "الاسم الكامل", min_len=5, max_len=120)
    f.phone()
    f.password()
    validate_donor_fields(f, db)
    if not data.get("consent"):
        f.error("consent", "يجب الموافقة على سياسة الخصوصية.")
    if f.ok and db.one("SELECT id FROM users WHERE phone = ?", (f.clean["phone"],)):
        f.error("phone", "هذا الرقم مسجل مسبقًا.")
    if not f.ok:
        return bad(f)
    with db.transaction():
        now = utcnow()
        uid = db.insert("users", {"full_name": f.clean["full_name"], "phone": f.clean["phone"],
                                  "password_hash": hash_password(f.clean["password"]), "status": "active", "is_staff": 0,
                                  "created_at": now, "updated_at": now})
        db.insert("user_roles", {"user_id": uid, "role_id": db.scalar("SELECT id FROM roles WHERE code='donor'"), "created_at": now})
        create_donor_record(db, uid, f)
    user = db.get("users", uid)
    audit.log("register", "user", uid, {"قناة": "API"}, user=user)
    return jsonify(token=issue_token(user), token_type="Bearer"), 201


@bp.route("/me")
@api_auth_required()
def me():
    return jsonify(_user_json(g.user))


# ---------------- بيانات عامة ----------------
@bp.route("/governorates")
def governorates():
    return jsonify(get_db().query("SELECT id, name_ar, name_en FROM governorates WHERE is_active = 1 ORDER BY name_ar"))


@bp.route("/localities")
def localities():
    gov = request.args.get("governorate_id", type=int)
    return jsonify(get_db().query("SELECT id, name_ar, name_en FROM localities WHERE governorate_id = ? AND is_active = 1 ORDER BY name_ar",
                                  (gov or 0,)))


@bp.route("/centers")
def centers():
    db = get_db()
    where, params = ["c.status = 'active'"], []
    for k in ("governorate_id", "locality_id"):
        v = request.args.get(k, type=int)
        if v:
            where.append(f"c.{k} = ?"); params.append(v)
    q = (request.args.get("q") or "").strip()[:60]
    if q:
        where.append(f"c.name {db.like()} ?"); params.append(f"%{q}%")
    rows = db.query(f"""SELECT c.id, c.name, c.center_type, c.address, c.phone, c.working_hours, c.latitude, c.longitude,
        c.accepts_appointments, g.name_ar AS governorate, l.name_ar AS locality FROM blood_centers c
        JOIN governorates g ON g.id = c.governorate_id JOIN localities l ON l.id = c.locality_id
        WHERE {' AND '.join(where)} ORDER BY c.name""", params)
    for r in rows:
        r["phone"] = display_phone(r["phone"])
        for k in ("latitude", "longitude"):
            r[k] = float(r[k]) if r[k] is not None else None
    return jsonify(rows)


@bp.route("/centers/<int:center_id>")
def center(center_id):
    db = get_db()
    c = db.one("SELECT id, name, center_type, address, phone, working_hours, services, latitude, longitude, accepts_appointments "
               "FROM blood_centers WHERE id = ? AND status = 'active'", (center_id,))
    if not c:
        abort(404)
    c["phone"] = display_phone(c["phone"])
    for k in ("latitude", "longitude"):
        c[k] = float(c[k]) if c[k] is not None else None
    c["blood_availability"] = {r["blood_type"]: label("inventory", stock_status(r))
                               for r in db.query("SELECT * FROM blood_inventory WHERE center_id = ?", (center_id,))}
    c["open_days"] = appt_svc.open_days(center_id, 14)
    return jsonify(c)


@bp.route("/centers/<int:center_id>/slots")
def slots(center_id):
    f = Form(request.args)
    f.date("date", "التاريخ")
    if not f.ok:
        return bad(f)
    return jsonify(appt_svc.available_slots(center_id, f.clean["date"]))


@bp.route("/appeals")
def appeals():
    rows = open_appeals(governorate_id=request.args.get("governorate_id", type=int))
    return jsonify([{"id": a["id"], "title": a["title"], "blood_type": a["blood_type"], "units_needed": a["units_needed"],
                     "units_collected": a["units_collected"], "urgency": a["urgency"], "urgency_label": URGENCY[a["urgency"]],
                     "center_id": a["center_id"], "center": a["center_name"], "governorate": a["governorate"],
                     "message": a["message"], "published_at": a["published_at"]} for a in rows])


@bp.route("/content")
def content():
    return jsonify(get_db().query("SELECT id, title, slug, category, summary, body, published_at FROM educational_content "
                                  "WHERE is_published = 1 ORDER BY published_at DESC LIMIT 50"))


# ---------------- المتبرع ----------------
@bp.route("/donor/profile", methods=["GET", "PATCH"])
@api_auth_required(donor=True)
def donor_profile():
    db = get_db()
    d = g.user.donor
    if request.method == "PATCH":
        data = body()
        f = Form({"governorate_id": d["governorate_id"], "locality_id": d["locality_id"],
                  "preferred_center_id": d["preferred_center_id"], "blood_type": d["blood_type"] or "unknown", **data})
        validate_donor_fields(f, db)
        if not f.ok:
            return bad(f)
        new = {"governorate_id": f.clean["governorate_id"], "locality_id": f.clean["locality_id"],
               "preferred_center_id": f.clean.get("preferred_center_id")}
        if not d["blood_type_verified"]:
            new["blood_type"] = f.clean.get("blood_type")
        db.update("donors", d["id"], {**new, "updated_at": utcnow()})
        audit.log("donor_update", "donor", d["id"], audit.diff(d, new, list(new)))
        d = db.get("donors", d["id"])
    prof = db.one("SELECT * FROM donor_profiles WHERE donor_id = ?", (d["id"],))
    return jsonify({"code": d["donor_code"], "name": g.user.name, "phone": display_phone(g.user.phone),
                    "blood_type": d["blood_type"], "blood_type_verified": bool(d["blood_type_verified"]),
                    "governorate_id": d["governorate_id"], "locality_id": d["locality_id"],
                    "preferred_center_id": d["preferred_center_id"], "registered_at": d["registered_at"],
                    "last_donation_at": d["last_donation_at"], "donations_count": d["donations_count"], "status": d["status"],
                    "notifications": {k: bool(prof[k]) for k in ("notify_in_app", "notify_sms", "notify_emergency", "notify_reminders")}})


def _appt_json(a):
    return {"id": a["id"], "center_id": a["center_id"], "center": a.get("center_name"), "date": str(a["appointment_date"])[:10],
            "time": str(a["appointment_time"])[:5], "status": a["status"], "status_label": label("appointment", a["status"])}


@bp.route("/donor/appointments", methods=["GET", "POST"])
@api_auth_required(donor=True)
def donor_appointments():
    db = get_db()
    d = g.user.donor
    if request.method == "POST":
        data = body()
        f = Form(data)
        c = f.fk("center_id", "المركز", db, "blood_centers", where="status = 'active'")
        f.date("date", "التاريخ")
        f.time("time", "الوقت")
        if not data.get("acknowledged"):
            f.error("acknowledged", "يجب تأكيد الاطلاع على أن حجز الموعد لا يعني الأهلية الطبية للتبرع.")
        if not f.ok:
            return bad(f)
        try:
            aid = appt_svc.book(d, c["id"], f.clean["date"], f.clean["time"], (data.get("notes") or "")[:300] or None)
        except appt_svc.BookingError as e:
            return jsonify(error="booking_error", message=str(e)), 409
        audit.log("appointment_create", "appointment", aid, {"قناة": "API"})
        a = db.one("SELECT a.*, c.name AS center_name FROM appointments a JOIN blood_centers c ON c.id = a.center_id WHERE a.id = ?", (aid,))
        return jsonify(_appt_json(a)), 201
    rows = db.query("""SELECT a.*, c.name AS center_name FROM appointments a JOIN blood_centers c ON c.id = a.center_id
                       WHERE a.donor_id = ? ORDER BY a.appointment_date DESC LIMIT 100""", (d["id"],))
    return jsonify([_appt_json(a) for a in rows])


def _my_appt(appt_id):
    a = get_db().one("SELECT a.*, c.name AS center_name FROM appointments a JOIN blood_centers c ON c.id = a.center_id "
                     "WHERE a.id = ? AND a.donor_id = ?", (appt_id, g.user.donor["id"]))
    if not a:
        abort(404)
    return a


@bp.route("/donor/appointments/<int:appt_id>", methods=["GET", "PATCH"])
@api_auth_required(donor=True)
def donor_appointment(appt_id):
    a = _my_appt(appt_id)
    if request.method == "PATCH":
        db = get_db()
        f = Form({"center_id": a["center_id"], **body()})
        c = f.fk("center_id", "المركز", db, "blood_centers", where="status = 'active'")
        f.date("date", "التاريخ")
        f.time("time", "الوقت")
        if not f.ok:
            return bad(f)
        try:
            appt_svc.reschedule(a, c["id"], f.clean["date"], f.clean["time"])
        except appt_svc.BookingError as e:
            return jsonify(error="booking_error", message=str(e)), 409
        audit.log("appointment_update", "appointment", appt_id, {"قناة": "API"})
        a = _my_appt(appt_id)
    return jsonify(_appt_json(a))


@bp.route("/donor/appointments/<int:appt_id>/cancel", methods=["POST"])
@api_auth_required(donor=True)
def donor_appointment_cancel(appt_id):
    a = _my_appt(appt_id)
    reason = (body().get("reason") or "ألغاه المتبرع")[:200]
    try:
        appt_svc.cancel(a, reason, by_donor=True)
    except appt_svc.BookingError as e:
        return jsonify(error="booking_error", message=str(e)), 409
    audit.log("appointment_cancel", "appointment", appt_id, {"قناة": "API"})
    return jsonify(_appt_json(_my_appt(appt_id)))


@bp.route("/donor/donations")
@api_auth_required(donor=True)
def donor_donations():
    rows = get_db().query("""SELECT x.id, x.donated_at, x.blood_type, x.volume_ml, x.status, c.name AS center
                             FROM donations x JOIN blood_centers c ON c.id = x.center_id WHERE x.donor_id = ?
                             ORDER BY x.donated_at DESC""", (g.user.donor["id"],))
    for r in rows:
        r["status_label"] = label("donation", r["status"])
    return jsonify(rows)


@bp.route("/notifications")
@api_auth_required()
def notifications():
    page = paginate(get_db(), "SELECT id, category, title, body, link, is_read, created_at FROM notifications WHERE user_id = ? "
                    "ORDER BY created_at DESC", [g.user.id], request.args.get("page", 1, type=int), 30)
    return jsonify(items=page["rows"], page=page["page"], pages=page["pages"], total=page["total"])


@bp.route("/notifications/<int:nid>/read", methods=["POST"])
@api_auth_required()
def notification_read(nid):
    cur = get_db().execute("UPDATE notifications SET is_read = 1, read_at = ? WHERE id = ? AND user_id = ?", (utcnow(), nid, g.user.id))
    if not cur.rowcount:
        abort(404)
    return jsonify(ok=True)


# ---------------- الإدارة (حسب النطاق) ----------------
@bp.route("/admin/dashboard")
@api_auth_required("dashboard.view")
def admin_dashboard():
    return jsonify(stats.dashboard(g.user.scope))


@bp.route("/admin/inventory")
@api_auth_required("inventory.view")
def admin_inventory():
    cf, cp = center_filter(g.user.scope)
    rows = get_db().query(f"""SELECT i.center_id, c.name AS center, i.blood_type, i.available_units, i.reserved_units,
        i.critical_level, i.low_level, i.updated_at FROM blood_inventory i JOIN blood_centers c ON c.id = i.center_id
        WHERE {cf} AND c.status = 'active' ORDER BY c.name, i.blood_type""", cp)
    for r in rows:
        r["status"] = stock_status(r)
    return jsonify(rows)


@bp.route("/admin/requests", methods=["GET", "POST"])
@api_auth_required("requests.view")
def admin_requests():
    db = get_db()
    if request.method == "POST":
        if not g.user.can("requests.create"):
            return jsonify(error="forbidden", message="لا تملك صلاحية إنشاء طلبات الدم"), 403
        f = Form(body())
        c = f.fk("center_id", "المركز", db, "blood_centers", where="status = 'active'")
        from ..rbac import can_access_center
        if c and not can_access_center(db, g.user.scope, c["id"]):
            return jsonify(error="forbidden", message="المركز خارج نطاق صلاحياتك"), 403
        f.blood_type()
        f.integer("units_required", "عدد الوحدات", min_value=1, max_value=100)
        f.urgency()
        f.text("requesting_entity", "الجهة الطالبة", min_len=3, max_len=150)
        f.text("notes", "ملاحظات", required=False, max_len=1000)
        if not f.ok:
            return bad(f)
        rid = ra.create_request(f.clean, g.user.id)
        audit.log("request_create", "blood_request", rid, {"قناة": "API"})
        return jsonify(db.get("blood_requests", rid)), 201
    cf, cp = center_filter(g.user.scope)
    rows = db.query(f"""SELECT r.id, r.request_code, r.blood_type, r.units_required, r.units_fulfilled, r.urgency, r.status,
        r.requesting_entity, r.created_at, c.name AS center FROM blood_requests r JOIN blood_centers c ON c.id = r.center_id
        WHERE {cf} ORDER BY r.created_at DESC LIMIT 200""", cp)
    return jsonify(rows)


@bp.errorhandler(404)
def _nf(_e):
    return jsonify(error="not_found", message="غير موجود"), 404


