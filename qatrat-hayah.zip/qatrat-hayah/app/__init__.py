"""قطرة حياة | QATRAT HAYAH — منصة رقمية للتبرع بالدم وخدمات نقل الدم."""
import logging
from datetime import timedelta
from pathlib import Path

import click
from flask import Flask, g, jsonify, render_template, request
from werkzeug.exceptions import HTTPException

from .config import Config
from .db import close_db, get_db


def create_app(config_object=None, overrides=None):
    app = Flask(__name__, instance_relative_config=False)
    app.config.from_object(config_object or Config)
    if overrides:
        app.config.update(overrides)
    if app.config.get("ENV") == "production" and not app.config.get("TESTING"):
        import os
        missing = [k for k in ("QH_SECRET_KEY",) if not os.environ.get(k)]
        if missing:
            raise RuntimeError("متغيرات بيئة مطلوبة للإنتاج غير مضبوطة: " + ", ".join(missing))
        app.config["SESSION_COOKIE_SECURE"] = True
    app.permanent_session_lifetime = timedelta(seconds=app.config["PERMANENT_SESSION_LIFETIME"])
    if app.config["DATABASE_URL"].startswith("sqlite:///"):
        Path(app.config["DATABASE_URL"][len("sqlite:///"):]).parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO)

    app.teardown_appcontext(close_db)
    _register_template_helpers(app)
    _register_hooks(app)
    _register_errors(app)
    _register_blueprints(app)
    _register_cli(app)

    with app.app_context():
        from .schema import migrate
        from .seed import seed_reference
        db = get_db()
        migrate(db)
        seed_reference(db)
        if app.config.get("SEED_DEMO_DATA"):
            from .seed import seed_demo
            seed_demo(db)
    return app


def _register_blueprints(app):
    from .views.public import bp as public_bp
    from .views.auth import bp as auth_bp
    from .views.donor import bp as donor_bp
    from .views.admin import bp as admin_bp
    from .views.api import bp as api_bp
    from .views.setup import bp as setup_bp
    for bp in (public_bp, auth_bp, donor_bp, admin_bp, api_bp, setup_bp):
        app.register_blueprint(bp)


def _register_hooks(app):
    from .security import csrf_protect, load_current_user

    @app.before_request
    def _before():
        from .views.setup import setup_required_redirect
        r = setup_required_redirect()
        if r is not None:
            return r
        load_current_user()
        csrf_protect()

    @app.after_request
    def _headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        resp.headers["Permissions-Policy"] = "geolocation=(self), camera=(), microphone=()"
        resp.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
        if app.config.get("SESSION_COOKIE_SECURE"):
            resp.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
        if request.path.startswith("/static/"):
            resp.headers["Cache-Control"] = "public, max-age=604800"
        elif g.get("user") is not None:
            resp.headers["Cache-Control"] = "no-store"
        return resp


def _register_errors(app):
    messages = {
        400: ("طلب غير صالح", "تعذر معالجة الطلب. يرجى التحقق من البيانات والمحاولة مرة أخرى."),
        403: ("غير مصرح", "لا تملك صلاحية للوصول إلى هذه الصفحة."),
        404: ("الصفحة غير موجودة", "لم نتمكن من العثور على الصفحة المطلوبة."),
        405: ("إجراء غير مسموح", "هذا الإجراء غير مسموح."),
        413: ("الملف كبير جدًا", "حجم البيانات المرسلة أكبر من المسموح."),
        429: ("محاولات كثيرة", "تجاوزت عدد المحاولات المسموح. يرجى الانتظار قليلًا ثم المحاولة."),
        500: ("خطأ غير متوقع", "حدث خطأ غير متوقع. تم تسجيله وسنعمل على معالجته."),
    }

    @app.errorhandler(Exception)
    def _err(e):
        if isinstance(e, HTTPException) and e.code is not None and e.code < 400:
            return e
        code = e.code if isinstance(e, HTTPException) else 500
        if code == 500:
            app.logger.exception("Unhandled error")
        title, msg = messages.get(code, messages[500])
        if isinstance(e, HTTPException) and code == 400 and e.description and "النموذج" in str(e.description):
            msg = e.description
        if request.path.startswith("/api/"):
            return jsonify(error=title, message=msg), code
        return render_template("error.html", code=code, title=title, message=msg), code


def _register_template_helpers(app):
    from . import filters
    filters.register(app)


def _register_cli(app):
    @app.cli.command("init-db")
    def init_db():
        """تطبيق الترحيلات والبيانات المرجعية."""
        click.echo("قاعدة البيانات جاهزة.")

    @app.cli.command("create-admin")
    @click.option("--name", prompt="الاسم")
    @click.option("--phone", prompt="رقم الهاتف")
    @click.password_option()
    def create_admin(name, phone, password):
        """إنشاء حساب مدير النظام."""
        from .seed import create_super_admin
        from .validators import Form
        f = Form({"phone": phone, "password": password})
        f.phone(); f.password()
        if not f.ok:
            raise click.ClickException(" ".join(f.errors.values()))
        create_super_admin(get_db(), name, f.clean["phone"], password)
        click.echo("تم إنشاء مدير النظام.")

    @app.cli.command("seed-demo")
    def seed_demo_cmd():
        """إضافة بيانات تجريبية وهمية (لبيئة التطوير فقط)."""
        from .seed import seed_demo
        click.echo("تمت الإضافة." if seed_demo(get_db()) else "توجد بيانات بالفعل؛ لم تتم الإضافة.")

    @app.cli.command("send-reminders")
    def send_reminders_cmd():
        from .services.appointments import send_reminders
        click.echo(f"تذكيرات مرسلة: {send_reminders()}")

    @app.cli.command("process-outbox")
    def process_outbox_cmd():
        from .notifications import process_outbox
        click.echo(f"رسائل مرسلة: {process_outbox()}")

    @app.cli.command("expire-appeals")
    def expire_cmd():
        from .services.requests_appeals import expire_appeals
        click.echo(f"نداءات مغلقة: {expire_appeals()}")

    @app.cli.command("cleanup")
    def cleanup_cmd():
        """حذف سجلات حدود المحاولات القديمة ورسائل الصندوق المرسلة منذ أكثر من 90 يومًا."""
        import time
        from .db import utcnow
        db = get_db()
        db.execute("DELETE FROM rate_limits WHERE window_start < ?", (int(time.time()) - 86400,))
        db.execute("DELETE FROM notification_outbox WHERE status = 'sent' AND sent_at < ?",
                   ((__import__("datetime").datetime.utcnow() - timedelta(days=90)).strftime("%Y-%m-%d %H:%M:%S"),))
        click.echo("تم التنظيف. " + utcnow())

    @app.cli.command("restore-json")
    @click.argument("path")
    @click.option("--yes", is_flag=True, help="تأكيد استبدال كل البيانات الحالية")
    def restore_json_cmd(path, yes):
        """استعادة نسخة احتياطية بصيغة JSON (qatrat-*.json.zip). تحذف البيانات الحالية!"""
        if not yes:
            raise click.ClickException("هذا الأمر يستبدل كل البيانات. أعد التشغيل مع --yes للتأكيد.")
        from .services.backup import restore_json
        click.echo(f"تمت الاستعادة: {restore_json(path)} صفًا.")

    @app.cli.command("export-json")
    @click.argument("path")
    def export_json_cmd(path):
        """تصدير نسخة JSON محمولة (للنقل بين SQLite و PostgreSQL أو بين الخوادم)."""
        from .services.backup import export_json
        with open(path, "wb") as fh:
            fh.write(export_json())
        click.echo(f"تم التصدير إلى {path}")

    @app.cli.command("backup")
    def backup_cmd():
        from .services.backup import create_backup
        click.echo(f"تم إنشاء النسخة: {create_backup()}")
