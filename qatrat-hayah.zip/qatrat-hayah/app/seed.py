"""البيانات المرجعية (الأدوار، الصلاحيات، الولايات) والبيانات التجريبية.

تنبيه: كل الأسماء وأرقام الهواتف في البيانات التجريبية وهمية بالكامل،
ولا تمثل أي متبرع أو مريض حقيقي. أسماء المراكز التجريبية عامة وليست بيانات رسمية.
"""
import random
from datetime import datetime, timedelta, timezone

from .db import utcnow
from .rbac import PERMISSIONS, ROLE_PERMISSIONS, ROLES
from .schema import BLOOD_TYPES

GOVERNORATES = [
    ("شمال كردفان", "North Kordofan", "NK", 1),
    ("الخرطوم", "Khartoum", "KH", 0), ("الجزيرة", "Gezira", "GZ", 0), ("نهر النيل", "River Nile", "RN", 0),
    ("الشمالية", "Northern", "NO", 0), ("كسلا", "Kassala", "KA", 0), ("القضارف", "Gedaref", "GD", 0),
    ("البحر الأحمر", "Red Sea", "RS", 0), ("سنار", "Sennar", "SN", 0), ("النيل الأبيض", "White Nile", "WN", 0),
    ("النيل الأزرق", "Blue Nile", "BN", 0), ("شمال دارفور", "North Darfur", "ND", 0),
    ("جنوب دارفور", "South Darfur", "SD", 0), ("غرب دارفور", "West Darfur", "WD", 0),
    ("وسط دارفور", "Central Darfur", "CD", 0), ("شرق دارفور", "East Darfur", "ED", 0),
    ("غرب كردفان", "West Kordofan", "WK", 0), ("جنوب كردفان", "South Kordofan", "SK", 0),
]

# محليات ولاية شمال كردفان ومدنها الرئيسية (قابلة للتعديل والإضافة من لوحة الإدارة)
NK_LOCALITIES = [
    ("شيكان", "Sheikan", ["الأبيض"]),
    ("أم روابة", "Um Rawaba", ["أم روابة"]),
    ("الرهد", "Er Rahad", ["الرهد"]),
    ("بارا", "Bara", ["بارا"]),
    ("غرب بارا", "West Bara", ["أم كريدم"]),
    ("جبرة الشيخ", "Gebrat El Sheikh", ["جبرة الشيخ"]),
    ("سودري", "Sodari", ["سودري"]),
    ("أم دم حاج أحمد", "Um Dam Haj Ahmed", ["أم دم حاج أحمد"]),
]

DEMO_CENTERS = [
    # name, type, locality, city, lat, lon, hours, services
    ("المركز الرئيسي لخدمات نقل الدم – الأبيض", "blood_bank", "شيكان", "الأبيض", 13.1843, 30.2167,
     "السبت – الخميس: 8:00 ص – 8:00 م", "استقبال المتبرعين، فحص الفصائل، تخزين الدم ومكوناته، صرف الوحدات للمستشفيات"),
    ("بنك الدم بالمستشفى التعليمي – الأبيض", "hospital_bank", "شيكان", "الأبيض", 13.1790, 30.2300,
     "يوميًا: 8:00 ص – 2:00 م", "استقبال المتبرعين، صرف الوحدات للأقسام"),
    ("مركز التبرع بالدم – أم روابة", "donation_center", "أم روابة", "أم روابة", 12.9060, 31.2160,
     "السبت – الخميس: 8:00 ص – 2:00 م", "استقبال المتبرعين، فحص الفصائل"),
    ("مركز التبرع بالدم – الرهد", "donation_center", "الرهد", "الرهد", 12.7170, 30.6500,
     "السبت – الخميس: 8:00 ص – 2:00 م", "استقبال المتبرعين"),
    ("مركز التبرع بالدم – بارا", "donation_center", "بارا", "بارا", 13.7000, 30.3700,
     "الأحد – الخميس: 8:00 ص – 1:00 م", "استقبال المتبرعين"),
    ("وحدة التبرع المتنقلة – شيكان", "mobile_unit", "شيكان", "الأبيض", None, None,
     "حسب جدول الحملات", "حملات تبرع في الجامعات والمساجد والأسواق"),
]

FIRST_M = ["محمد", "أحمد", "عثمان", "عبدالله", "مصطفى", "الطيب", "حسن", "إبراهيم", "يوسف", "خالد", "عمر", "آدم", "صلاح", "بكري", "مجاهد"]
FIRST_F = ["فاطمة", "آمنة", "مريم", "سارة", "هبة", "إيمان", "نون", "رشا", "سلمى", "تسنيم", "مواهب", "إسراء"]
LAST = ["عبدالرحمن", "الحسن", "إدريس", "الأمين", "النور", "موسى", "عبدالقادر", "البشير", "حامد", "الصديق", "علي", "بابكر", "يعقوب", "الفاضل"]

DEMO_PASSWORD = "Demo@2026"

CONTENT = [
    ("كيف تستعد للتبرع بالدم؟", "before", "خطوات بسيطة تجعل تجربة التبرع مريحة وآمنة.",
     "- احصل على نوم كافٍ في الليلة السابقة.\n- تناول وجبة خفيفة صحية قبل التبرع بساعتين تقريبًا، وتجنب الأطعمة الدسمة.\n"
     "- اشرب كمية كافية من الماء.\n- أحضر بطاقة إثبات الهوية.\n- أخبر الطاقم الطبي بأي أدوية تتناولها أو حالة صحية لديك.\n\n"
     "تذكّر: حجز الموعد لا يُعد دليلاً على الأهلية الطبية للتبرع، والقرار النهائي يحدده المختصون في مركز التبرع."),
    ("ماذا تفعل بعد التبرع؟", "after", "نصائح للعناية بنفسك بعد التبرع مباشرة.",
     "- استرح في المركز من 10 إلى 15 دقيقة وتناول المشروب المقدم لك.\n- اشرب كميات إضافية من السوائل خلال اليوم.\n"
     "- تجنب المجهود البدني الشاق ورفع الأوزان الثقيلة بقية اليوم.\n- اترك الضمادة على مكان الإبرة لعدة ساعات.\n"
     "- إذا شعرت بدوار فاجلس أو استلقِ وارفع قدميك، وتواصل مع المركز إذا استمرت الأعراض."),
    ("من يمكنه التبرع بالدم؟ (إرشادات عامة)", "eligibility", "معلومات عامة فقط — القرار للمختصين في المركز.",
     "توجد شروط عامة معتمدة في أغلب مراكز نقل الدم، مثل العمر المناسب، والوزن المناسب، والحالة الصحية الجيدة يوم التبرع، "
     "ومرور فترة كافية على آخر تبرع.\n\nتختلف التفاصيل حسب اللوائح الوطنية وحالة كل متبرع، ولذلك يُجري المختصون في المركز "
     "تقييمًا طبيًا قبل كل تبرع. هذه المنصة لا تحدد أهليتك للتبرع."),
    ("مفاهيم خاطئة شائعة عن التبرع بالدم", "myths", "تصحيح لأكثر المعتقدات انتشارًا.",
     "- «التبرع يُضعف الجسم بشكل دائم»: الجسم يعوّض كمية الدم المتبرع بها خلال فترة قصيرة.\n"
     "- «يمكن أن أُصاب بعدوى أثناء التبرع»: تُستخدم أدوات معقمة تُستعمل لمرة واحدة فقط.\n"
     "- «لا حاجة للتبرع إذا كانت فصيلتي شائعة»: الفصائل الشائعة هي الأكثر طلبًا أيضًا.\n"
     "- «التبرع يستغرق وقتًا طويلًا»: سحب الدم يستغرق عادة أقل من 15 دقيقة."),
    ("لماذا نحتاج إلى متبرعين منتظمين؟", "general", "المخزون الآمن يعتمد على العطاء المستمر.",
     "لا يمكن تصنيع الدم، ومكوناته لها فترات صلاحية محدودة. لذلك تحتاج بنوك الدم إلى متبرعين منتظمين لضمان توفر الدم "
     "لمرضى الحوادث والولادة والعمليات وأمراض الدم. سجّل في «قطرة حياة» واحجز موعدك القادم."),
]


def seed_reference(db):
    """مزامنة الأدوار والصلاحيات وقائمة الولايات (آمنة للتشغيل المتكرر)."""
    now = utcnow()
    for code, name, level, rank in ROLES:
        r = db.one("SELECT id FROM roles WHERE code = ?", (code,))
        if r:
            db.execute("UPDATE roles SET name_ar = ?, scope_level = ?, rank = ? WHERE id = ?", (name, level, rank, r["id"]))
        else:
            db.insert("roles", {"code": code, "name_ar": name, "scope_level": level, "rank": rank})
    for code, name, module in PERMISSIONS:
        if not db.one("SELECT id FROM permissions WHERE code = ?", (code,)):
            db.insert("permissions", {"code": code, "name_ar": name, "module": module})
    db.execute("DELETE FROM role_permissions")
    for rcode, perms in ROLE_PERMISSIONS.items():
        rid = db.scalar("SELECT id FROM roles WHERE code = ?", (rcode,))
        for p in perms:
            pid = db.scalar("SELECT id FROM permissions WHERE code = ?", (p,))
            db.execute("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)", (rid, pid))
    if not db.scalar("SELECT COUNT(*) AS n FROM governorates", (), 0):
        for ar, en, code, active in GOVERNORATES:
            db.insert("governorates", {"name_ar": ar, "name_en": en, "code": code, "is_active": active, "created_at": now})
        nk = db.scalar("SELECT id FROM governorates WHERE code = 'NK'")
        for ar, en, cities in NK_LOCALITIES:
            lid = db.insert("localities", {"governorate_id": nk, "name_ar": ar, "name_en": en, "is_active": 1, "created_at": now})
            for c in cities:
                db.insert("cities", {"locality_id": lid, "name_ar": c, "is_active": 1, "created_at": now})
    if not db.scalar("SELECT COUNT(*) AS n FROM educational_content", (), 0):
        # محتوى توعوي عام (ليس بيانات تجريبية) يمكن تعديله من لوحة الإدارة
        for i, (title, cat, summary, body) in enumerate(CONTENT):
            db.insert("educational_content", {"title": title, "slug": f"article-{i + 1}", "category": cat, "summary": summary,
                                              "body": body, "is_published": 1, "published_at": now, "author_id": None,
                                              "created_at": now, "updated_at": now})
    from .services.common import DEFAULT_SETTINGS
    for k, (v, desc) in DEFAULT_SETTINGS.items():
        if not db.one("SELECT key FROM system_settings WHERE key = ?", (k,)):
            db.execute("INSERT INTO system_settings (key, value, description, updated_at) VALUES (?,?,?,?)", (k, v, desc, now))


def create_user(db, name, phone, password, is_staff=0, pw_hash=None):
    from .security import hash_password
    now = utcnow()
    return db.insert("users", {"full_name": name, "phone": phone, "password_hash": pw_hash or hash_password(password),
                               "status": "active", "is_staff": is_staff, "created_at": now, "updated_at": now})


def assign_role(db, user_id, role_code, gov=None, loc=None, center=None, by=None):
    rid = db.scalar("SELECT id FROM roles WHERE code = ?", (role_code,))
    return db.insert("user_roles", {"user_id": user_id, "role_id": rid, "governorate_id": gov, "locality_id": loc,
                                    "center_id": center, "assigned_by": by, "created_at": utcnow()})


def create_super_admin(db, name, phone, password):
    uid = create_user(db, name, phone, password, is_staff=1)
    assign_role(db, uid, "super_admin")
    return uid


def _ts(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")


def seed_demo(db, rng_seed=2026):
    """بيانات تجريبية وهمية بالكامل لغرض التطوير والعرض فقط."""
    if db.scalar("SELECT COUNT(*) AS n FROM users", (), 0):
        return False
    from .security import hash_password
    from .services import inventory
    rng = random.Random(rng_seed)
    now = datetime.now(timezone.utc)
    pw = hash_password(DEMO_PASSWORD)
    nk = db.one("SELECT * FROM governorates WHERE code = 'NK'")
    locs = {r["name_ar"]: r for r in db.query("SELECT * FROM localities WHERE governorate_id = ?", (nk["id"],))}
    cities = {r["name_ar"]: r for r in db.query("SELECT * FROM cities")}

    centers = []
    for name, ctype, loc, city, lat, lon, hours, services in DEMO_CENTERS:
        cid = db.insert("blood_centers", {
            "name": name, "center_type": ctype, "governorate_id": nk["id"], "locality_id": locs[loc]["id"],
            "city_id": cities[city]["id"], "address": f"{city} – العنوان التفصيلي (تجريبي)",
            "phone": f"09000001{len(centers) + 10}", "working_hours": hours, "latitude": lat, "longitude": lon,
            "services": services, "accepts_appointments": 1, "status": "active",
            "created_at": _ts(now), "updated_at": _ts(now)})
        if ctype in ("blood_bank", "hospital_bank"):
            db.insert("blood_banks", {"center_id": cid, "license_no": f"DEMO-{cid:03d}", "storage_capacity_units": 400,
                                      "has_component_separation": 1 if ctype == "blood_bank" else 0, "is_active": 1,
                                      "created_at": _ts(now)})
        days = [5, 6, 0, 1, 2, 3] if "الأحد" not in hours else [6, 0, 1, 2, 3]
        if hours.startswith("يوميًا"):
            days = list(range(7))
        end = "20:00" if "8:00 م" in hours else ("13:00" if "1:00 م" in hours else "14:00")
        for wd in days:
            db.insert("center_schedules", {"center_id": cid, "weekday": wd, "start_time": "08:00", "end_time": end,
                                           "slot_minutes": 30, "capacity_per_slot": 4 if ctype == "blood_bank" else 2})
        inventory.ensure_center_inventory(cid)
        centers.append(db.get("blood_centers", cid))
    main, hosp, umr = centers[0], centers[1], centers[2]

    staff = [
        ("مدير النظام (تجريبي)", "+249900000001", "super_admin", {}),
        ("مسؤول الإدارة العامة (تجريبي)", "+249900000002", "general_admin", {}),
        ("مدير ولاية شمال كردفان (تجريبي)", "+249900000003", "state_manager", {"gov": nk["id"]}),
        ("مدير محلية شيكان (تجريبي)", "+249900000004", "locality_manager", {"loc": locs["شيكان"]["id"]}),
        ("مدير المركز الرئيسي (تجريبي)", "+249900000005", "center_manager", {"center": main["id"]}),
        ("موظف المركز الرئيسي (تجريبي)", "+249900000006", "center_staff", {"center": main["id"]}),
        ("مدير مركز أم روابة (تجريبي)", "+249900000007", "center_manager", {"center": umr["id"]}),
    ]
    staff_ids = {}
    for name, phone, role, sc in staff:
        uid = create_user(db, name, phone, None, is_staff=1, pw_hash=pw)
        assign_role(db, uid, role, sc.get("gov"), sc.get("loc"), sc.get("center"))
        staff_ids[role if role not in staff_ids else role + "_2"] = uid
    admin_id = staff_ids["super_admin"]
    mgr_id = staff_ids["center_manager"]
    staff_id = staff_ids["center_staff"]

    # المتبرعون (وهميون)
    weights = [0.30, 0.03, 0.25, 0.02, 0.06, 0.01, 0.30, 0.03]  # توزيع تقريبي للعرض فقط
    donors = []
    loc_list = list(locs.values())
    for i in range(48):
        female = rng.random() < 0.35
        name = f"{rng.choice(FIRST_F if female else FIRST_M)} {rng.choice(FIRST_M)} {rng.choice(LAST)}"
        phone = f"+2499110{i + 1:05d}"
        uid = create_user(db, name, phone, None, pw_hash=pw)
        assign_role(db, uid, "donor")
        center = rng.choice(centers[:5])
        loc = db.get("localities", center["locality_id"]) if rng.random() < 0.8 else rng.choice(loc_list)
        reg = now - timedelta(days=rng.randint(20, 420))
        bt = rng.choices(BLOOD_TYPES, weights)[0] if rng.random() < 0.9 else None
        did = db.insert("donors", {
            "user_id": uid, "donor_code": f"D-DEMO{i + 1:03d}", "blood_type": bt, "blood_type_verified": 0,
            "governorate_id": nk["id"], "locality_id": loc["id"], "preferred_center_id": center["id"],
            "donations_count": 0, "status": "active", "registered_at": _ts(reg), "updated_at": _ts(reg)})
        db.insert("donor_profiles", {"donor_id": did, "gender": "female" if female else "male",
                                     "birth_year": rng.randint(1970, 2005), "notify_in_app": 1, "notify_sms": 0,
                                     "notify_emergency": 1, "notify_reminders": 1, "updated_at": _ts(reg)})
        donors.append(db.get("donors", did))

    # تبرعات سابقة معتمدة (تُضاف للمخزون عبر الحركات)
    unit = 1
    for d in donors:
        if not d["blood_type"]:
            continue
        n = rng.choice([0, 1, 1, 2, 3])
        dates = sorted(now - timedelta(days=rng.randint(5, 360)) for _ in range(n))
        for dt in dates:
            center = db.get("blood_centers", d["preferred_center_id"])
            status = "approved" if rng.random() < 0.93 else "rejected"
            xid = db.insert("donations", {
                "donor_id": d["id"], "center_id": center["id"], "unit_number": f"U-DEMO{unit:05d}",
                "blood_type": d["blood_type"], "volume_ml": 450, "donated_at": _ts(dt),
                "medical_decision_by": "د. طبيب المركز (تجريبي)", "status": status,
                "rejection_reason": "لم تجتز الوحدة الفحص المخبري (تجريبي)" if status == "rejected" else None,
                "recorded_by": staff_id, "approved_by": mgr_id, "approved_at": _ts(dt + timedelta(hours=6)),
                "created_at": _ts(dt)})
            unit += 1
            if status == "approved":
                inventory.apply(center["id"], d["blood_type"], "donation_in", 1, mgr_id, "تبرع (تجريبي)", ("donation", xid))
                db.execute("UPDATE donors SET donations_count = donations_count + 1, last_donation_at = ?, "
                           "blood_type_verified = 1 WHERE id = ?", (_ts(dt), d["id"]))
    # رصيد افتتاحي (تسوية جرد) لإظهار حالات المخزون المختلفة
    for c in centers[:5]:
        for bt in BLOOD_TYPES:
            row = inventory.get_row(c["id"], bt)
            base = {"O+": 14, "A+": 11, "B+": 9, "AB+": 4, "O-": 2, "A-": 3, "B-": 1, "AB-": 0}[bt]
            if c["center_type"] == "donation_center":
                base = base // 3
            target = max(0, base + rng.randint(-2, 3))
            inventory.stocktake(c["id"], bt, target, mgr_id, "رصيد افتتاحي (تجريبي)")
    inventory.apply(main["id"], "O+", "reserve", 2, mgr_id, "حجز لعملية جراحية (تجريبي)")

    # مواعيد قادمة
    from .timeutil import local_today
    today = local_today()
    for i, d in enumerate(donors[:10]):
        day = today + timedelta(days=1 + i % 6)
        sched = db.one("SELECT * FROM center_schedules WHERE center_id = ? AND weekday = ?", (d["preferred_center_id"], day.weekday()))
        if not sched:
            continue
        t = f"{8 + (i % 5):02d}:{'00' if i % 2 == 0 else '30'}"
        db.insert("appointments", {"donor_id": d["id"], "center_id": d["preferred_center_id"],
                                   "appointment_date": day.isoformat(), "appointment_time": t,
                                   "status": "confirmed" if i % 3 == 0 else "booked", "created_at": _ts(now),
                                   "updated_at": _ts(now)})
    # مواعيد سابقة (للتقارير)
    for i, d in enumerate(donors[10:22]):
        day = today - timedelta(days=3 + i)
        db.insert("appointments", {"donor_id": d["id"], "center_id": d["preferred_center_id"],
                                   "appointment_date": day.isoformat(), "appointment_time": "09:00",
                                   "status": rng.choice(["completed", "no_show", "cancelled", "deferred"]),
                                   "created_at": _ts(now - timedelta(days=10)), "updated_at": _ts(now)})

    # طلبات الدم
    from .services.common import unique_code
    reqs = [("O+", 4, main, "قسم الجراحة – المستشفى التعليمي", "urgent", "approved"),
            ("A-", 2, hosp, "قسم النساء والتوليد", "critical", "pending"),
            ("B+", 3, umr, "مستشفى أم روابة – الطوارئ", "medium", "partially_fulfilled"),
            ("AB+", 1, main, "قسم الباطنية", "normal", "fulfilled")]
    for bt, units, c, entity, urg, st in reqs:
        db.insert("blood_requests", {
            "request_code": unique_code("blood_requests", "request_code", "BR-"), "blood_type": bt,
            "units_required": units, "units_fulfilled": units if st == "fulfilled" else (1 if st == "partially_fulfilled" else 0),
            "center_id": c["id"], "requesting_entity": entity, "patient_reference": "ملف رقم تجريبي",
            "urgency": urg, "status": st, "notes": "طلب تجريبي لأغراض العرض", "requested_by": staff_id,
            "approved_by": mgr_id if st != "pending" else None, "approved_at": _ts(now) if st != "pending" else None,
            "created_at": _ts(now - timedelta(days=rng.randint(0, 6))), "updated_at": _ts(now)})

    # نداءات عاجلة
    db.insert("emergency_appeals", {
        "title": "احتياج عاجل للدم", "blood_type": "O-", "units_needed": 5, "units_collected": 1, "urgency": "critical",
        "center_id": main["id"], "message": "نداء تجريبي: يحتاج المركز الرئيسي إلى متبرعين من فصيلة O-.",
        "status": "open", "created_by": staff_id, "approved_by": mgr_id, "published_at": _ts(now - timedelta(hours=5)),
        "expires_at": (today + timedelta(days=7)).isoformat(), "created_at": _ts(now - timedelta(hours=6)),
        "updated_at": _ts(now)})
    db.insert("emergency_appeals", {
        "title": "دعم مخزون فصيلة B-", "blood_type": "B-", "units_needed": 3, "units_collected": 0, "urgency": "urgent",
        "center_id": umr["id"], "message": "نداء تجريبي بانتظار اعتماد مدير المركز.", "status": "pending_approval",
        "created_by": staff_ids.get("center_manager_2", mgr_id), "expires_at": (today + timedelta(days=5)).isoformat(),
        "created_at": _ts(now), "updated_at": _ts(now)})

    return True
