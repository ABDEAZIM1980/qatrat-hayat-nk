"""أدوات الوقت: التخزين بتوقيت UTC والعرض بتوقيت السودان."""
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from flask import current_app, has_app_context


def tz():
    name = current_app.config.get("TIMEZONE", "Africa/Khartoum") if has_app_context() else "Africa/Khartoum"
    return ZoneInfo(name)


def local_now():
    return datetime.now(timezone.utc).astimezone(tz())


def local_today():
    return local_now().date()


def parse_ts(v):
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        dt = v
    else:
        s = str(v).replace("T", " ")[:19]
        try:
            dt = datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
        except ValueError:
            try:
                dt = datetime.strptime(s[:10], "%Y-%m-%d")
            except ValueError:
                return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(tz())


def local_to_utc_str(local_dt):
    """يحوّل وقتًا محليًا (بدون منطقة) إلى نص UTC للتخزين."""
    if local_dt.tzinfo is None:
        local_dt = local_dt.replace(tzinfo=tz())
    return local_dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
