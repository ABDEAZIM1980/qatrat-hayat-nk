"""المصادقة، حماية CSRF، تحديد معدل الطلبات، ومُزخرفات الصلاحيات."""
import hmac
import secrets
import time
from datetime import datetime, timedelta, timezone
from functools import wraps

import jwt
from flask import abort, current_app, flash, g, redirect, request, session, url_for, jsonify
from werkzeug.security import check_password_hash, generate_password_hash

from .db import get_db, utcnow
from .rbac import load_user_access

PASSWORD_METHOD = "scrypt"


def hash_password(pw):
    return generate_password_hash(pw, method=PASSWORD_METHOD)


def verify_password(hashval, pw):
    try:
        return check_password_hash(hashval, pw)
    except Exception:
        return False


# نص ثابت لمقارنة زمنية متساوية عند عدم وجود المستخدم (منع كشف الأرقام المسجلة بالتوقيت)
_DUMMY_HASH = None


def dummy_verify(pw):
    global _DUMMY_HASH
    if _DUMMY_HASH is None:
        _DUMMY_HASH = hash_password("dummy-password-123")
    verify_password(_DUMMY_HASH, pw)


# ---------------- CSRF ----------------
def csrf_token():
    tok = session.get("_csrf")
    if not tok:
        tok = secrets.token_urlsafe(32)
        session["_csrf"] = tok
    return tok


def csrf_protect():
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return
    if request.path.startswith("/api/") or request.path == "/tasks/run":
        return  # الواجهة البرمجية ورابط المهام يستخدمان رموزًا وليس الكوكيز
    sent = request.form.get("_csrf") or request.headers.get("X-CSRF-Token", "")
    if not sent or not hmac.compare_digest(sent, session.get("_csrf", "")):
        abort(400, description="انتهت صلاحية النموذج. يرجى تحديث الصفحة والمحاولة مرة أخرى.")


# ---------------- Rate limiting ----------------
def rate_limited(key, limit, window):
    """يُرجع True إذا تجاوز المفتاح الحد المسموح خلال النافذة الزمنية."""
    if not current_app.config.get("RATELIMIT_ENABLED", True):
        return False
    db = get_db()
    now = int(time.time())
    row = db.one("SELECT window_start, hits FROM rate_limits WHERE key = ?", (key,))
    if not row or now - row["window_start"] >= window:
        if row:
            db.execute("UPDATE rate_limits SET window_start = ?, hits = 1 WHERE key = ?", (now, key))
        else:
            db.execute("INSERT INTO rate_limits (key, window_start, hits) VALUES (?, ?, 1)", (key, now))
        return False
    if row["hits"] >= limit:
        return True
    db.execute("UPDATE rate_limits SET hits = hits + 1 WHERE key = ?", (key,))
    return False


def reset_rate(key):
    get_db().execute("DELETE FROM rate_limits WHERE key = ?", (key,))


def client_ip():
    # خلف Nginx: يجب ضبط ProxyFix (انظر wsgi.py) حتى تكون remote_addr صحيحة
    return request.remote_addr or "0.0.0.0"


# ---------------- المستخدم الحالي ----------------
class CurrentUser:
    def __init__(self, row, perms, scope):
        self.row = row
        self.id = row["id"]
        self.name = row["full_name"]
        self.phone = row["phone"]
        self.perms = perms
        self.scope = scope
        self.is_staff = bool(row["is_staff"]) and not scope.is_empty
        self._donor = None

    def can(self, *perms):
        return any(p in self.perms for p in perms)

    @property
    def donor(self):
        if self._donor is None:
            self._donor = get_db().one("SELECT * FROM donors WHERE user_id = ?", (self.id,)) or False
        return self._donor or None

    @property
    def role_names(self):
        from .rbac import ROLE_NAMES
        return [ROLE_NAMES.get(r, r) for r in self.scope.roles]


def load_user(user_id, auth_version=None):
    db = get_db()
    row = db.one("SELECT * FROM users WHERE id = ?", (user_id,))
    if not row or row["status"] != "active":
        return None
    if auth_version is not None and row["auth_version"] != auth_version:
        return None
    perms, scope = load_user_access(db, row["id"])
    return CurrentUser(row, perms, scope)


def load_current_user():
    g.user = None
    uid = session.get("uid")
    if uid:
        g.user = load_user(uid, session.get("av"))
        if g.user is None:
            session.clear()


def login_session(user_row):
    session.clear()
    session.permanent = True
    session["uid"] = user_row["id"]
    session["av"] = user_row["auth_version"]
    csrf_token()


def login_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if g.get("user") is None:
            flash("يرجى تسجيل الدخول أولًا.", "info")
            return redirect(url_for("auth.login", next=request.full_path if request.method == "GET" else None))
        return view(*a, **kw)
    return wrapped


def permission_required(*perms):
    def deco(view):
        @wraps(view)
        def wrapped(*a, **kw):
            if g.get("user") is None:
                return redirect(url_for("auth.login", next=request.full_path))
            if not g.user.is_staff or not g.user.can(*perms):
                abort(403)
            return view(*a, **kw)
        return wrapped
    return deco


def donor_required(view):
    @wraps(view)
    def wrapped(*a, **kw):
        if g.get("user") is None:
            flash("يرجى تسجيل الدخول أولًا.", "info")
            return redirect(url_for("auth.login", next=request.full_path))
        if not g.user.donor:
            flash("هذه الصفحة مخصصة للمتبرعين. أكمل ملف المتبرع أولًا.", "info")
            return redirect(url_for("donor.complete_profile"))
        return view(*a, **kw)
    return wrapped


# ---------------- JWT للواجهة البرمجية ----------------
def issue_token(user_row):
    now = datetime.now(timezone.utc)
    payload = {"sub": str(user_row["id"]), "av": user_row["auth_version"], "iat": now,
               "exp": now + timedelta(minutes=current_app.config["JWT_TTL_MINUTES"]), "typ": "access"}
    return jwt.encode(payload, current_app.config["JWT_SECRET"], algorithm="HS256")


def api_auth_required(*perms, donor=False):
    def deco(view):
        @wraps(view)
        def wrapped(*a, **kw):
            hdr = request.headers.get("Authorization", "")
            if not hdr.startswith("Bearer "):
                return jsonify(error="unauthorized", message="يلزم تسجيل الدخول"), 401
            try:
                data = jwt.decode(hdr[7:], current_app.config["JWT_SECRET"], algorithms=["HS256"])
                user = load_user(int(data["sub"]), data.get("av"))
            except Exception:
                user = None
            if user is None:
                return jsonify(error="unauthorized", message="رمز الدخول غير صالح أو منتهي"), 401
            g.user = user
            if perms and (not user.is_staff or not user.can(*perms)):
                return jsonify(error="forbidden", message="لا تملك صلاحية لهذا الإجراء"), 403
            if donor and not user.donor:
                return jsonify(error="forbidden", message="هذه الخدمة مخصصة للمتبرعين"), 403
            return view(*a, **kw)
        return wrapped
    return deco


def register_login_failure(db, user_row):
    cfg = current_app.config
    fails = user_row["failed_logins"] + 1
    data = {"failed_logins": fails, "updated_at": utcnow()}
    if fails >= cfg["LOGIN_MAX_ATTEMPTS"]:
        until = datetime.now(timezone.utc) + timedelta(minutes=cfg["ACCOUNT_LOCK_MINUTES"])
        data["locked_until"] = until.strftime("%Y-%m-%d %H:%M:%S")
        data["failed_logins"] = 0
    db.update("users", user_row["id"], data)


def is_locked(user_row):
    lu = user_row.get("locked_until")
    if not lu:
        return False
    return str(lu) > utcnow()
