/* قطرة حياة — سكربت خفيف (كل الصفحات تعمل بدونه، وهو يحسّن التجربة فقط) */
(function () {
  "use strict";

  // القوائم المترابطة: الولاية ← المحلية ← المدينة / المركز
  function fill(select, url, placeholder, keep) {
    if (!select) return;
    var current = keep || select.getAttribute("data-value") || "";
    select.disabled = true;
    fetch(url, { credentials: "same-origin" }).then(function (r) { return r.json(); }).then(function (rows) {
      select.innerHTML = "";
      var o = document.createElement("option");
      o.value = ""; o.textContent = placeholder; select.appendChild(o);
      rows.forEach(function (row) {
        var op = document.createElement("option");
        op.value = row.id; op.textContent = row.name;
        if (String(row.id) === String(current)) op.selected = true;
        select.appendChild(op);
      });
      select.disabled = false;
      select.dispatchEvent(new Event("change"));
    }).catch(function () { select.disabled = false; });
  }

  document.querySelectorAll("[data-geo-gov]").forEach(function (gov) {
    var form = gov.form || document;
    var loc = form.querySelector("[data-geo-loc]");
    var city = form.querySelector("[data-geo-city]");
    var center = form.querySelector("[data-geo-center]");
    var booking = center && center.hasAttribute("data-booking") ? "&booking=1" : "";
    gov.addEventListener("change", function () {
      if (loc) fill(loc, "/geo/localities.json?governorate_id=" + encodeURIComponent(gov.value), loc.getAttribute("data-placeholder") || "اختر المحلية");
      if (center && !loc) fill(center, "/geo/centers.json?governorate_id=" + encodeURIComponent(gov.value) + booking, center.getAttribute("data-placeholder") || "اختر المركز");
    });
    if (loc) loc.addEventListener("change", function () {
      if (city) fill(city, "/geo/cities.json?locality_id=" + encodeURIComponent(loc.value), city.getAttribute("data-placeholder") || "اختر المدينة");
      if (center) {
        var url = loc.value ? "/geo/centers.json?locality_id=" + encodeURIComponent(loc.value) + booking
                            : "/geo/centers.json?governorate_id=" + encodeURIComponent(gov.value) + booking;
        fill(center, url, center.getAttribute("data-placeholder") || "بدون تفضيل");
      }
    });
  });

  // تأكيد الإجراءات الحساسة
  document.addEventListener("submit", function (e) {
    var msg = e.target.getAttribute("data-confirm");
    if (msg && !window.confirm(msg)) e.preventDefault();
  });

  // إرسال نماذج التصفية تلقائيًا عند تغيير القوائم
  document.querySelectorAll("form[data-autosubmit] select").forEach(function (s) {
    s.addEventListener("change", function () { s.form.requestSubmit ? s.form.requestSubmit() : s.form.submit(); });
  });

  // إغلاق القوائم المنسدلة عند النقر خارجها
  document.addEventListener("click", function (e) {
    document.querySelectorAll("details.menu[open]").forEach(function (d) {
      if (!d.contains(e.target)) d.removeAttribute("open");
    });
  });

  // أقرب مركز باستخدام موقع الجهاز (بإذن المستخدم فقط)
  var nearBtn = document.querySelector("[data-near]");
  if (nearBtn && "geolocation" in navigator) {
    nearBtn.hidden = false;
    nearBtn.addEventListener("click", function () {
      nearBtn.disabled = true;
      nearBtn.textContent = "جارٍ تحديد موقعك…";
      navigator.geolocation.getCurrentPosition(function (p) {
        location.href = "/centers?lat=" + p.coords.latitude.toFixed(4) + "&lon=" + p.coords.longitude.toFixed(4);
      }, function () {
        nearBtn.disabled = false;
        nearBtn.textContent = "تعذر تحديد الموقع — اختر الولاية والمحلية";
      }, { timeout: 10000, maximumAge: 600000 });
    });
  }

  // إظهار حقول النطاق المناسبة عند اختيار الدور
  var roleSel = document.querySelector("[data-role-select]");
  if (roleSel) {
    var sync = function () {
      var opt = roleSel.options[roleSel.selectedIndex];
      var level = opt ? opt.getAttribute("data-level") : "";
      document.querySelectorAll("[data-scope]").forEach(function (el) {
        el.hidden = el.getAttribute("data-scope") !== level;
      });
    };
    roleSel.addEventListener("change", sync); sync();
  }

  // حقل المركز المستلم يظهر فقط عند التحويل
  var txSel = document.querySelector("[data-tx-type]");
  if (txSel) {
    var t = document.querySelector("[data-transfer-target]");
    var syncTx = function () { if (t) t.hidden = txSel.value !== "transfer_out"; };
    txSel.addEventListener("change", syncTx); syncTx();
  }

  // صفحة الطباعة
  if (document.body.hasAttribute("data-autoprint")) window.addEventListener("load", function () { window.print(); });
  document.querySelectorAll("[data-print]").forEach(function (b) { b.addEventListener("click", function () { window.print(); }); });
})();

// تطبيق قابل للتثبيت على الهاتف (PWA)
if ("serviceWorker" in navigator && (location.protocol === "https:" || location.hostname === "localhost")) {
  window.addEventListener("load", function () { navigator.serviceWorker.register("/sw.js").catch(function () {}); });
}
