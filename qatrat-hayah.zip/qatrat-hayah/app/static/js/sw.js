/* عامل الخدمة: يحفظ الملفات الثابتة وصفحة «بدون اتصال» فقط.
   لا تُحفظ أي صفحة تحتوي بيانات شخصية. */
const VERSION = "qh-v1";
const ASSETS = ["/offline", "/static/css/app.css", "/static/js/app.js", "/static/img/logo.svg",
  "/static/fonts/plex-arabic-Regular.woff", "/static/fonts/plex-arabic-Bold.woff", "/static/fonts/plex-arabic-SemiBold.woff",
  "/static/img/icon-192.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(ASSETS))); self.skipWaiting(); });
self.addEventListener("activate", e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;
  if (url.pathname.startsWith("/static/")) {
    e.respondWith(caches.match(req).then(r => r || fetch(req).then(res => {
      const copy = res.clone(); caches.open(VERSION).then(c => c.put(req, copy)); return res; })));
    return;
  }
  if (req.mode === "navigate") {
    e.respondWith(fetch(req).catch(() => caches.match("/offline")));
  }
});
