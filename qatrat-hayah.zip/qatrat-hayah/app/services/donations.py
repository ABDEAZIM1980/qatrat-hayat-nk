"""التقييم الطبي وتسجيل التبرعات واعتماد الوحدات.

النظام لا يتخذ أي قرار طبي: يسجّل فقط قرار المختص (اسمه وقراره) كما هو.
"""
from ..db import get_db, utcnow
from ..notifications import notify
from . import inventory
from .common import unique_code


class DonationError(Exception):
    pass


def record_assessment(appt, decision, assessed_by_name, reason, defer_until, user_id):
    db = get_db()
    if appt["status"] != "checked_in":
        raise DonationError("يجب تسجيل حضور المتبرع قبل تسجيل قرار التقييم الطبي.")
    if decision not in ("accepted", "deferred", "rejected"):
        raise DonationError("قرار غير صالح")
    with db.transaction():
        aid = db.insert("medical_assessments", {
            "appointment_id": appt["id"], "donor_id": appt["donor_id"], "decision": decision,
            "assessed_by_name": assessed_by_name, "reason": reason, "defer_until": defer_until,
            "recorded_by": user_id, "created_at": utcnow()})
        if decision != "accepted":
            db.update("appointments", appt["id"], {"status": "deferred", "updated_at": utcnow()})
    if decision != "accepted":
        donor = db.get("donors", appt["donor_id"])
        msg = "بحسب تقييم المختص في المركز لم يتم التبرع في هذه الزيارة."
        if defer_until:
            msg += f" يمكنك حجز موعد جديد بعد {defer_until}."
        msg += " شكرًا لحرصك على العطاء."
        notify(donor["user_id"], "appointment_status", "نتيجة زيارة التبرع", msg, f"/donor/appointments/{appt['id']}")
    return aid


def latest_assessment(appt_id):
    return get_db().one("SELECT * FROM medical_assessments WHERE appointment_id = ? ORDER BY id DESC LIMIT 1", (appt_id,))


def record_donation(donor, center_id, blood_type, volume_ml, donated_at, medical_decision_by, user_id,
                    appointment=None, notes=None, unit_number=None):
    db = get_db()
    if appointment is not None:
        if appointment["status"] != "checked_in":
            raise DonationError("لا يمكن تسجيل تبرع لموعد لم يتم تسجيل حضوره.")
        a = latest_assessment(appointment["id"])
        if not a or a["decision"] != "accepted":
            raise DonationError("يجب تسجيل قرار المختص بقبول التبرع قبل تسجيل العملية.")
        if db.one("SELECT id FROM donations WHERE appointment_id = ?", (appointment["id"],)):
            raise DonationError("تم تسجيل تبرع لهذا الموعد مسبقًا.")
    if unit_number:
        if db.one("SELECT id FROM donations WHERE unit_number = ?", (unit_number,)):
            raise DonationError("رقم الوحدة مسجل مسبقًا.")
    else:
        unit_number = unique_code("donations", "unit_number", "U-")
    with db.transaction():
        did = db.insert("donations", {
            "donor_id": donor["id"], "center_id": center_id, "appointment_id": appointment["id"] if appointment else None,
            "unit_number": unit_number, "blood_type": blood_type, "volume_ml": volume_ml, "donated_at": donated_at,
            "medical_decision_by": medical_decision_by, "status": "pending", "recorded_by": user_id,
            "notes": notes, "created_at": utcnow()})
        if appointment is not None:
            db.update("appointments", appointment["id"], {"status": "completed", "updated_at": utcnow()})
    notify(donor["user_id"], "appointment_status", "شكرًا لتبرعك",
           "تم تسجيل تبرعك وهو الآن قيد الفحص المخبري. سيصلك إشعار عند اعتماد الوحدة.", "/donor/donations")
    return did


def approve(donation, user_id):
    """اعتماد الوحدة بعد الفحص: يضيفها للمخزون ويحدّث سجل المتبرع."""
    db = get_db()
    if donation["status"] != "pending":
        raise DonationError("تمت معالجة هذه الوحدة مسبقًا.")
    with db.transaction():
        db.update("donations", donation["id"], {"status": "approved", "approved_by": user_id, "approved_at": utcnow()})
        inventory.apply(donation["center_id"], donation["blood_type"], "donation_in", 1, user_id,
                        f"وحدة رقم {donation['unit_number']}", ("donation", donation["id"]))
        donor = db.get("donors", donation["donor_id"])
        last = donor["last_donation_at"]
        new_last = donation["donated_at"] if not last or str(donation["donated_at"]) > str(last) else last
        db.update("donors", donor["id"], {
            "donations_count": donor["donations_count"] + 1, "last_donation_at": new_last,
            # الفصيلة المثبتة مخبريًا تحل محل الفصيلة التي أدخلها المتبرع
            "blood_type": donation["blood_type"], "blood_type_verified": 1, "updated_at": utcnow()})
    notify(donor["user_id"], "donation_approved", "تم اعتماد تبرعك",
           "تم اعتماد وحدة الدم التي تبرعت بها. قطرة منك... تنقذ حياة. شكرًا لك!", "/donor/donations")


def reject(donation, user_id, reason):
    """رفض الوحدة مخبريًا. لا يُرسل للمتبرع أي تفاصيل حساسة عبر الإشعارات؛
    يتواصل المركز معه بشكل سري عند الحاجة."""
    db = get_db()
    if donation["status"] != "pending":
        raise DonationError("تمت معالجة هذه الوحدة مسبقًا.")
    db.update("donations", donation["id"], {"status": "rejected", "rejection_reason": reason,
                                             "approved_by": user_id, "approved_at": utcnow()})
