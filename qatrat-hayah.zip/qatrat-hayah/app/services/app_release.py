"""ملف تطبيق أندرويد (APK) المنشور للجمهور: الرفع والتحقق والقراءة."""
import hashlib
import io
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from flask import current_app

APK_NAME = "qatrat-hayah.apk"
META_NAME = "release.json"


def _dir():
    p = Path(current_app.config["APP_FILES_DIR"])
    p.mkdir(parents=True, exist_ok=True)
    return p


class ReleaseError(Exception):
    pass


def _db():
    from ..db import get_db
    return get_db()


def current():
    """بيانات الإصدار المنشور، أو None إن لم يُرفع ملف.

    المصدر الأساسي قاعدة البيانات (تبقى بعد إعادة تشغيل الخادم)، والقرص نسخة مؤقتة للتنزيل السريع.
    """
    row = _db().one("SELECT meta FROM stored_files WHERE name = ?", (APK_NAME,))
    if row:
        try:
            return json.loads(row["meta"])
        except ValueError:
            return None
    # توافق مع الإصدارات القديمة التي كانت تحفظ الملف على القرص فقط
    d = _dir()
    if not (d / APK_NAME).exists() or not (d / META_NAME).exists():
        return None
    try:
        return json.loads((d / META_NAME).read_text(encoding="utf-8"))
    except ValueError:
        return None


def apk_path():
    """مسار الملف على القرص؛ يُستعاد من قاعدة البيانات إن كان مفقودًا أو قديمًا."""
    d = _dir()
    path = d / APK_NAME
    meta = current()
    if meta and meta.get("sha256"):
        ok = False
        if path.exists():
            ok = hashlib.sha256(path.read_bytes()).hexdigest() == meta["sha256"]
        if not ok:
            row = _db().one("SELECT data FROM stored_files WHERE name = ?", (APK_NAME,))
            if row and row["data"] is not None:
                tmp = d / (APK_NAME + ".tmp")
                tmp.write_bytes(bytes(row["data"]))
                os.replace(tmp, path)
    return path


def save(data, version, notes, user_name):
    if len(data) < 10 * 1024:
        raise ReleaseError("الملف صغير جدًا ولا يبدو تطبيق أندرويد صحيحًا.")
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = set(z.namelist())
    except zipfile.BadZipFile:
        raise ReleaseError("الملف ليس بصيغة APK صحيحة.")
    if "AndroidManifest.xml" not in names or not any(n.endswith(".dex") for n in names):
        raise ReleaseError("الملف لا يحتوي على مكونات تطبيق أندرويد (AndroidManifest.xml).")
    if not any(n.startswith("META-INF/") for n in names) and not data[-1024 * 64:].count(b"APK Sig Block"):
        raise ReleaseError("الملف غير موقّع. استخدم ملف APK الموقّع الناتج من PWABuilder.")
    d = _dir()
    tmp = d / (APK_NAME + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, d / APK_NAME)
    meta = {"version": version, "notes": notes, "size_mb": round(len(data) / 1024 / 1024, 1),
            "sha256": hashlib.sha256(data).hexdigest(), "uploaded_by": user_name,
            "uploaded_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")}
    meta_json = json.dumps(meta, ensure_ascii=False)
    (d / META_NAME).write_text(meta_json, encoding="utf-8")
    from ..db import utcnow
    db = _db()
    with db.transaction():
        db.execute("DELETE FROM stored_files WHERE name = ?", (APK_NAME,))
        db.execute("INSERT INTO stored_files (name, data, meta, updated_at) VALUES (?, ?, ?, ?)",
                   (APK_NAME, data, meta_json, utcnow()))
    return meta


def remove():
    _db().execute("DELETE FROM stored_files WHERE name = ?", (APK_NAME,))
    d = _dir()
    for n in (APK_NAME, META_NAME):
        if (d / n).exists():
            (d / n).unlink()
