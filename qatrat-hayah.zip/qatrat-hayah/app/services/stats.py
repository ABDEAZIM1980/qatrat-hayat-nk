"""مؤشرات لوحة التحكم ورسومها البيانية — كلها محصورة بنطاق المستخدم."""
from datetime import timedelta

from ..db import get_db
from ..rbac import center_filter, donor_filter
from ..schema import BLOOD_TYPES
from ..timeutil import local_now
from ..validators import URGENCY, URGENCY_ORDER
from .inventory import stock_status


def _months(n=12):
    now = local_now()
    y, m = now.year, now.month
    out = []
    for _ in range(n):
        out.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            m, y = 12, y - 1
    return list(reversed(out))


MONTHS_AR = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]


def month_label(ym):
    y, m = ym.split("-")
    return MONTHS_AR[int(m) - 1]


def dashboard(scope):
    db = get_db()
    cf, cp = center_filter(scope)
    df, dp = donor_filter(db, scope)
    today = local_now().date().isoformat()
    year_ago = (local_now() - timedelta(days=365)).strftime("%Y-%m-%d")
    k = {}
    k["donors"] = db.scalar(f"SELECT COUNT(*) AS n FROM donors d WHERE {df}", dp, 0)
    k["active_donors"] = db.scalar(
        f"SELECT COUNT(*) AS n FROM donors d WHERE {df} AND d.status = 'active' AND d.last_donation_at >= ?",
        [*dp, year_ago], 0)
    k["appointments_upcoming"] = db.scalar(
        f"""SELECT COUNT(*) AS n FROM appointments a JOIN blood_centers c ON c.id = a.center_id
            WHERE {cf} AND a.status IN ('booked','confirmed') AND a.appointment_date >= ?""", [*cp, today], 0)
    k["appointments_today"] = db.scalar(
        f"""SELECT COUNT(*) AS n FROM appointments a JOIN blood_centers c ON c.id = a.center_id
            WHERE {cf} AND a.appointment_date = ? AND a.status != 'cancelled'""", [*cp, today], 0)
    k["donations_approved"] = db.scalar(
        f"""SELECT COUNT(*) AS n FROM donations x JOIN blood_centers c ON c.id = x.center_id
            WHERE {cf} AND x.status = 'approved'""", cp, 0)
    k["donations_pending"] = db.scalar(
        f"""SELECT COUNT(*) AS n FROM donations x JOIN blood_centers c ON c.id = x.center_id
            WHERE {cf} AND x.status = 'pending'""", cp, 0)
    k["centers"] = db.scalar(f"SELECT COUNT(*) AS n FROM blood_centers c WHERE {cf} AND c.status = 'active'", cp, 0)
    k["open_requests"] = db.scalar(
        f"""SELECT COUNT(*) AS n FROM blood_requests r JOIN blood_centers c ON c.id = r.center_id
            WHERE {cf} AND r.status IN ('pending','approved','partially_fulfilled')""", cp, 0)
    k["open_appeals"] = db.scalar(
        f"""SELECT COUNT(*) AS n FROM emergency_appeals e JOIN blood_centers c ON c.id = e.center_id
            WHERE {cf} AND e.status = 'open'""", cp, 0)
    k["pending_appeals"] = db.scalar(
        f"""SELECT COUNT(*) AS n FROM emergency_appeals e JOIN blood_centers c ON c.id = e.center_id
            WHERE {cf} AND e.status = 'pending_approval'""", cp, 0)

    # المخزون حسب الفصيلة (مجموع المراكز ضمن النطاق)
    inv_rows = db.query(
        f"""SELECT i.* FROM blood_inventory i JOIN blood_centers c ON c.id = i.center_id
            WHERE {cf} AND c.status = 'active' AND c.center_type != 'mobile_unit'""", cp)
    inv = {bt: {"available": 0, "reserved": 0, "critical_centers": 0, "low_centers": 0, "critical_level": 0, "low_level": 0}
           for bt in BLOOD_TYPES}
    status_counts = {"available": 0, "low": 0, "critical": 0}
    for r in inv_rows:
        b = inv[r["blood_type"]]
        b["available"] += r["available_units"]
        b["reserved"] += r["reserved_units"]
        b["critical_level"] += r["critical_level"]
        b["low_level"] += r["low_level"]
        st = stock_status(r)
        status_counts[st] += 1
        if st == "critical":
            b["critical_centers"] += 1
        elif st == "low":
            b["low_centers"] += 1
    k["inventory_total"] = sum(v["available"] for v in inv.values())
    # الفصيلة حرجة إذا كان مجموعها في النطاق لا يتجاوز مجموع الحدود الحرجة للمراكز
    for v in inv.values():
        v["status"] = ("critical" if v["available"] <= v["critical_level"]
                       else "low" if v["available"] <= v["low_level"] else "available")
    critical_types = [bt for bt, v in inv.items() if v["status"] == "critical"]

    # الرسوم البيانية
    months = _months(12)
    mexpr = db.month_expr("x.donated_at")
    by_month = {r["m"]: r["n"] for r in db.query(
        f"""SELECT {mexpr} AS m, COUNT(*) AS n FROM donations x JOIN blood_centers c ON c.id = x.center_id
            WHERE {cf} AND x.status = 'approved' AND x.donated_at >= ? GROUP BY {mexpr}""",
        [*cp, months[0] + "-01"])}
    by_gov = db.query(
        f"""SELECT g.name_ar AS label, COUNT(*) AS n FROM donations x JOIN blood_centers c ON c.id = x.center_id
            JOIN governorates g ON g.id = c.governorate_id
            WHERE {cf} AND x.status = 'approved' GROUP BY g.name_ar ORDER BY n DESC""", cp)
    by_type = {r["blood_type"]: r["n"] for r in db.query(
        f"""SELECT x.blood_type, COUNT(*) AS n FROM donations x JOIN blood_centers c ON c.id = x.center_id
            WHERE {cf} AND x.status = 'approved' GROUP BY x.blood_type""", cp)}
    by_urg = {r["urgency"]: r["n"] for r in db.query(
        f"""SELECT r.urgency, COUNT(*) AS n FROM blood_requests r JOIN blood_centers c ON c.id = r.center_id
            WHERE {cf} AND r.status IN ('pending','approved','partially_fulfilled') GROUP BY r.urgency""", cp)}
    charts = {
        "by_month": [{"label": month_label(m), "sub": m[:4], "value": by_month.get(m, 0)} for m in months],
        "by_governorate": [{"label": r["label"], "value": r["n"]} for r in by_gov],
        "by_blood_type": [{"label": bt, "value": by_type.get(bt, 0)} for bt in BLOOD_TYPES],
        "by_urgency": [{"label": URGENCY[u], "value": by_urg.get(u, 0), "key": u} for u in URGENCY_ORDER],
        "inventory_status": status_counts,
    }
    return {"kpi": k, "inventory": inv, "critical_types": critical_types, "charts": charts}


def public_summary():
    """أرقام عامة للصفحة الرئيسية (لا تتضمن أي بيانات شخصية)."""
    db = get_db()
    return {
        "centers": db.scalar("SELECT COUNT(*) AS n FROM blood_centers WHERE status = 'active'", (), 0),
        "donors": db.scalar("SELECT COUNT(*) AS n FROM donors WHERE status = 'active'", (), 0),
        "donations": db.scalar("SELECT COUNT(*) AS n FROM donations WHERE status = 'approved'", (), 0),
        "governorates": db.scalar("SELECT COUNT(*) AS n FROM governorates WHERE is_active = 1", (), 0),
    }
