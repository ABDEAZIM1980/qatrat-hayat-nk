"""طلبات الدم والنداءات العاجلة."""
from ..db import get_db, utcnow
from ..notifications import notify, notify_center_staff
from ..validators import URGENCY
from . import inventory
from .common import unique_code


class WorkflowError(Exception):
    pass


# ---------------- طلبات الدم ----------------
def create_request(data, user_id):
    db = get_db()
    now = utcnow()
    rid = db.insert("blood_requests", {
        "request_code": unique_code("blood_requests", "request_code", "BR-"),
        "blood_type": data["blood_type"], "units_required": data["units_required"], "units_fulfilled": 0,
        "center_id": data["center_id"], "requesting_entity": data["requesting_entity"],
        "patient_reference": data.get("patient_reference"), "urgency": data["urgency"], "status": "pending",
        "needed_by": data.get("needed_by"), "notes": data.get("notes"), "requested_by": user_id,
        "created_at": now, "updated_at": now})
    notify_center_staff(data["center_id"], "request_status", "طلب دم جديد بانتظار الاعتماد",
                        f"طلب {data['units_required']} وحدة من فصيلة \u2066{data['blood_type']}\u2069 — "
                        f"درجة الاستعجال: {URGENCY[data['urgency']]}.", f"/admin/requests/{rid}")
    return rid


def approve_request(req, user_id):
    if req["status"] != "pending":
        raise WorkflowError("لا يمكن اعتماد هذا الطلب في حالته الحالية.")
    get_db().update("blood_requests", req["id"], {"status": "approved", "approved_by": user_id,
                                                   "approved_at": utcnow(), "updated_at": utcnow()})
    if req["requested_by"] != user_id:
        notify(req["requested_by"], "request_status", "تم اعتماد طلب الدم",
               f"تم اعتماد الطلب {req['request_code']}.", f"/admin/requests/{req['id']}", respect_prefs=False)


def reject_request(req, user_id, reason):
    if req["status"] != "pending":
        raise WorkflowError("لا يمكن رفض هذا الطلب في حالته الحالية.")
    notes = ((req["notes"] or "") + f"\nسبب الرفض: {reason}").strip()
    get_db().update("blood_requests", req["id"], {"status": "rejected", "approved_by": user_id,
                                                   "approved_at": utcnow(), "notes": notes[:1000], "updated_at": utcnow()})
    notify(req["requested_by"], "request_status", "تم رفض طلب الدم",
           f"الطلب {req['request_code']}: {reason}", f"/admin/requests/{req['id']}", respect_prefs=False)


def cancel_request(req, reason):
    if req["status"] in ("fulfilled", "rejected", "cancelled"):
        raise WorkflowError("لا يمكن إلغاء هذا الطلب.")
    notes = ((req["notes"] or "") + f"\nسبب الإلغاء: {reason}").strip()
    get_db().update("blood_requests", req["id"], {"status": "cancelled", "notes": notes[:1000], "updated_at": utcnow()})


def fulfill_request(req, issue_center_id, blood_type, units, user_id):
    """صرف وحدات من المخزون لطلب معتمد. اختيار الفصيلة المصروفة قرار مخبري يُدخله المختص."""
    if req["status"] not in ("approved", "partially_fulfilled"):
        raise WorkflowError("يجب اعتماد الطلب قبل صرف الوحدات.")
    remaining = req["units_required"] - req["units_fulfilled"]
    if units > remaining:
        raise WorkflowError(f"المتبقي من الطلب {remaining} وحدة فقط.")
    db = get_db()
    with db.transaction():
        try:
            inventory.apply(issue_center_id, blood_type, "issue_out", units, user_id,
                            f"صرف للطلب {req['request_code']}", ("blood_request", req["id"]))
        except inventory.InventoryError as e:
            raise WorkflowError(str(e))
        done = req["units_fulfilled"] + units
        db.update("blood_requests", req["id"], {
            "units_fulfilled": done, "status": "fulfilled" if done >= req["units_required"] else "partially_fulfilled",
            "updated_at": utcnow()})
    return done


# ---------------- النداءات العاجلة ----------------
def create_appeal(data, user_id):
    now = utcnow()
    return get_db().insert("emergency_appeals", {
        "title": data["title"], "blood_type": data["blood_type"], "units_needed": data["units_needed"],
        "units_collected": 0, "urgency": data["urgency"], "center_id": data["center_id"],
        "blood_request_id": data.get("blood_request_id"), "message": data.get("message"),
        "status": "pending_approval", "created_by": user_id, "expires_at": data.get("expires_at"),
        "created_at": now, "updated_at": now})


def publish_appeal(appeal, user_id):
    """اعتماد ونشر النداء، ثم إشعار المتبرعين النشطين من نفس الفصيلة في الولاية."""
    if appeal["status"] != "pending_approval":
        raise WorkflowError("هذا النداء ليس بانتظار الاعتماد.")
    db = get_db()
    now = utcnow()
    db.update("emergency_appeals", appeal["id"], {"status": "open", "approved_by": user_id, "published_at": now,
                                                   "updated_at": now})
    center = db.get("blood_centers", appeal["center_id"])
    donors = db.query(
        """SELECT d.user_id FROM donors d JOIN users u ON u.id = d.user_id
           WHERE d.status = 'active' AND u.status = 'active' AND d.blood_type = ? AND d.governorate_id = ?""",
        (appeal["blood_type"], center["governorate_id"]))
    n = notify([d["user_id"] for d in donors], "emergency_appeal", f"نداء عاجل: {appeal['title']}",
               f"يحتاج {center['name']} إلى {appeal['units_needed']} وحدة من فصيلة \u2066{appeal['blood_type']}\u2069. "
               "احجز موعدًا إذا كنت قادرًا على التبرع؛ القرار النهائي للمختصين في المركز.",
               f"/appeals/{appeal['id']}")
    if appeal["created_by"] != user_id:
        notify(appeal["created_by"], "admin", "تم نشر النداء العاجل", appeal["title"], f"/admin/appeals/{appeal['id']}",
               respect_prefs=False)
    return n


def reject_appeal(appeal, user_id, reason):
    if appeal["status"] != "pending_approval":
        raise WorkflowError("هذا النداء ليس بانتظار الاعتماد.")
    get_db().update("emergency_appeals", appeal["id"], {"status": "rejected", "approved_by": user_id,
                                                         "updated_at": utcnow()})
    notify(appeal["created_by"], "admin", "لم يتم اعتماد النداء", f"{appeal['title']}: {reason}",
           f"/admin/appeals/{appeal['id']}", respect_prefs=False)


def update_appeal_progress(appeal, collected, new_status=None):
    if appeal["status"] != "open":
        raise WorkflowError("يمكن تحديث النداءات المفتوحة فقط.")
    data = {"units_collected": collected, "updated_at": utcnow()}
    if new_status in ("completed", "closed"):
        data["status"] = new_status
        data["closed_at"] = utcnow()
    elif collected >= appeal["units_needed"]:
        data["status"] = "completed"
        data["closed_at"] = utcnow()
    get_db().update("emergency_appeals", appeal["id"], data)


def expire_appeals():
    """إغلاق النداءات المنتهية تلقائيًا (cron)."""
    from ..timeutil import local_today
    db = get_db()
    cur = db.execute("UPDATE emergency_appeals SET status = 'closed', closed_at = ?, updated_at = ? "
                     "WHERE status = 'open' AND expires_at IS NOT NULL AND expires_at < ?",
                     (utcnow(), utcnow(), local_today().isoformat()))
    return cur.rowcount
