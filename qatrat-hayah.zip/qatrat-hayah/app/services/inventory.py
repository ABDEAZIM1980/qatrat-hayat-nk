"""إدارة مخزون الدم: كل تغيير يمر عبر حركة (transaction) موثقة ولا يُعدّل الرصيد مباشرة."""
from ..db import get_db, utcnow
from ..schema import BLOOD_TYPES
from .common import get_int_setting


class InventoryError(Exception):
    pass


def stock_status(row):
    a = row["available_units"]
    if a <= row["critical_level"]:
        return "critical"
    if a <= row["low_level"]:
        return "low"
    return "available"


def ensure_center_inventory(center_id):
    db = get_db()
    existing = {r["blood_type"] for r in db.query("SELECT blood_type FROM blood_inventory WHERE center_id = ?", (center_id,))}
    crit = get_int_setting("default_critical_level", 3)
    low = get_int_setting("default_low_level", 8)
    for bt in BLOOD_TYPES:
        if bt not in existing:
            db.insert("blood_inventory", {"center_id": center_id, "blood_type": bt, "available_units": 0,
                                          "reserved_units": 0, "critical_level": crit, "low_level": low,
                                          "updated_at": utcnow()})


def get_row(center_id, blood_type):
    ensure_center_inventory(center_id)
    return get_db().one("SELECT * FROM blood_inventory WHERE center_id = ? AND blood_type = ?", (center_id, blood_type))


def apply(center_id, blood_type, tx_type, quantity, user_id=None, reason=None, reference=(None, None)):
    """ينفذ حركة مخزون بشكل ذرّي ويُرجع السجل بعد التحديث."""
    if blood_type not in BLOOD_TYPES:
        raise InventoryError("فصيلة غير صالحة")
    if not isinstance(quantity, int) or quantity <= 0:
        raise InventoryError("الكمية يجب أن تكون رقمًا موجبًا")
    db = get_db()
    with db.transaction():
        row = get_row(center_id, blood_type)
        avail, resv = row["available_units"], row["reserved_units"]
        if tx_type in ("donation_in", "transfer_in"):
            avail += quantity
        elif tx_type in ("issue_out", "expire", "discard", "transfer_out"):
            if quantity > avail:
                raise InventoryError(f"الكمية المتاحة من {blood_type} ({avail}) أقل من المطلوب ({quantity}).")
            avail -= quantity
        elif tx_type == "reserve":
            if quantity > avail:
                raise InventoryError(f"لا يمكن حجز {quantity} وحدة؛ المتاح {avail} فقط.")
            avail -= quantity
            resv += quantity
        elif tx_type == "release":
            if quantity > resv:
                raise InventoryError(f"المحجوز حاليًا {resv} وحدة فقط.")
            resv -= quantity
            avail += quantity
        elif tx_type == "issue_reserved":
            if quantity > resv:
                raise InventoryError(f"المحجوز حاليًا {resv} وحدة فقط.")
            resv -= quantity
            tx_type = "issue_out"
        else:
            raise InventoryError("نوع الحركة غير معروف")
        now = utcnow()
        db.execute("UPDATE blood_inventory SET available_units = ?, reserved_units = ?, updated_at = ?, updated_by = ? WHERE id = ?",
                   (avail, resv, now, user_id, row["id"]))
        db.insert("blood_inventory_transactions", {
            "inventory_id": row["id"], "center_id": center_id, "blood_type": blood_type, "tx_type": tx_type,
            "quantity": quantity, "available_after": avail, "reserved_after": resv,
            "reference_type": reference[0], "reference_id": reference[1], "reason": reason,
            "created_by": user_id, "created_at": now})
    return db.get("blood_inventory", row["id"])


def stocktake(center_id, blood_type, counted, user_id, reason):
    """تسوية جرد: يضبط الرصيد المتاح على العدد الفعلي."""
    if not isinstance(counted, int) or counted < 0:
        raise InventoryError("العدد الفعلي غير صالح")
    db = get_db()
    with db.transaction():
        row = get_row(center_id, blood_type)
        diff = counted - row["available_units"]
        if diff == 0:
            return row
        now = utcnow()
        db.execute("UPDATE blood_inventory SET available_units = ?, updated_at = ?, updated_by = ? WHERE id = ?",
                   (counted, now, user_id, row["id"]))
        db.insert("blood_inventory_transactions", {
            "inventory_id": row["id"], "center_id": center_id, "blood_type": blood_type, "tx_type": "adjust",
            "quantity": abs(diff), "available_after": counted, "reserved_after": row["reserved_units"],
            "reference_type": None, "reference_id": None,
            "reason": f"{'زيادة' if diff > 0 else 'نقص'} {abs(diff)} — {reason}", "created_by": user_id, "created_at": now})
    return db.get("blood_inventory", row["id"])


def transfer(from_center, to_center, blood_type, quantity, user_id, reason):
    if from_center == to_center:
        raise InventoryError("لا يمكن التحويل إلى نفس المركز")
    db = get_db()
    with db.transaction():
        apply(from_center, blood_type, "transfer_out", quantity, user_id, reason, ("center", to_center))
        apply(to_center, blood_type, "transfer_in", quantity, user_id, reason, ("center", from_center))


def set_thresholds(center_id, blood_type, critical, low, user_id):
    if critical < 0 or low < critical:
        raise InventoryError("الحد المنخفض يجب أن يكون أكبر من أو يساوي الحد الحرج")
    row = get_row(center_id, blood_type)
    get_db().execute("UPDATE blood_inventory SET critical_level = ?, low_level = ?, updated_at = ?, updated_by = ? WHERE id = ?",
                     (critical, low, utcnow(), user_id, row["id"]))
