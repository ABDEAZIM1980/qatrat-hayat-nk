"""النسخ الاحتياطي لقاعدة البيانات.

- SQLite: نسخة متسقة عبر sqlite3 backup API (آمنة أثناء التشغيل) ثم ضغطها gzip.
- PostgreSQL: pg_dump بصيغة custom.
تُحذف النسخ الأقدم تلقائيًا حسب QH_BACKUP_RETENTION. يُنصح بنسخ مجلد النسخ خارج الخادم يوميًا.
"""
import gzip
import os
import shutil
import sqlite3
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from flask import current_app


def backup_dir():
    p = Path(current_app.config["BACKUP_DIR"])
    p.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(p, 0o700)
    except OSError:
        pass
    return p


def create_backup():
    url = current_app.config["DATABASE_URL"]
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    out_dir = backup_dir()
    if url.startswith("sqlite:///"):
        src = url[len("sqlite:///"):]
        tmp = out_dir / f"qatrat-{stamp}.db"
        s = sqlite3.connect(src)
        d = sqlite3.connect(tmp)
        with d:
            s.backup(d)
        s.close(); d.close()
        final = out_dir / f"qatrat-{stamp}.db.gz"
        with open(tmp, "rb") as fi, gzip.open(final, "wb") as fo:
            shutil.copyfileobj(fi, fo)
        tmp.unlink()
    elif shutil.which("pg_dump"):
        final = out_dir / f"qatrat-{stamp}.dump"
        subprocess.run(["pg_dump", "--format=custom", f"--file={final}", url], check=True)
    else:
        # الاستضافة المجانية غالبًا بلا pg_dump: نسخة بيانات محمولة (JSON) قابلة للاستعادة بأمر restore-json
        final = out_dir / f"qatrat-{stamp}.json.zip"
        final.write_bytes(export_json())
    os.chmod(final, 0o600)
    prune()
    return final


def list_backups():
    d = backup_dir()
    files = sorted([f for f in d.iterdir() if f.name.startswith("qatrat-")], key=lambda f: f.stat().st_mtime, reverse=True)
    return [{"name": f.name, "size_kb": round(f.stat().st_size / 1024, 1),
             "created": datetime.fromtimestamp(f.stat().st_mtime, timezone.utc).strftime("%Y-%m-%d %H:%M:%S")}
            for f in files]


def prune():
    keep = current_app.config.get("BACKUP_RETENTION", 30)
    files = sorted([f for f in backup_dir().iterdir() if f.name.startswith("qatrat-")], key=lambda f: f.stat().st_mtime,
                   reverse=True)
    for f in files[keep:]:
        f.unlink()


# ---------------- نسخة محمولة بصيغة JSON (تعمل مع SQLite و PostgreSQL) ----------------
TABLE_ORDER = [
    "roles", "permissions", "role_permissions", "governorates", "localities", "cities", "users", "blood_centers",
    "blood_banks", "center_schedules", "user_roles", "donors", "donor_profiles", "appointments", "donations",
    "medical_assessments", "blood_requests", "emergency_appeals", "blood_inventory", "blood_inventory_transactions",
    "notifications", "notification_outbox", "educational_content", "audit_logs", "reports", "system_settings",
    "password_resets",
]


def export_json():
    """يصدّر كل الجداول إلى ملف zip (جدول لكل ملف JSON)."""
    import io
    import json
    import zipfile
    from ..db import get_db
    db = get_db()
    buf = io.BytesIO()
    version = db.scalar("SELECT MAX(version) AS v FROM schema_migrations", (), 0)
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps({"app": "qatrat-hayah", "schema_version": version,
                                                "created_utc": datetime.now(timezone.utc).isoformat(),
                                                "tables": TABLE_ORDER}, ensure_ascii=False))
        for t in TABLE_ORDER:
            rows = db.query(f"SELECT * FROM {t}")
            z.writestr(f"{t}.json", json.dumps(rows, ensure_ascii=False, default=str))
    return buf.getvalue()


def restore_json(path):
    """يستعيد نسخة JSON إلى قاعدة البيانات الحالية (يستبدل كل البيانات). يُرجع عدد الصفوف."""
    import json
    import zipfile
    from ..db import get_db
    db = get_db()
    total = 0
    with zipfile.ZipFile(path) as z:
        manifest = json.loads(z.read("manifest.json"))
        if manifest.get("app") != "qatrat-hayah":
            raise ValueError("الملف ليس نسخة احتياطية لقطرة حياة")
        with db.transaction():
            for t in reversed(TABLE_ORDER):
                db.execute(f"DELETE FROM {t}")
            for t in TABLE_ORDER:
                if f"{t}.json" not in z.namelist():
                    continue
                for row in json.loads(z.read(f"{t}.json")):
                    row = {k: (json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else v) for k, v in row.items()}
                    cols = list(row)
                    db.execute(f"INSERT INTO {t} ({', '.join(cols)}) VALUES ({', '.join('?' for _ in cols)})",
                               [row[c] for c in cols])
                    total += 1
        if db.dialect == "postgres":
            for t in TABLE_ORDER:
                if t in ("role_permissions", "system_settings"):
                    continue
                db.execute(f"SELECT setval(pg_get_serial_sequence('{t}', 'id'), COALESCE((SELECT MAX(id) FROM {t}), 0) + 1, false)")
    return total
