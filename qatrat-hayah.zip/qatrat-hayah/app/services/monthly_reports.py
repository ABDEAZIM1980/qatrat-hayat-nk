"""التقرير الشهري لبنك الدم.

يتبع استمارة الإدارة العامة لخدمات نقل الدم:
  1) فحوصات الأمراض المنقولة بالدم (HIV / HBV / HCV / VDRL × RAPID / ELISA × متفاعل / غير متفاعل)
  2) كمية الدم ومشتقاته المنقولة للمرضى حسب الأقسام والمستشفيات
  3) حملات التبرع الطوعي بالدم
  4) الوحدات الصحية التي تخدمها خدمات نقل الدم وحجم الخدمة المقدمة

تُحفظ القيم كـ JSON: الخانة الفارغة = None (تظهر فارغة في التقرير كما في الاستمارة الورقية)، والصفر يُحفظ صفرًا.
أسماء الأقسام والمستشفيات ليست ثابتة في البرمجة: كل بنك دم يكتب أقسامه، وتُقترح عليه في الشهر التالي.
"""
import json
from datetime import datetime

from ..db import get_db
from ..timeutil import local_to_utc_str

MONTHS_AR = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"]
QUARTERS_AR = {1: "الربع الأول", 2: "الربع الثاني", 3: "الربع الثالث", 4: "الربع الرابع"}

DISEASES = ["HIV", "HBV", "HCV", "VDRL"]
METHODS = [("rapid", "RAPID"), ("elisa", "ELISA")]
RESULTS = [("r", "Reactive"), ("n", "Non-Rea")]
COMPONENTS = [("whole", "Whole blood"), ("platelet", "Platelet"), ("plasma", "Plasma"), ("prbc", "Packed RBCs")]
DEFAULT_DEPARTMENTS = ["الحوادث العامة", "الأطفال", "مركز غسيل الكلى", "الباطنية", "الجراحة", "نساء وتوليد"]
UNIT_TYPES = [("teaching", "تعليمي"), ("university", "جامعي"), ("military", "عسكري"), ("police", "شرطة"),
              ("specialized", "تخصصي"), ("rural", "ريفي"), ("private", "خاص")]
# (المفتاح، الاسم، المجموعة) بنفس ترتيب الاستمارة
SERVICE_FIELDS = [
    ("groupings", "عدد الفصائل", None),
    ("donors_voluntary", "طوعي", "عدد المتبرعين"), ("donors_family", "عائلي", "عدد المتبرعين"),
    ("donors_paid", "مدفوع الأجر", "عدد المتبرعين"),
    ("blood_out", "الصادر", "حركة الدم"), ("blood_in", "الوارد", "حركة الدم"),
    ("bottles_normal", "طبيعي", "عدد الزجاجات"), ("bottles_urgent", "مستعجل", "عدد الزجاجات"),
    ("reactive", "المتفاعلة", None), ("expired", "التالف", None),
]
MAX_VALUE = 1_000_000
EXTRA_DEPT_ROWS = 3
MIN_CAMPAIGN_ROWS = 5
MAX_ROWS = 60


# ---------------- البنية الفارغة ----------------
def empty_data():
    return {
        "tti": {d: {m: {r: None for r, _ in RESULTS} for m, _ in METHODS} for d in DISEASES},
        "transfusion": [{"dept": name, **{c: None for c, _ in COMPONENTS}} for name in DEFAULT_DEPARTMENTS],
        "campaigns": [],
        "units": {k: None for k, _ in UNIT_TYPES},
        "service": {k: None for k, _, _ in SERVICE_FIELDS},
    }


def load(row):
    """يقرأ بيانات التقرير ويكمل أي مفاتيح ناقصة (توافق مع إصدارات لاحقة من الاستمارة)."""
    base = empty_data()
    try:
        d = json.loads(row["data"]) if isinstance(row["data"], str) else (row["data"] or {})
    except ValueError:
        d = {}
    for dis in DISEASES:
        for m, _ in METHODS:
            for r, _ in RESULTS:
                base["tti"][dis][m][r] = _num((((d.get("tti") or {}).get(dis) or {}).get(m) or {}).get(r))
    if isinstance(d.get("transfusion"), list):
        base["transfusion"] = [{"dept": str(x.get("dept") or "")[:80], **{c: _num(x.get(c)) for c, _ in COMPONENTS}}
                               for x in d["transfusion"] if isinstance(x, dict)]
    if isinstance(d.get("campaigns"), list):
        base["campaigns"] = [{"org": str(x.get("org") or "")[:100], "days": _num(x.get("days")), "units": _num(x.get("units")),
                              "locality": str(x.get("locality") or "")[:80]} for x in d["campaigns"] if isinstance(x, dict)]
    for k, _ in UNIT_TYPES:
        base["units"][k] = _num((d.get("units") or {}).get(k))
    for k, _, _ in SERVICE_FIELDS:
        base["service"][k] = _num((d.get("service") or {}).get(k))
    return base


def _num(v):
    if v is None or v == "":
        return None
    try:
        n = int(v)
    except (TypeError, ValueError):
        return None
    return n if 0 <= n <= MAX_VALUE else None


def dumps(data):
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


# ---------------- المجاميع ----------------
def _s(*vals):
    return sum(v or 0 for v in vals)


def totals(data):
    t = {"tti": {d: _s(*(data["tti"][d][m][r] for m, _ in METHODS for r, _ in RESULTS)) for d in DISEASES}}
    t["tti_all"] = sum(t["tti"].values())
    t["transfusion"] = {c: _s(*(row[c] for row in data["transfusion"])) for c, _ in COMPONENTS}
    t["transfusion_all"] = sum(t["transfusion"].values())
    t["campaign_units"] = _s(*(c["units"] for c in data["campaigns"]))
    t["campaign_days"] = _s(*(c["days"] for c in data["campaigns"]))
    t["units_all"] = _s(*data["units"].values())
    s = data["service"]
    t["donors_all"] = _s(s["donors_voluntary"], s["donors_family"], s["donors_paid"])
    return t


# ---------------- قراءة الاستمارة ----------------
def form_rows(data):
    """صفوف الاستمارة: الأقسام الحالية + صفوف فارغة لإضافة أقسام جديدة، وحملات + صفوف فارغة."""
    depts = list(data["transfusion"]) + [{"dept": "", **{c: None for c, _ in COMPONENTS}} for _ in range(EXTRA_DEPT_ROWS)]
    camps = list(data["campaigns"])
    camps += [{"org": "", "days": None, "units": None, "locality": ""}
              for _ in range(max(MIN_CAMPAIGN_ROWS - len(camps), 2))]
    return depts[:MAX_ROWS], camps[:MAX_ROWS]


def parse_form(form):
    """يحوّل حقول الاستمارة إلى بيانات التقرير. يُرجع (data, errors) حيث errors قائمة رسائل."""
    errors = []

    def num(name, label):
        raw = (form.get(name) or "").strip()
        raw = raw.translate(str.maketrans("٠١٢٣٤٥٦٧٨٩", "0123456789"))
        if raw == "":
            return None
        if not raw.isdigit() or len(raw) > 7 or int(raw) > MAX_VALUE:
            errors.append(f"«{label}»: أدخل رقمًا صحيحًا من 0 إلى {MAX_VALUE:,}.")
            return None
        return int(raw)

    def text(name, max_len):
        return " ".join((form.get(name) or "").split())[:max_len]

    data = empty_data()
    for d in DISEASES:
        for m, ml in METHODS:
            for r, rl in RESULTS:
                data["tti"][d][m][r] = num(f"tti__{d}__{m}__{r}", f"{d} {ml} {rl}")

    data["transfusion"] = []
    n = min(_count(form.get("dept_count")), MAX_ROWS)
    seen = set()
    for i in range(n):
        name = text(f"dept_name_{i}", 80)
        vals = {c: num(f"dept_{c}_{i}", f"{name or 'قسم'} — {cl}") for c, cl in COMPONENTS}
        if not name:
            if any(v is not None for v in vals.values()):
                errors.append(f"اكتب اسم القسم أو المستشفى في الصف {i + 1} من جدول «كمية الدم ومشتقاته».")
            continue
        if name in seen:
            errors.append(f"القسم «{name}» مكرر في جدول «كمية الدم ومشتقاته». اجمع أرقامه في صف واحد.")
            continue
        seen.add(name)
        data["transfusion"].append({"dept": name, **vals})

    data["campaigns"] = []
    n = min(_count(form.get("camp_count")), MAX_ROWS)
    for i in range(n):
        org = text(f"camp_org_{i}", 100)
        loc = text(f"camp_loc_{i}", 80)
        days = num(f"camp_days_{i}", f"عدد الأيام (الحملة {i + 1})")
        units = num(f"camp_units_{i}", f"عدد الوحدات (الحملة {i + 1})")
        if not org:
            if days is not None or units is not None or loc:
                errors.append(f"اكتب الجهة المنفذة في الصف {i + 1} من جدول «التبرع الطوعي بالدم».")
            continue
        data["campaigns"].append({"org": org, "days": days, "units": units, "locality": loc})

    for k, kl in UNIT_TYPES:
        data["units"][k] = num(f"unit_{k}", f"عدد الوحدات الصحية — {kl}")
    for k, kl, grp in SERVICE_FIELDS:
        data["service"][k] = num(f"svc_{k}", f"{grp} — {kl}" if grp else kl)
    return data, errors


def _count(v):
    try:
        return max(0, int(v))
    except (TypeError, ValueError):
        return 0


def missing_for_submit(data):
    """تحقق خفيف قبل الإرسال: تقرير بلا أي رقم على الإطلاق لا يُرسل."""
    t = totals(data)
    any_service = any(v is not None for v in data["service"].values())
    if not (t["tti_all"] or t["transfusion_all"] or t["campaign_units"] or any_service or t["units_all"]):
        return "التقرير فارغ. أدخل أرقام الشهر قبل الإرسال."
    return None


# ---------------- التجميع لعدة أشهر أو عدة بنوك دم ----------------
def aggregate(rows):
    """يجمع تقارير (صفوف monthly_reports مع center_name) في تقرير واحد.

    القيم الشهرية تُجمع. عدد الوحدات الصحية رصيد وليس حركة: يُؤخذ آخر شهر لكل بنك دم ثم يُجمع بين البنوك.
    """
    out = empty_data()
    out["transfusion"] = []
    order, by_dept = [], {}
    latest_units = {}
    for r in sorted(rows, key=lambda x: (x["year"], x["month"])):
        d = load(r)
        for dis in DISEASES:
            for m, _ in METHODS:
                for res, _ in RESULTS:
                    v = d["tti"][dis][m][res]
                    if v is not None:
                        out["tti"][dis][m][res] = (out["tti"][dis][m][res] or 0) + v
        for row in d["transfusion"]:
            key = row["dept"]
            if key not in by_dept:
                by_dept[key] = {"dept": key, **{c: None for c, _ in COMPONENTS}}
                order.append(key)
            for c, _ in COMPONENTS:
                if row[c] is not None:
                    by_dept[key][c] = (by_dept[key][c] or 0) + row[c]
        for c in d["campaigns"]:
            out["campaigns"].append({**c, "center": r.get("center_name"), "period": f"{MONTHS_AR[r['month'] - 1]} {r['year']}"})
        for k, _, _ in SERVICE_FIELDS:
            v = d["service"][k]
            if v is not None:
                out["service"][k] = (out["service"][k] or 0) + v
        if any(v is not None for v in d["units"].values()):
            latest_units[r["center_id"]] = d["units"]
    out["transfusion"] = [by_dept[k] for k in order]
    for units in latest_units.values():
        for k, _ in UNIT_TYPES:
            if units[k] is not None:
                out["units"][k] = (out["units"][k] or 0) + units[k]
    return out


# ---------------- اقتراحات من بيانات المنصة ----------------
def month_bounds_utc(year, month):
    start = datetime(year, month, 1)
    end = datetime(year + (month == 12), month % 12 + 1, 1)
    return local_to_utc_str(start), local_to_utc_str(end)


def platform_figures(center_id, year, month):
    """أرقام الشهر المسجلة في المنصة نفسها، تُعرض كمرجع وتُستخدم في «التعبئة من بيانات المنصة»."""
    db = get_db()
    a, b = month_bounds_utc(year, month)
    donations = db.scalar("SELECT COUNT(*) AS n FROM donations WHERE center_id = ? AND status = 'approved' "
                          "AND donated_at >= ? AND donated_at < ?", (center_id, a, b), 0)
    tx = {r["tx_type"]: r["q"] for r in db.query(
        "SELECT tx_type, SUM(quantity) AS q FROM blood_inventory_transactions WHERE center_id = ? "
        "AND created_at >= ? AND created_at < ? GROUP BY tx_type", (center_id, a, b))}
    return {
        "donations": int(donations or 0),
        "issued": int(tx.get("issue_out") or 0),
        "transfer_in": int(tx.get("transfer_in") or 0),
        "transfer_out": int(tx.get("transfer_out") or 0),
        "expired": int((tx.get("expire") or 0) + (tx.get("discard") or 0)),
    }


def apply_platform_figures(data, figs):
    """يملأ الخانات الفارغة فقط، ولا يغيّر أي رقم أدخله بنك الدم."""
    s = data["service"]
    filled = []
    for key, val, label in (("donors_voluntary", figs["donations"], "المتبرعون (طوعي)"),
                            ("blood_in", figs["transfer_in"], "الوارد"), ("blood_out", figs["transfer_out"], "الصادر"),
                            ("expired", figs["expired"], "التالف")):
        if s[key] is None and val:
            s[key] = val
            filled.append(label)
    return filled


# ---------------- الفترات ----------------
def period_months(year, period):
    """period: 'm1'..'m12' أو 'q1'..'q4' أو 'h1','h2' أو 'y'. يُرجع (قائمة الأشهر، الاسم)."""
    if period and period[0] == "m" and period[1:].isdigit() and 1 <= int(period[1:]) <= 12:
        m = int(period[1:])
        return [m], f"شهر {MONTHS_AR[m - 1]} {year}م"
    if period and period[0] == "q" and period[1:] in ("1", "2", "3", "4"):
        q = int(period[1:])
        return list(range(3 * q - 2, 3 * q + 1)), f"{QUARTERS_AR[q]} {year}م"
    if period == "h1":
        return list(range(1, 7)), f"النصف الأول {year}م"
    if period == "h2":
        return list(range(7, 13)), f"النصف الثاني {year}م"
    return list(range(1, 13)), f"عام {year}م"


def period_choices():
    out = [(f"m{i}", MONTHS_AR[i - 1]) for i in range(1, 13)]
    out += [(f"q{q}", QUARTERS_AR[q]) for q in range(1, 5)]
    out += [("h1", "النصف الأول"), ("h2", "النصف الثاني"), ("y", "السنة كاملة")]
    return out


def to_xlsx(title, subtitle, data):
    """تصدير التقرير (فردي أو مجمّع) إلى Excel بنفس أقسام الاستمارة."""
    import io
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "التقرير الشهري"
    ws.sheet_view.rightToLeft = True
    thin = Side(style="thin", color="9AA5B1")
    box = Border(left=thin, right=thin, top=thin, bottom=thin)
    head = PatternFill("solid", fgColor="F5EBD3")
    sub = PatternFill("solid", fgColor="E8EEF6")
    bold = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    row = [1]

    def line(values, fill=None, font=None):
        ws.append(values)
        r = ws.max_row
        for i, _ in enumerate(values, start=1):
            c = ws.cell(row=r, column=i)
            c.border = box
            c.alignment = center
            if fill:
                c.fill = fill
            if font:
                c.font = font
        row[0] = r

    ws.append([title]); ws.cell(row=ws.max_row, column=1).font = Font(bold=True, size=14, color="B71C1C")
    ws.append([subtitle]); ws.append([])
    t = totals(data)

    line(["إجمالي عدد الفحوصات للأمراض المنقولة بمختبر بنك الدم"], head, bold)
    line(["المرض", "الطريقة", "Reactive", "Non-Reactive", "الإجمالي"], sub, bold)
    for d in DISEASES:
        for m, ml in METHODS:
            v = data["tti"][d][m]
            line([d, ml, v["r"], v["n"], _s(v["r"], v["n"])])
        line([d, "الإجمالي", "", "", t["tti"][d]], head, bold)
    ws.append([])

    line(["كمية الدم ومشتقاته المنقولة للمرضى"], head, bold)
    line(["الأقسام"] + [cl for _, cl in COMPONENTS], sub, bold)
    for r in data["transfusion"]:
        line([r["dept"]] + [r[c] for c, _ in COMPONENTS])
    line(["المجموع"] + [t["transfusion"][c] for c, _ in COMPONENTS], head, bold)
    ws.append([])

    line(["التبرع الطوعي بالدم"], head, bold)
    has_center = any(c.get("center") for c in data["campaigns"])
    line(["الجهة المنفذة", "عدد الأيام", "عدد الوحدات", "المحلية"] + (["بنك الدم", "الشهر"] if has_center else []), sub, bold)  # Excel: عمودان منفصلان للفرز
    for c in data["campaigns"]:
        line([c["org"], c["days"], c["units"], c["locality"]] + ([c.get("center"), c.get("period")] if has_center else []))
    line(["المجموع", t["campaign_days"], t["campaign_units"], ""], head, bold)
    ws.append([])

    line(["عدد الوحدات الصحية التي بها خدمات نقل الدم وحجم ونوع الخدمة المقدمة"], head, bold)
    line([f"عدد الوحدات الصحية — {l}" for _, l in UNIT_TYPES], sub, bold)
    line([data["units"][k] for k, _ in UNIT_TYPES])
    line([f"{g} — {l}" if g else l for _, l, g in SERVICE_FIELDS], sub, bold)
    line([data["service"][k] for k, _, _ in SERVICE_FIELDS])

    for col in "ABCDEFGHIJ":
        ws.column_dimensions[col].width = 22
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
