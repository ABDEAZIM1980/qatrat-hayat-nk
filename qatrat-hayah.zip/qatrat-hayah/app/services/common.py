"""دوال مشتركة: توليد الأكواد، الإعدادات، التسميات العربية للحالات."""
import secrets
import string

from ..db import get_db, utcnow

STATUS_LABELS = {
    "appointment": {
        "booked": "محجوز", "confirmed": "مؤكد", "checked_in": "حضر المتبرع", "completed": "تم التبرع",
        "deferred": "لم يتم التبرع (قرار طبي)", "cancelled": "ملغى", "no_show": "لم يحضر",
    },
    "donation": {"pending": "بانتظار الفحص والاعتماد", "approved": "معتمد", "rejected": "غير معتمد"},
    "request": {
        "pending": "بانتظار الاعتماد", "approved": "معتمد – قيد التوفير", "partially_fulfilled": "صُرف جزئيًا",
        "fulfilled": "مكتمل", "rejected": "مرفوض", "cancelled": "ملغى",
    },
    "appeal": {
        "pending_approval": "بانتظار الاعتماد", "open": "مفتوح", "completed": "مكتمل", "closed": "مغلق",
        "rejected": "مرفوض",
    },
    "center": {"active": "يعمل", "inactive": "معطّل"},
    "user": {"active": "نشط", "suspended": "موقوف", "disabled": "معطّل"},
    "donor": {"active": "نشط", "inactive": "غير نشط", "suspended": "موقوف"},
    "inventory": {"available": "متوفر", "low": "منخفض", "critical": "حرج"},
    "assessment": {"accepted": "مقبول للتبرع", "deferred": "تأجيل", "rejected": "غير مقبول"},
}

CENTER_TYPES = {
    "donation_center": "مركز تبرع", "blood_bank": "بنك دم", "hospital_bank": "بنك دم مستشفى",
    "mobile_unit": "وحدة تبرع متنقلة",
}

TX_TYPES = {
    "donation_in": "إضافة من تبرع", "issue_out": "صرف", "reserve": "حجز", "release": "فك حجز",
    "expire": "انتهاء صلاحية", "discard": "إتلاف", "adjust": "تسوية جرد",
    "transfer_in": "تحويل وارد", "transfer_out": "تحويل صادر",
}

CONTENT_CATEGORIES = {
    "before": "قبل التبرع", "after": "بعد التبرع", "eligibility": "شروط التبرع العامة",
    "myths": "مفاهيم خاطئة", "general": "معلومات عامة", "news": "أخبار",
}

WEEKDAYS = ["الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت", "الأحد"]  # Python weekday()


def label(kind, value):
    return STATUS_LABELS.get(kind, {}).get(value, value or "—")


def gen_code(prefix, length=6):
    alphabet = string.ascii_uppercase.replace("O", "").replace("I", "") + "23456789"
    return prefix + "".join(secrets.choice(alphabet) for _ in range(length))


def unique_code(table, column, prefix, length=6):
    db = get_db()
    assert table in {"donors", "blood_requests", "donations"} and column in {"donor_code", "request_code", "unit_number"}
    for _ in range(20):
        c = gen_code(prefix, length)
        if not db.one(f"SELECT 1 AS x FROM {table} WHERE {column} = ?", (c,)):
            return c
    raise RuntimeError("تعذر توليد رمز فريد")


DEFAULT_SETTINGS = {
    "booking_window_days": ("60", "عدد الأيام المتاحة للحجز مسبقًا"),
    "reminder_hours_before": ("24", "إرسال تذكير قبل الموعد بعدد الساعات"),
    "default_critical_level": ("3", "الحد الحرج الافتراضي لمخزون كل فصيلة"),
    "default_low_level": ("8", "الحد المنخفض الافتراضي لمخزون كل فصيلة"),
    "support_phone": ("0900000000", "رقم الدعم الظاهر للمستخدمين (تجريبي)"),
    "public_registration": ("1", "السماح بتسجيل المتبرعين من الموقع"),
}


def get_setting(key, default=None):
    row = get_db().one("SELECT value FROM system_settings WHERE key = ?", (key,))
    if row is None:
        return DEFAULT_SETTINGS.get(key, (default,))[0]
    return row["value"]


def get_int_setting(key, default=0):
    try:
        return int(get_setting(key, str(default)))
    except (TypeError, ValueError):
        return default


def set_setting(key, value, user_id=None):
    db = get_db()
    if db.one("SELECT 1 AS x FROM system_settings WHERE key = ?", (key,)):
        db.execute("UPDATE system_settings SET value = ?, updated_by = ?, updated_at = ? WHERE key = ?",
                   (value, user_id, utcnow(), key))
    else:
        db.execute("INSERT INTO system_settings (key, value, description, updated_by, updated_at) VALUES (?,?,?,?,?)",
                   (key, value, DEFAULT_SETTINGS.get(key, ("", ""))[1], user_id, utcnow()))
