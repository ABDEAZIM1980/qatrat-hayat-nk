"""التقارير القابلة للتصفية والتصدير (CSV / Excel / PDF).

التقارير لا تتضمن أرقام هواتف المتبرعين أو أي بيانات تعريفية غير لازمة (تقليل البيانات).
"""
import csv
import io

from ..db import get_db
from ..rbac import center_filter, donor_filter
from ..schema import BLOOD_TYPES
from ..validators import URGENCY
from .common import label
from .inventory import stock_status

REPORTS = {
    "donors": "تقرير المتبرعين",
    "donations": "تقرير التبرعات",
    "appointments": "تقرير المواعيد",
    "inventory": "تقرير المخزون",
    "requests": "تقرير طلبات الدم",
    "appeals": "تقرير الاحتياجات العاجلة",
    "center_performance": "تقرير أداء المراكز",
    "by_governorate": "تقرير حسب الولاية",
    "by_blood_type": "تقرير حسب الفصيلة",
}


def _geo_filters(f, where, params, gov_col="c.governorate_id", loc_col="c.locality_id", center_col="c.id"):
    if f.get("governorate_id"):
        where.append(f"{gov_col} = ?"); params.append(f["governorate_id"])
    if f.get("locality_id"):
        where.append(f"{loc_col} = ?"); params.append(f["locality_id"])
    if f.get("center_id") and center_col:
        where.append(f"{center_col} = ?"); params.append(f["center_id"])


def _dates(f, col, where, params):
    if f.get("date_from"):
        where.append(f"{col} >= ?"); params.append(f["date_from"])
    if f.get("date_to"):
        where.append(f"{col} <= ?"); params.append(f["date_to"] + " 23:59:59" if "donated" in col or "created" in col or "published" in col else f["date_to"])


def run(report, f, scope, limit=5000):
    db = get_db()
    cf, cp = center_filter(scope)
    where, params = [cf], list(cp)
    if report == "donors":
        df, dp = donor_filter(db, scope)
        where, params = [df], list(dp)
        _geo_filters(f, where, params, "d.governorate_id", "d.locality_id", "d.preferred_center_id")
        if f.get("blood_type"):
            where.append("d.blood_type = ?"); params.append(f["blood_type"])
        if f.get("status"):
            where.append("d.status = ?"); params.append(f["status"])
        _dates(f, "d.registered_at", where, params)
        cols = [("donor_code", "رمز المتبرع"), ("full_name", "الاسم"), ("blood_type", "الفصيلة"),
                ("governorate", "الولاية"), ("locality", "المحلية"), ("registered_at", "تاريخ التسجيل"),
                ("donations_count", "عدد التبرعات المعتمدة"), ("last_donation_at", "آخر تبرع معتمد"), ("status", "الحالة")]
        rows = db.query(
            f"""SELECT d.donor_code, u.full_name, d.blood_type, g.name_ar AS governorate, l.name_ar AS locality,
                d.registered_at AS registered_at, d.donations_count,
                d.last_donation_at AS last_donation_at, d.status
                FROM donors d JOIN users u ON u.id = d.user_id JOIN governorates g ON g.id = d.governorate_id
                JOIN localities l ON l.id = d.locality_id WHERE {' AND '.join(where)}
                ORDER BY d.registered_at DESC LIMIT ?""", [*params, limit])
        for r in rows:
            r["status"] = label("donor", r["status"])
            r["blood_type"] = r["blood_type"] or "غير محددة"
    elif report == "donations":
        _geo_filters(f, where, params)
        if f.get("blood_type"):
            where.append("x.blood_type = ?"); params.append(f["blood_type"])
        if f.get("status"):
            where.append("x.status = ?"); params.append(f["status"])
        _dates(f, "x.donated_at", where, params)
        cols = [("unit_number", "رقم الوحدة"), ("donated_at", "تاريخ التبرع"), ("donor_code", "رمز المتبرع"),
                ("blood_type", "الفصيلة"), ("volume_ml", "الحجم (مل)"), ("center", "المركز"),
                ("governorate", "الولاية"), ("status", "الحالة")]
        rows = db.query(
            f"""SELECT x.unit_number, x.donated_at AS donated_at, d.donor_code, x.blood_type, x.volume_ml,
                c.name AS center, g.name_ar AS governorate, x.status
                FROM donations x JOIN donors d ON d.id = x.donor_id JOIN blood_centers c ON c.id = x.center_id
                JOIN governorates g ON g.id = c.governorate_id WHERE {' AND '.join(where)}
                ORDER BY x.donated_at DESC LIMIT ?""", [*params, limit])
        for r in rows:
            r["status"] = label("donation", r["status"])
    elif report == "appointments":
        _geo_filters(f, where, params)
        if f.get("status"):
            where.append("a.status = ?"); params.append(f["status"])
        _dates(f, "a.appointment_date", where, params)
        cols = [("appointment_date", "التاريخ"), ("appointment_time", "الوقت"), ("center", "المركز"),
                ("donor_code", "رمز المتبرع"), ("blood_type", "الفصيلة"), ("status", "الحالة")]
        rows = db.query(
            f"""SELECT a.appointment_date, a.appointment_time, c.name AS center, d.donor_code, d.blood_type, a.status
                FROM appointments a JOIN blood_centers c ON c.id = a.center_id JOIN donors d ON d.id = a.donor_id
                WHERE {' AND '.join(where)} ORDER BY a.appointment_date DESC, a.appointment_time LIMIT ?""",
            [*params, limit])
        for r in rows:
            r["status"] = label("appointment", r["status"])
            r["blood_type"] = r["blood_type"] or "غير محددة"
            r["appointment_time"] = str(r["appointment_time"])[:5]
    elif report == "inventory":
        _geo_filters(f, where, params)
        if f.get("blood_type"):
            where.append("i.blood_type = ?"); params.append(f["blood_type"])
        cols = [("center", "المركز"), ("governorate", "الولاية"), ("locality", "المحلية"), ("blood_type", "الفصيلة"),
                ("available_units", "المتاح"), ("reserved_units", "المحجوز"), ("critical_level", "الحد الحرج"),
                ("status", "الحالة"), ("updated_at", "آخر تحديث")]
        rows = db.query(
            f"""SELECT c.name AS center, g.name_ar AS governorate, l.name_ar AS locality, i.blood_type,
                i.available_units, i.reserved_units, i.critical_level, i.low_level, i.updated_at AS updated_at
                FROM blood_inventory i JOIN blood_centers c ON c.id = i.center_id
                JOIN governorates g ON g.id = c.governorate_id JOIN localities l ON l.id = c.locality_id
                WHERE {' AND '.join(where)} AND c.status = 'active' ORDER BY c.name, i.blood_type LIMIT ?""",
            [*params, limit])
        for r in rows:
            st = stock_status(r)
            if f.get("status") and f["status"] != st:
                r["_skip"] = True
            r["status"] = label("inventory", st)
        rows = [r for r in rows if not r.get("_skip")]
    elif report == "requests":
        _geo_filters(f, where, params)
        if f.get("blood_type"):
            where.append("r.blood_type = ?"); params.append(f["blood_type"])
        if f.get("status"):
            where.append("r.status = ?"); params.append(f["status"])
        if f.get("urgency"):
            where.append("r.urgency = ?"); params.append(f["urgency"])
        _dates(f, "r.created_at", where, params)
        cols = [("request_code", "رقم الطلب"), ("created_at", "التاريخ"), ("center", "المركز"),
                ("requesting_entity", "الجهة الطالبة"), ("blood_type", "الفصيلة"), ("units_required", "المطلوب"),
                ("units_fulfilled", "المصروف"), ("urgency", "الاستعجال"), ("status", "الحالة")]
        rows = db.query(
            f"""SELECT r.request_code, r.created_at AS created_at, c.name AS center, r.requesting_entity,
                r.blood_type, r.units_required, r.units_fulfilled, r.urgency, r.status
                FROM blood_requests r JOIN blood_centers c ON c.id = r.center_id
                WHERE {' AND '.join(where)} ORDER BY r.created_at DESC LIMIT ?""", [*params, limit])
        for r in rows:
            r["urgency"] = URGENCY.get(r["urgency"], r["urgency"])
            r["status"] = label("request", r["status"])
    elif report == "appeals":
        _geo_filters(f, where, params)
        if f.get("blood_type"):
            where.append("e.blood_type = ?"); params.append(f["blood_type"])
        if f.get("status"):
            where.append("e.status = ?"); params.append(f["status"])
        _dates(f, "e.created_at", where, params)
        cols = [("title", "العنوان"), ("center", "المركز"), ("blood_type", "الفصيلة"), ("units_needed", "المطلوب"),
                ("units_collected", "تم جمعه"), ("urgency", "الاستعجال"), ("status", "الحالة"), ("published_at", "تاريخ النشر")]
        rows = db.query(
            f"""SELECT e.title, c.name AS center, e.blood_type, e.units_needed, e.units_collected, e.urgency, e.status,
                e.published_at AS published_at FROM emergency_appeals e
                JOIN blood_centers c ON c.id = e.center_id WHERE {' AND '.join(where)}
                ORDER BY e.created_at DESC LIMIT ?""", [*params, limit])
        for r in rows:
            r["urgency"] = URGENCY.get(r["urgency"], r["urgency"])
            r["status"] = label("appeal", r["status"])
            r["published_at"] = r["published_at"] or "لم يُنشر"
    elif report == "center_performance":
        _geo_filters(f, where, params)
        dw, dpar = [], []
        if f.get("date_from"):
            dw.append("{c} >= ?"); dpar.append(f["date_from"])
        if f.get("date_to"):
            dw.append("{c} <= ?"); dpar.append(f["date_to"] + " 23:59:59")

        def dcond(col):
            return (" AND " + " AND ".join(x.format(c=col) for x in dw)) if dw else ""
        cols = [("center", "المركز"), ("governorate", "الولاية"), ("appointments", "المواعيد"),
                ("completed", "تمت بتبرع"), ("no_show", "لم يحضر"), ("approved", "وحدات معتمدة"),
                ("rejected", "وحدات غير معتمدة"), ("issued", "وحدات مصروفة"), ("available", "المخزون المتاح")]
        rows = db.query(
            f"""SELECT c.name AS center, g.name_ar AS governorate,
              (SELECT COUNT(*) FROM appointments a WHERE a.center_id = c.id{dcond('a.appointment_date')}) AS appointments,
              (SELECT COUNT(*) FROM appointments a WHERE a.center_id = c.id AND a.status = 'completed'{dcond('a.appointment_date')}) AS completed,
              (SELECT COUNT(*) FROM appointments a WHERE a.center_id = c.id AND a.status = 'no_show'{dcond('a.appointment_date')}) AS no_show,
              (SELECT COUNT(*) FROM donations x WHERE x.center_id = c.id AND x.status = 'approved'{dcond('x.donated_at')}) AS approved,
              (SELECT COUNT(*) FROM donations x WHERE x.center_id = c.id AND x.status = 'rejected'{dcond('x.donated_at')}) AS rejected,
              (SELECT COALESCE(SUM(t.quantity),0) FROM blood_inventory_transactions t WHERE t.center_id = c.id AND t.tx_type = 'issue_out'{dcond('t.created_at')}) AS issued,
              (SELECT COALESCE(SUM(i.available_units),0) FROM blood_inventory i WHERE i.center_id = c.id) AS available
              FROM blood_centers c JOIN governorates g ON g.id = c.governorate_id
              WHERE {' AND '.join(where)} ORDER BY c.name LIMIT ?""",
            _perf_params(dpar, params, limit))
    elif report == "by_governorate":
        cols = [("governorate", "الولاية"), ("centers", "المراكز العاملة"), ("donors", "المتبرعون"),
                ("approved", "تبرعات معتمدة"), ("open_requests", "طلبات مفتوحة"), ("available", "المخزون المتاح")]
        gw, gp = [], []
        if not scope.is_global:
            ids = sorted(scope.governorate_ids | {r["governorate_id"] for r in db.query(
                f"SELECT DISTINCT c.governorate_id FROM blood_centers c WHERE {cf}", cp)})
            if not ids:
                return cols, []
            gw.append(f"g.id IN ({', '.join('?' for _ in ids)})"); gp += ids
        if f.get("governorate_id"):
            gw.append("g.id = ?"); gp.append(f["governorate_id"])
        rows = db.query(
            f"""SELECT g.name_ar AS governorate,
               (SELECT COUNT(*) FROM blood_centers c WHERE c.governorate_id = g.id AND c.status = 'active') AS centers,
               (SELECT COUNT(*) FROM donors d WHERE d.governorate_id = g.id) AS donors,
               (SELECT COUNT(*) FROM donations x JOIN blood_centers c ON c.id = x.center_id WHERE c.governorate_id = g.id AND x.status = 'approved') AS approved,
               (SELECT COUNT(*) FROM blood_requests r JOIN blood_centers c ON c.id = r.center_id WHERE c.governorate_id = g.id AND r.status IN ('pending','approved','partially_fulfilled')) AS open_requests,
               (SELECT COALESCE(SUM(i.available_units),0) FROM blood_inventory i JOIN blood_centers c ON c.id = i.center_id WHERE c.governorate_id = g.id) AS available
               FROM governorates g WHERE g.is_active = 1 {('AND ' + ' AND '.join(gw)) if gw else ''} ORDER BY g.name_ar""", gp)
    elif report == "by_blood_type":
        _geo_filters(f, where, params)
        df, dp = donor_filter(db, scope)
        cols = [("blood_type", "الفصيلة"), ("donors", "المتبرعون"), ("approved", "تبرعات معتمدة"),
                ("available", "المخزون المتاح"), ("requested", "وحدات مطلوبة (طلبات مفتوحة)")]
        w = " AND ".join(where)
        rows = []
        for bt in BLOOD_TYPES:
            rows.append({
                "blood_type": bt,
                "donors": db.scalar(f"SELECT COUNT(*) AS n FROM donors d WHERE {df} AND d.blood_type = ?", [*dp, bt], 0),
                "approved": db.scalar(f"SELECT COUNT(*) AS n FROM donations x JOIN blood_centers c ON c.id = x.center_id WHERE {w} AND x.status='approved' AND x.blood_type = ?", [*params, bt], 0),
                "available": db.scalar(f"SELECT COALESCE(SUM(i.available_units),0) AS n FROM blood_inventory i JOIN blood_centers c ON c.id = i.center_id WHERE {w} AND i.blood_type = ?", [*params, bt], 0),
                "requested": db.scalar(f"SELECT COALESCE(SUM(r.units_required - r.units_fulfilled),0) AS n FROM blood_requests r JOIN blood_centers c ON c.id = r.center_id WHERE {w} AND r.status IN ('pending','approved','partially_fulfilled') AND r.blood_type = ?", [*params, bt], 0),
            })
    else:
        raise KeyError(report)
    return cols, localize(rows)


TS_COLS = {"registered_at": False, "last_donation_at": False, "donated_at": False, "created_at": False,
           "published_at": False, "updated_at": True}


def localize(rows):
    """تحويل الطوابع الزمنية من UTC إلى توقيت السودان للعرض والتصدير."""
    from ..timeutil import parse_ts
    for r in rows:
        for k, with_time in TS_COLS.items():
            if k in r and r[k] and r[k] != "لم يُنشر":
                dt = parse_ts(r[k])
                if dt:
                    r[k] = dt.strftime("%Y-%m-%d %H:%M" if with_time else "%Y-%m-%d")
    return rows


def _perf_params(dpar, params, limit):
    # 7 استعلامات فرعية؛ الأخير (المخزون) بدون تاريخ
    return [*(dpar * 6), *params, limit]


# ---------------- التصدير ----------------
def to_csv(cols, rows):
    buf = io.StringIO()
    buf.write("﻿")  # BOM ليفتح Excel النص العربي بشكل صحيح
    w = csv.writer(buf)
    w.writerow([c[1] for c in cols])
    for r in rows:
        w.writerow([_cell(r.get(c[0])) for c in cols])
    return buf.getvalue().encode("utf-8")


def _cell(v):
    if v is None:
        return ""
    s = str(v)
    # منع حقن الصيغ في Excel (CSV injection)
    if s and s[0] in "=+-@" and not _is_number(s):
        return "'" + s
    return s


def _is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False


def to_xlsx(title, cols, rows, meta):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "التقرير"
    ws.sheet_view.rightToLeft = True
    ws.append([title])
    ws["A1"].font = Font(bold=True, size=14, color="B71C1C")
    ws.append([meta])
    ws.append([])
    ws.append([c[1] for c in cols])
    hdr = ws.max_row
    for cell in ws[hdr]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="0D47A1")
        cell.alignment = Alignment(horizontal="center")
    for r in rows:
        ws.append([_xl(r.get(c[0])) for c in cols])
    for i, c in enumerate(cols, start=1):
        width = max([len(str(c[1]))] + [len(str(r.get(c[0]) or "")) for r in rows[:200]]) + 4
        ws.column_dimensions[ws.cell(row=hdr, column=i).column_letter].width = min(width, 40)
    ws.freeze_panes = ws.cell(row=hdr + 1, column=1)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _xl(v):
    if isinstance(v, str) and v and v[0] in "=+-@" and not _is_number(v):
        return "'" + v
    return v


def html_to_pdf(html, landscape=True):
    """تحويل HTML إلى PDF باستخدام Chromium (يدعم العربية بالكامل). يُرجع None إن لم يتوفر."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        return None
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(args=["--no-sandbox"])
            page = browser.new_page()
            page.set_content(html, wait_until="load")
            pdf = page.pdf(format="A4", landscape=landscape, print_background=True,
                           margin={"top": "12mm", "bottom": "12mm", "left": "10mm", "right": "10mm"})
            browser.close()
            return pdf
    except Exception:
        return None


def embedded_font_css():
    """خط عربي مضمّن (base64) لاستخدامه عند توليد PDF خارج سياق المتصفح."""
    import base64
    from pathlib import Path
    fonts = Path(__file__).resolve().parent.parent / "static" / "fonts"
    css = []
    for weight, name in ((400, "Regular"), (700, "Bold")):
        p = fonts / f"plex-arabic-{name}.woff"
        if p.exists():
            b64 = base64.b64encode(p.read_bytes()).decode()
            css.append(f"@font-face{{font-family:'Plex Arabic';font-weight:{weight};src:url(data:font/woff;base64,{b64}) format('woff');}}")
    return "".join(css)
