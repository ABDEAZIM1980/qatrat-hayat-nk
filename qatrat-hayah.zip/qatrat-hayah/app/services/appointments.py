"""حجز المواعيد: حساب الأوقات المتاحة، الحجز، التعديل، الإلغاء، وتغيير الحالة.

ملاحظة مهمة: حجز الموعد لا يعني الأهلية الطبية للتبرع. القرار يتخذه المختص في المركز.
"""
from datetime import date, datetime, timedelta

from ..db import get_db, utcnow
from ..notifications import notify, notify_center_staff
from ..timeutil import local_now
from .common import WEEKDAYS, get_int_setting

ACTIVE = ("booked", "confirmed")

# الانتقالات المسموح بها لحالة الموعد من قِبل موظفي المركز
STAFF_TRANSITIONS = {
    "booked": {"confirmed", "checked_in", "cancelled", "no_show"},
    "confirmed": {"checked_in", "cancelled", "no_show"},
    "checked_in": {"no_show"},  # بعد الحضور: يُسجَّل التقييم الطبي أو التبرع
}


class BookingError(Exception):
    pass


def _parse_date(d):
    return d if isinstance(d, date) else datetime.strptime(str(d)[:10], "%Y-%m-%d").date()


def _t(v):
    return str(v)[:5]


def available_slots(center_id, day, exclude_appointment_id=None):
    """قائمة بالأوقات المتاحة [{time, remaining}] لمركز في يوم محدد."""
    db = get_db()
    day = _parse_date(day)
    center = db.one("SELECT * FROM blood_centers WHERE id = ?", (center_id,))
    if not center or center["status"] != "active" or not center["accepts_appointments"]:
        return []
    now = local_now()
    window = get_int_setting("booking_window_days", 60)
    if day < now.date() or day > now.date() + timedelta(days=window):
        return []
    sched = db.one("SELECT * FROM center_schedules WHERE center_id = ? AND weekday = ?", (center_id, day.weekday()))
    if not sched:
        return []
    booked = {}
    for r in db.query(
        """SELECT appointment_time AS t, COUNT(*) AS n FROM appointments
           WHERE center_id = ? AND appointment_date = ? AND status IN ('booked','confirmed','checked_in')
           AND id != ? GROUP BY appointment_time""",
        (center_id, day.isoformat(), exclude_appointment_id or 0),
    ):
        booked[_t(r["t"])] = r["n"]
    start = datetime.combine(day, datetime.strptime(_t(sched["start_time"]), "%H:%M").time())
    end = datetime.combine(day, datetime.strptime(_t(sched["end_time"]), "%H:%M").time())
    step = timedelta(minutes=sched["slot_minutes"])
    out = []
    cur = start
    while cur + step <= end:
        t = cur.strftime("%H:%M")
        if day > now.date() or cur.time() > (now + timedelta(minutes=30)).time().replace(tzinfo=None):
            remaining = sched["capacity_per_slot"] - booked.get(t, 0)
            if remaining > 0:
                out.append({"time": t, "remaining": remaining})
        cur += step
    return out


def open_days(center_id, days=14):
    """الأيام القادمة التي يعمل فيها المركز (للمساعدة في اختيار التاريخ)."""
    db = get_db()
    weekdays = {r["weekday"] for r in db.query("SELECT weekday FROM center_schedules WHERE center_id = ?", (center_id,))}
    today = local_now().date()
    out = []
    for i in range(days):
        d = today + timedelta(days=i)
        if d.weekday() in weekdays:
            out.append({"date": d.isoformat(), "weekday": WEEKDAYS[d.weekday()]})
    return out


def _validate_slot(center_id, day, time_str, exclude=None):
    slots = {s["time"] for s in available_slots(center_id, day, exclude)}
    if time_str not in slots:
        raise BookingError("هذا الوقت غير متاح. يرجى اختيار وقت آخر من الأوقات المعروضة.")


def book(donor, center_id, day, time_str, notes=None):
    db = get_db()
    if donor["status"] != "active":
        raise BookingError("حساب المتبرع غير نشط. يرجى التواصل مع المركز.")
    with db.transaction():
        active = db.one(
            """SELECT id FROM appointments WHERE donor_id = ? AND status IN ('booked','confirmed')
               AND appointment_date >= ?""", (donor["id"], local_now().date().isoformat()))
        if active:
            raise BookingError("لديك موعد قائم بالفعل. يمكنك تعديله أو إلغاؤه قبل حجز موعد جديد.")
        _validate_slot(center_id, day, time_str)
        now = utcnow()
        aid = db.insert("appointments", {
            "donor_id": donor["id"], "center_id": center_id, "appointment_date": _parse_date(day).isoformat(),
            "appointment_time": time_str, "status": "booked", "donor_notes": notes, "created_at": now,
            "updated_at": now})
    center = db.get("blood_centers", center_id)
    notify(donor["user_id"], "appointment_confirmed", "تم تأكيد حجز موعدك",
           f"موعدك في {center['name']} بتاريخ {_parse_date(day).isoformat()} الساعة {time_str}. "
           "نذكّرك بأن حجز الموعد لا يُعد دليلاً على الأهلية الطبية للتبرع.", f"/donor/appointments/{aid}")
    notify_center_staff(center_id, "center", "حجز موعد جديد",
                        f"تم حجز موعد جديد بتاريخ {_parse_date(day).isoformat()} الساعة {time_str}.",
                        f"/admin/appointments/{aid}")
    return aid


def reschedule(appt, center_id, day, time_str):
    db = get_db()
    if appt["status"] not in ACTIVE:
        raise BookingError("لا يمكن تعديل هذا الموعد في حالته الحالية.")
    with db.transaction():
        _validate_slot(center_id, day, time_str, exclude=appt["id"])
        db.update("appointments", appt["id"], {
            "center_id": center_id, "appointment_date": _parse_date(day).isoformat(),
            "appointment_time": time_str, "status": "booked", "reminder_sent_at": None, "updated_at": utcnow()})
    donor = db.get("donors", appt["donor_id"])
    notify(donor["user_id"], "appointment_status", "تم تعديل موعدك",
           f"موعدك الجديد بتاريخ {_parse_date(day).isoformat()} الساعة {time_str}.", f"/donor/appointments/{appt['id']}")
    notify_center_staff(center_id, "center", "تعديل موعد", f"تم تعديل موعد إلى {_parse_date(day).isoformat()} {time_str}.",
                        f"/admin/appointments/{appt['id']}")


def cancel(appt, reason, by_donor=True):
    db = get_db()
    if appt["status"] not in ACTIVE:
        raise BookingError("لا يمكن إلغاء هذا الموعد في حالته الحالية.")
    db.update("appointments", appt["id"], {"status": "cancelled", "cancel_reason": reason, "updated_at": utcnow()})
    donor = db.get("donors", appt["donor_id"])
    if by_donor:
        notify_center_staff(appt["center_id"], "center", "إلغاء موعد",
                            f"ألغى متبرع موعده بتاريخ {appt['appointment_date']}.", f"/admin/appointments/{appt['id']}")
    else:
        notify(donor["user_id"], "appointment_status", "تم إلغاء موعدك",
               f"تم إلغاء موعدك بتاريخ {appt['appointment_date']}. {('السبب: ' + reason) if reason else ''}".strip(),
               f"/donor/appointments/{appt['id']}")


def staff_set_status(appt, new_status, notes=None):
    db = get_db()
    allowed = STAFF_TRANSITIONS.get(appt["status"], set())
    if new_status not in allowed:
        raise BookingError("لا يمكن نقل الموعد إلى هذه الحالة.")
    data = {"status": new_status, "updated_at": utcnow()}
    if notes:
        data["staff_notes"] = notes
    if new_status == "cancelled":
        data["cancel_reason"] = notes or "ألغاه المركز"
    db.update("appointments", appt["id"], data)
    donor = db.get("donors", appt["donor_id"])
    from .common import label
    if new_status in ("confirmed", "cancelled", "no_show"):
        notify(donor["user_id"], "appointment_status", "تحديث حالة موعدك",
               f"حالة موعدك بتاريخ {appt['appointment_date']}: {label('appointment', new_status)}.",
               f"/donor/appointments/{appt['id']}")


def send_reminders():
    """يرسل تذكيرًا للمواعيد خلال الساعات القادمة (تُشغَّل عبر cron: flask send-reminders)."""
    db = get_db()
    hours = get_int_setting("reminder_hours_before", 24)
    now = local_now().replace(tzinfo=None)
    horizon = now + timedelta(hours=hours)
    rows = db.query(
        """SELECT a.*, d.user_id, c.name AS center_name FROM appointments a
           JOIN donors d ON d.id = a.donor_id JOIN blood_centers c ON c.id = a.center_id
           WHERE a.status IN ('booked','confirmed') AND a.reminder_sent_at IS NULL
           AND a.appointment_date >= ? AND a.appointment_date <= ?""",
        (now.date().isoformat(), horizon.date().isoformat()))
    n = 0
    for a in rows:
        at = datetime.strptime(f"{str(a['appointment_date'])[:10]} {_t(a['appointment_time'])}", "%Y-%m-%d %H:%M")
        if now <= at <= horizon:
            notify(a["user_id"], "appointment_reminder", "تذكير بموعد التبرع",
                   f"نذكّرك بموعدك في {a['center_name']} بتاريخ {str(a['appointment_date'])[:10]} الساعة {_t(a['appointment_time'])}. "
                   "احرص على تناول وجبة خفيفة وشرب الماء قبل الحضور.", f"/donor/appointments/{a['id']}")
            db.update("appointments", a["id"], {"reminder_sent_at": utcnow()})
            n += 1
    return n
