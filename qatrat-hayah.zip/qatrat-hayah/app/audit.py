"""سجل التدقيق (Audit Log) لكل العمليات الحساسة."""
import json

from flask import g, has_request_context, request

from .db import get_db, utcnow

ACTIONS = {
    "login": "تسجيل الدخول",
    "login_failed": "محاولة دخول فاشلة",
    "logout": "تسجيل الخروج",
    "register": "تسجيل حساب جديد",
    "password_change": "تغيير كلمة المرور",
    "user_create": "إنشاء مستخدم",
    "user_update": "تعديل مستخدم",
    "role_assign": "إسناد دور",
    "role_revoke": "سحب دور",
    "center_create": "إضافة مركز",
    "center_update": "تعديل مركز",
    "center_status": "تغيير حالة مركز",
    "geo_create": "إضافة وحدة جغرافية",
    "geo_update": "تعديل وحدة جغرافية",
    "donor_update": "تعديل بيانات متبرع",
    "appointment_create": "حجز موعد",
    "appointment_update": "تعديل موعد",
    "appointment_cancel": "إلغاء موعد",
    "appointment_status": "تغيير حالة موعد",
    "assessment_record": "تسجيل قرار التقييم الطبي",
    "donation_record": "تسجيل تبرع",
    "donation_approve": "اعتماد وحدة دم",
    "donation_reject": "رفض وحدة دم",
    "request_create": "إنشاء طلب دم",
    "request_update": "تعديل طلب دم",
    "request_approve": "اعتماد طلب دم",
    "request_reject": "رفض طلب دم",
    "request_fulfill": "صرف وحدات لطلب دم",
    "appeal_create": "إنشاء نداء عاجل",
    "appeal_publish": "نشر نداء عاجل",
    "appeal_reject": "رفض نداء عاجل",
    "appeal_status": "تغيير حالة نداء",
    "inventory_adjust": "تعديل المخزون",
    "content_create": "إضافة محتوى توعوي",
    "content_update": "تعديل محتوى توعوي",
    "notification_broadcast": "إرسال إشعار إداري",
    "report_export": "تصدير تقرير",
    "settings_update": "تعديل الإعدادات",
    "backup_create": "إنشاء نسخة احتياطية",
}

ENTITY_NAMES = {
    "user": "مستخدم", "center": "مركز", "governorate": "ولاية", "locality": "محلية", "city": "مدينة",
    "donor": "متبرع", "appointment": "موعد", "donation": "تبرع", "blood_request": "طلب دم",
    "appeal": "نداء عاجل", "inventory": "مخزون", "content": "محتوى", "report": "تقرير",
    "settings": "إعدادات", "backup": "نسخة احتياطية", "notification": "إشعار",
}

_SENSITIVE = {"password", "password_hash", "_csrf", "token"}


def log(action, entity_type=None, entity_id=None, details=None, user=None):
    db = get_db()
    u = user if user is not None else (g.get("user") if has_request_context() else None)
    uid = getattr(u, "id", None) if u is not None and not isinstance(u, dict) else (u or {}).get("id")
    uname = getattr(u, "name", None) if u is not None and not isinstance(u, dict) else (u or {}).get("full_name")
    clean = {k: v for k, v in (details or {}).items() if k not in _SENSITIVE}
    ip = ua = None
    if has_request_context():
        ip = request.remote_addr
        ua = (request.headers.get("User-Agent") or "")[:255]
    db.insert("audit_logs", {
        "user_id": uid, "user_name": uname, "action": action, "entity_type": entity_type,
        "entity_id": entity_id, "details": json.dumps(clean, ensure_ascii=False, default=str) if clean else None,
        "ip_address": ip, "user_agent": ua, "created_at": utcnow(),
    })


def diff(old, new, fields):
    """يُرجع الحقول التي تغيّرت فقط (قديم ← جديد)."""
    out = {}
    for f in fields:
        if f in new and (old or {}).get(f) != new[f]:
            out[f] = {"من": (old or {}).get(f), "إلى": new[f]}
    return out
